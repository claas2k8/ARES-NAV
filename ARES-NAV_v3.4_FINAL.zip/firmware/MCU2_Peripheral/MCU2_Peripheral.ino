/*
 * ARES-NAV — MCU 2 Peripheral Controller
 * Hardware: Arduino Pro Micro (ATmega32U4 @ 16 MHz)
 * Role:     u-blox NEO-M8N GNSS (UART 115200),
 *           Bosch BMP280 barometer (I2C 0x76),
 *           AOSONG AHT20 temp/humidity (I2C 0x38),
 *           Rotary encoder with push-button (GPIO interrupts),
 *           48-byte binary frames over USB CDC at 10 Hz.
 *
 * AHT20 replaces BMP280 temperature for higher accuracy.
 * BMP280 pressure is temperature-compensated using AHT20 reading.
 *
 * USB Serial Number: ARESNAV-PERI  (set in platform config)
 * Pi device symlink: /dev/aresnav-peri  (via udev rule)
 *
 * Frame format: 48 bytes — ARES-NAV Spec Rev. 3.3, Section 13
 * Revision: 3.3  |  Duwald Systems  |  March 2026
 */

#include <Wire.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>

// ── Pin assignments ────────────────────────────────────────────────────────
#define GPS_SERIAL   Serial1
#define GPS_BAUD     115200UL
#define BMP280_ADDR  0x76    // SDO=GND
#define AHT20_ADDR   0x38    // fixed address
#define ENC_CLK_PIN  7
#define ENC_DT_PIN   6
#define ENC_SW_PIN   5
#define LED_ENC_PIN  17      // RX LED active LOW
#define LED_TX_PIN   30      // TX LED active LOW

// ── Frame constants ────────────────────────────────────────────────────────
#define FRAME_SIZE      48
#define SYNC0           0xBB
#define SYNC1           0x66
#define TX_INTERVAL_MS  100   // 10 Hz

// ── LED blink state machine ────────────────────────────────────────────────
struct Blink { uint8_t count; uint8_t pin; uint32_t next_ms; bool on; };
static Blink blink_enc = {0, LED_ENC_PIN, 0, false};

void blink_trigger(Blink &b, uint8_t times) {
  if (b.count == 0) { b.count = times * 2; b.on = false; b.next_ms = millis(); }
}
void blink_update(Blink &b) {
  if (!b.count || millis() < b.next_ms) return;
  b.on = !b.on;
  digitalWrite(b.pin, b.on ? LOW : HIGH);
  b.next_ms = millis() + 40;
  if (!--b.count) digitalWrite(b.pin, HIGH);
}

// ── uint64 timestamp via Timer1 overflow ──────────────────────────────────
volatile uint32_t t1_ovf = 0;
ISR(TIMER1_OVF_vect) { t1_ovf++; }

uint64_t micros64() {
  cli();
  uint32_t ovf = t1_ovf;
  uint32_t cnt = TCNT1;
  if (TIFR1 & _BV(TOV1) && cnt < 0x8000) ovf++;
  sei();
  return ((uint64_t)ovf << 16) * (64000000ULL / F_CPU) + ((uint64_t)cnt * 4);
}

static void timer1_init_ovf() {
  TCCR1A = 0;
  TCCR1B = _BV(CS11) | _BV(CS10); // prescaler 64
  TIMSK1 = _BV(TOIE1);
}

// ── CRC8 polynomial 0x07 ──────────────────────────────────────────────────
uint8_t crc8(uint8_t *d, uint8_t len) {
  uint8_t c = 0;
  for (uint8_t i = 0; i < len; i++) {
    c ^= d[i];
    for (uint8_t j = 0; j < 8; j++)
      c = (c & 0x80) ? (c << 1) ^ 0x07 : (c << 1);
  }
  return c;
}

// ── BMP280 driver ─────────────────────────────────────────────────────────
struct Bmp280Cal {
  uint16_t T1; int16_t T2, T3;
  uint16_t P1; int16_t P2, P3, P4, P5, P6, P7, P8, P9;
};
static Bmp280Cal bmp_cal;
static bool bmp_ok = false;

static uint8_t bmp_rb(uint8_t reg) {
  Wire.beginTransmission(BMP280_ADDR); Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)1);
  return Wire.available() ? Wire.read() : 0;
}
static void bmp_wb(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(BMP280_ADDR); Wire.write(reg); Wire.write(val);
  Wire.endTransmission();
}
static uint16_t bmp_r16u(uint8_t reg) {
  Wire.beginTransmission(BMP280_ADDR); Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)2);
  if (Wire.available() < 2) return 0;
  uint8_t lo = Wire.read(), hi = Wire.read();
  return (uint16_t)(hi << 8) | lo;
}
static int16_t bmp_r16s(uint8_t reg) { return (int16_t)bmp_r16u(reg); }

static bool bmp_init() {
  uint8_t id = bmp_rb(0xD0);
  if (id != 0x60 && id != 0x58) return false;
  bmp_cal.T1=bmp_r16u(0x88); bmp_cal.T2=bmp_r16s(0x8A); bmp_cal.T3=bmp_r16s(0x8C);
  bmp_cal.P1=bmp_r16u(0x8E); bmp_cal.P2=bmp_r16s(0x90); bmp_cal.P3=bmp_r16s(0x92);
  bmp_cal.P4=bmp_r16s(0x94); bmp_cal.P5=bmp_r16s(0x96); bmp_cal.P6=bmp_r16s(0x98);
  bmp_cal.P7=bmp_r16s(0x9A); bmp_cal.P8=bmp_r16s(0x9C); bmp_cal.P9=bmp_r16s(0x9E);
  bmp_wb(0xF5, 0x08); // IIR filter x2, t_sb 0.5ms
  bmp_wb(0xF4, 0x6F); // osrs_t=x4, osrs_p=x4, normal mode
  delay(10);
  return true;
}

// bmp_read: uses aht_temp_cdegc for t_fine override when AHT20 available
// This improves pressure accuracy by using the more accurate AHT20 temperature
static void bmp_read(int32_t *press_pa_x100, int32_t *temp_cdegc,
                     int32_t aht_temp_cdegc, bool use_aht) {
  Wire.beginTransmission(BMP280_ADDR); Wire.write(0xF7);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)6);
  if (Wire.available() < 6) { *press_pa_x100 = 0; *temp_cdegc = 0; return; }
  int32_t adc_P = ((int32_t)Wire.read()<<12)|((int32_t)Wire.read()<<4)|(Wire.read()>>4);
  int32_t adc_T = ((int32_t)Wire.read()<<12)|((int32_t)Wire.read()<<4)|(Wire.read()>>4);

  // Temperature compensation
  int32_t var1 = (((adc_T>>3)-((int32_t)bmp_cal.T1<<1))*bmp_cal.T2)>>11;
  int32_t var2 = (((((adc_T>>4)-(int32_t)bmp_cal.T1)*
                    ((adc_T>>4)-(int32_t)bmp_cal.T1))>>12)*bmp_cal.T3)>>14;
  int32_t t_fine = var1 + var2;

  // If AHT20 available, override t_fine for better pressure compensation
  // t_fine = temp_cdegc * 5120 / 100 (inverse of BMP280 temp formula)
  if (use_aht) {
    t_fine = (int32_t)(aht_temp_cdegc * 5120L / 100L);
  }

  *temp_cdegc = (t_fine * 5 + 128) >> 8;

  // Pressure compensation (64-bit)
  int64_t v1p = (int64_t)t_fine - 128000;
  int64_t v2p = v1p*v1p*(int64_t)bmp_cal.P6;
  v2p += ((v1p*(int64_t)bmp_cal.P5)<<17);
  v2p += ((int64_t)bmp_cal.P4<<35);
  v1p  = ((v1p*v1p*(int64_t)bmp_cal.P3)>>8)+((v1p*(int64_t)bmp_cal.P2)<<12);
  v1p  = (((int64_t)1<<47)+v1p)*(int64_t)bmp_cal.P1>>33;
  if (!v1p) { *press_pa_x100 = 0; return; }
  int64_t p = 1048576 - adc_P;
  p = (((p<<31)-v2p)*3125)/v1p;
  v1p = ((int64_t)bmp_cal.P9*(p>>13)*(p>>13))>>25;
  v2p = ((int64_t)bmp_cal.P8*p)>>19;
  p = ((p+v1p+v2p)>>8)+((int64_t)bmp_cal.P7<<4);
  *press_pa_x100 = (int32_t)((p*100)>>8);
}

// ── AHT20 driver ──────────────────────────────────────────────────────────
// AHT20 I2C address: 0x38 (fixed)
// Returns temperature in 0.01°C and humidity in 0.01% RH
static bool aht_ok = false;

static bool aht_init() {
  // Power-on delay
  delay(40);
  // Check status byte
  Wire.beginTransmission(AHT20_ADDR);
  Wire.endTransmission();
  delay(10);
  // Send init command 0xBE 0x08 0x00
  Wire.beginTransmission(AHT20_ADDR);
  Wire.write(0xBE); Wire.write(0x08); Wire.write(0x00);
  if (Wire.endTransmission() != 0) return false;
  delay(10);
  return true;
}

// Returns true if data valid
// temp_cdegc: temperature in 0.01°C (e.g. 2456 = 24.56°C)
// hum_cpct:   humidity in 0.01% RH  (e.g. 5523 = 55.23%)
static bool aht_read(int32_t *temp_cdegc, int32_t *hum_cpct) {
  // Trigger measurement: 0xAC 0x33 0x00
  Wire.beginTransmission(AHT20_ADDR);
  Wire.write(0xAC); Wire.write(0x33); Wire.write(0x00);
  if (Wire.endTransmission() != 0) return false;
  delay(80);  // measurement time per datasheet

  Wire.requestFrom((uint8_t)AHT20_ADDR, (uint8_t)6);
  if (Wire.available() < 6) return false;

  uint8_t status = Wire.read();
  if (status & 0x80) return false;  // busy bit set

  uint32_t raw_hum = ((uint32_t)Wire.read() << 12) |
                     ((uint32_t)Wire.read() << 4);
  uint8_t  mid     = Wire.read();
  raw_hum         |= (mid >> 4);
  uint32_t raw_tmp = ((uint32_t)(mid & 0x0F) << 16) |
                     ((uint32_t)Wire.read() << 8)   |
                      Wire.read();

  // Temperature: T = (raw_tmp / 2^20) * 200 - 50  [°C]
  // In 0.01°C:   T = (raw_tmp * 20000 / 1048576) - 5000
  *temp_cdegc = (int32_t)((int64_t)raw_tmp * 20000 / 1048576) - 5000;

  // Humidity: RH = (raw_hum / 2^20) * 100  [%]
  // In 0.01%:  RH = raw_hum * 10000 / 1048576
  *hum_cpct   = (int32_t)((uint64_t)raw_hum * 10000 / 1048576);

  return true;
}

// ── NEO-M8N NMEA parser ────────────────────────────────────────────────────
static char    nmea_buf[100];
static uint8_t nmea_pos = 0;

struct GnssData {
  double   lat, lon;
  float    alt_m;
  uint16_t spd_cms;
  uint16_t trk_cdeg;
  uint8_t  fix, sats, hdop10;
  bool     valid;
};
static GnssData gnss = {0};

static double parse_lat_lon(const char *s) {
  double raw = atof(s);
  int deg = (int)(raw / 100);
  return (double)deg + (raw - deg * 100.0) / 60.0;
}

static void parse_nmea(char *sentence) {
  if (strncmp(sentence+1,"GPGGA",5)==0 || strncmp(sentence+1,"GNGGA",5)==0) {
    // $GPGGA,hhmmss.ss,lat,N/S,lon,E/W,fix,sats,hdop,alt,M,...
    char *p = sentence; uint8_t field = 0;
    double lat=0,lon=0; float alt=0; int fix_q=0,sats=0; float hdop=9.9;
    char ns='N', ew='E';
    while (*p) {
      if (*p == ',') {
        field++;
        char *val = p+1;
        switch(field) {
          case 2: lat  = parse_lat_lon(val); break;
          case 3: ns   = *val; break;
          case 4: lon  = parse_lat_lon(val); break;
          case 5: ew   = *val; break;
          case 6: fix_q= atoi(val); break;
          case 7: sats = atoi(val); break;
          case 8: hdop = atof(val); break;
          case 9: alt  = atof(val); break;
        }
      }
      p++;
    }
    if (fix_q > 0) {
      gnss.lat     = (ns=='S') ? -lat : lat;
      gnss.lon     = (ew=='W') ? -lon : lon;
      gnss.alt_m   = alt;
      gnss.fix     = (fix_q == 1) ? 2 : (fix_q >= 2) ? 3 : 1;
      gnss.sats    = (uint8_t)sats;
      gnss.hdop10  = (uint8_t)(hdop * 10);
      gnss.valid   = true;
    } else {
      gnss.valid = false; gnss.fix = 0;
    }
  }
  if (strncmp(sentence+1,"GPRMC",5)==0 || strncmp(sentence+1,"GNRMC",5)==0) {
    char *p = sentence; uint8_t field = 0;
    float spd_kts=0, trk_deg=0; char status='V';
    while (*p) {
      if (*p == ',') {
        field++;
        char *val = p+1;
        switch(field) {
          case 2: status  = *val; break;
          case 7: spd_kts = atof(val); break;
          case 8: trk_deg = atof(val); break;
        }
      }
      p++;
    }
    if (status == 'A') {
      gnss.spd_cms  = (uint16_t)(spd_kts * 51.444f);
      gnss.trk_cdeg = (uint16_t)(trk_deg * 100.0f);
    }
  }
}

static void gnss_process_char(char c) {
  if (c == '$') { nmea_pos = 0; }
  if (nmea_pos < sizeof(nmea_buf)-1) nmea_buf[nmea_pos++] = c;
  if (c == '\n' && nmea_pos > 6) {
    nmea_buf[nmea_pos] = '\0';
    parse_nmea(nmea_buf);
    nmea_pos = 0;
  }
}

// ── UBX GNSS configuration ────────────────────────────────────────────────
static void ubx_send(uint8_t cls, uint8_t id, const uint8_t *pay, uint16_t len) {
  uint8_t ck_a=0, ck_b=0;
  GPS_SERIAL.write(0xB5); GPS_SERIAL.write(0x62);
  GPS_SERIAL.write(cls); ck_a+=cls; ck_b+=ck_a;
  GPS_SERIAL.write(id);  ck_a+=id;  ck_b+=ck_a;
  GPS_SERIAL.write(len & 0xFF);       ck_a+=(len&0xFF);   ck_b+=ck_a;
  GPS_SERIAL.write((len >> 8) & 0xFF);ck_a+=(len>>8)&0xFF;ck_b+=ck_a;
  for (uint16_t i=0;i<len;i++){GPS_SERIAL.write(pay[i]);ck_a+=pay[i];ck_b+=ck_a;}
  GPS_SERIAL.write(ck_a); GPS_SERIAL.write(ck_b);
}

static void gnss_configure() {
  // Set baud 115200
  const uint8_t baud[] = {0x01,0x00,0x00,0x00,0xD0,0x08,0x00,0x00,
                            0x00,0xC2,0x01,0x00,0x07,0x00,0x03,0x00,0x00,0x00,0x00,0x00};
  ubx_send(0x06,0x00,baud,sizeof(baud));
  delay(100);
  GPS_SERIAL.end();
  GPS_SERIAL.begin(GPS_BAUD);
  delay(100);
  // Set 10 Hz
  const uint8_t rate[] = {0x64,0x00,0x01,0x00,0x01,0x00};
  ubx_send(0x06,0x08,rate,sizeof(rate));
  delay(50);
  // Enable GGA + RMC on UART1
  const uint8_t gga[] = {0xF0,0x00,0x01};
  const uint8_t rmc[] = {0xF0,0x04,0x01};
  ubx_send(0x06,0x01,gga,sizeof(gga));
  delay(20);
  ubx_send(0x06,0x01,rmc,sizeof(rmc));
  delay(20);
}

// ── Encoder ISR ───────────────────────────────────────────────────────────
volatile int8_t  enc_delta   = 0;
volatile uint8_t enc_btn     = 0;
static   uint8_t last_clk_st = HIGH;
static   uint8_t last_sw_st  = HIGH;
static   uint32_t sw_dn_ms   = 0;

void enc_clk_isr() {
  uint8_t clk = digitalRead(ENC_CLK_PIN);
  uint8_t dt  = digitalRead(ENC_DT_PIN);
  if (clk != last_clk_st) {
    enc_delta += (dt != clk) ? +1 : -1;
    last_clk_st = clk;
  }
}
void enc_sw_isr() {
  uint8_t sw = digitalRead(ENC_SW_PIN);
  if (sw == LOW && last_sw_st == HIGH) { sw_dn_ms = millis(); }
  else if (sw == HIGH && last_sw_st == LOW) {
    uint32_t held = millis() - sw_dn_ms;
    if      (held >= 600) enc_btn |= 0x02;
    else if (held >= 30)  enc_btn |= 0x01;
  }
  last_sw_st = sw;
}

// ── Frame packer ──────────────────────────────────────────────────────────
static uint16_t frame_seq = 0;

static void pack_frame(uint8_t *f,
                       int32_t press_pa_x100, int32_t temp_cdegc,
                       bool bmp_valid,
                       int8_t enc_delta_val, uint8_t enc_btn_val) {
  uint8_t p = 0;
  auto wu16 = [&](uint16_t v){ f[p++]=v&0xFF; f[p++]=v>>8; };
  auto wi16 = [&](int16_t  v){ wu16((uint16_t)v); };

  f[p++]=SYNC0; f[p++]=SYNC1;
  wu16(frame_seq++);
  uint64_t ts = micros64();
  for (uint8_t i=0;i<8;i++) f[p++]=(ts>>(i*8))&0xFF;

  // GNSS
  double zd=0.0; float zf=0.0f;
  uint8_t *bd;
  bd=(uint8_t*)(gnss.valid?&gnss.lat:&zd); for(uint8_t i=0;i<8;i++) f[p++]=bd[i];
  bd=(uint8_t*)(gnss.valid?&gnss.lon:&zd); for(uint8_t i=0;i<8;i++) f[p++]=bd[i];
  bd=(uint8_t*)(gnss.valid?&gnss.alt_m:&zf);for(uint8_t i=0;i<4;i++) f[p++]=bd[i];
  wu16(gnss.valid ? gnss.spd_cms  : 0);
  wu16(gnss.valid ? gnss.trk_cdeg : 0);

  // Pressure: hPa*10 units
  wu16(bmp_valid ? (uint16_t)(press_pa_x100/1000) : 0);
  // Temperature: 0.01°C units
  wi16(bmp_valid ? (int16_t)(temp_cdegc) : 0);

  f[p++] = gnss.fix;
  f[p++] = gnss.sats;
  f[p++] = gnss.hdop10;
  f[p++] = (uint8_t)enc_delta_val;
  f[p++] = enc_btn_val;
  f[p++] = 0;  // battery placeholder

  f[p] = crc8(f, p); p++;
  while (p < FRAME_SIZE) f[p++] = 0;
}

// ── SETUP ─────────────────────────────────────────────────────────────────
static uint8_t tx_frame[FRAME_SIZE];

void setup() {
  Serial.begin(0);
  uint32_t t0 = millis();
  while (!Serial && millis()-t0 < 2000);

  Wire.begin();
  Wire.setClock(400000UL);

  // LED init
  pinMode(LED_ENC_PIN, OUTPUT); digitalWrite(LED_ENC_PIN, HIGH);
  pinMode(LED_TX_PIN,  OUTPUT); digitalWrite(LED_TX_PIN,  HIGH);

  // Init sensors
  bmp_ok = bmp_init();
  aht_ok = aht_init();

  // GNSS
  GPS_SERIAL.begin(9600);
  delay(200);
  gnss_configure();

  // Encoder
  pinMode(ENC_CLK_PIN, INPUT_PULLUP);
  pinMode(ENC_DT_PIN,  INPUT_PULLUP);
  pinMode(ENC_SW_PIN,  INPUT_PULLUP);
  last_clk_st = digitalRead(ENC_CLK_PIN);
  last_sw_st  = digitalRead(ENC_SW_PIN);
  attachInterrupt(digitalPinToInterrupt(ENC_CLK_PIN), enc_clk_isr, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_SW_PIN),  enc_sw_isr,  CHANGE);

  timer1_init_ovf();

  // Startup flash: 3x = OK, 5x = sensor error
  uint8_t flashes = (bmp_ok) ? 3 : 5;
  for (uint8_t i = 0; i < flashes; i++) {
    digitalWrite(LED_ENC_PIN, LOW); digitalWrite(LED_TX_PIN, LOW);
    delay(80);
    digitalWrite(LED_ENC_PIN, HIGH); digitalWrite(LED_TX_PIN, HIGH);
    delay(80);
  }

  wdt_enable(WDTO_2S);
}

// ── LOOP ──────────────────────────────────────────────────────────────────
static int32_t aht_temp_cdegc = 2000;  // 20.00°C default
static int32_t aht_hum_cpct   = 5000;  // 50.00% default
static bool    aht_fresh       = false;

void loop() {
  static uint32_t last_tx   = 0;
  static uint32_t last_aht  = 0;

  // Drain GNSS continuously
  while (GPS_SERIAL.available())
    gnss_process_char((char)GPS_SERIAL.read());

  // Read AHT20 every 500ms (80ms measurement time — don't do it every frame)
  uint32_t now = millis();
  if (now - last_aht >= 500) {
    last_aht = now;
    int32_t t_new, h_new;
    if (aht_read(&t_new, &h_new)) {
      aht_temp_cdegc = t_new;
      aht_hum_cpct   = h_new;
      aht_fresh      = true;
      aht_ok         = true;
    } else {
      aht_fresh = false;
      if (!aht_ok) aht_ok = aht_init(); // try re-init
    }
  }

  // 10 Hz frame transmission
  now = millis();
  if (now - last_tx >= TX_INTERVAL_MS) {
    last_tx = now;

    // Read BMP280 — use AHT20 temp if available for better compensation
    int32_t press_pa_x100 = 0, temp_cdegc = 0;
    if (bmp_ok) {
      bmp_read(&press_pa_x100, &temp_cdegc, aht_temp_cdegc, aht_fresh);
    } else {
      bmp_ok = bmp_init();
    }

    // Use AHT20 temperature in frame if available (more accurate)
    int32_t frame_temp = aht_fresh ? aht_temp_cdegc : temp_cdegc;

    // Read encoder atomically
    cli();
    int8_t  delta_now = enc_delta; enc_delta = 0;
    uint8_t btn_now   = enc_btn;   enc_btn   = 0;
    sei();

    // LED feedback
    if (delta_now != 0) blink_trigger(blink_enc, 1);
    if (btn_now & 0x01) blink_trigger(blink_enc, 3);
    if (btn_now & 0x02) blink_trigger(blink_enc, 5);

    // TX LED steady on = transmitting
    digitalWrite(LED_TX_PIN, Serial ? LOW : HIGH);

    pack_frame(tx_frame, press_pa_x100, frame_temp, bmp_ok, delta_now, btn_now);
    Serial.write(tx_frame, FRAME_SIZE);
  }

  blink_update(blink_enc);
  wdt_reset();
}
