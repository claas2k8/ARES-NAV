"""
ARES-NAV — Audio Warning System
Revision 3.1  |  Duwald Systems  |  March 2026

Provides voice callouts and warning tones for:
  - Gear check reminder (altitude-triggered)
  - No airport in glide range
  - Airport leaving glide range
  - CAUTION tone (any fault)

Hardware-agnostic: uses pygame.mixer as audio backend.
Audio output device is selected via config.json (device index or name).
Falls back to system default if no device configured.

Language: selectable per aircraft profile (de / en).
Falls back to English if a file is missing in the selected language.

Audio files are WAV (preferred) or MP3.
Searched in: /boot/firmware/ares-nav/audio/<lang>/
Fallback:    ./audio/<lang>/

To generate real TTS files on the Pi (requires internet):
    python3 gen_audio.py --lang de --lang en
"""

import os
import time
import math
import threading
import logging
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum, auto

log = logging.getLogger("ARES-NAV.audio")

# ── Try importing pygame mixer ────────────────────────────────────────────────
try:
    import pygame
    _PYGAME_OK = True
except ImportError:
    _PYGAME_OK = False
    log.warning("pygame not available — audio disabled")

# ── Callout identifiers ───────────────────────────────────────────────────────
class Callout(Enum):
    CAUTION              = "caution"
    GEAR_CHECK           = "gear_check"
    AIRPORT_LEAVING      = "airport_leaving_range"
    NO_AIRPORT_IN_RANGE  = "no_airport_in_range"

# ── Callout trigger conditions ────────────────────────────────────────────────
# Each entry: (callout, min_repeat_interval_seconds)
# min_repeat_interval prevents the same callout from being spammed
CALLOUT_CONFIG = {
    Callout.CAUTION:             30,   # at most once per 30s
    Callout.GEAR_CHECK:         120,   # at most once per 2 minutes
    Callout.AIRPORT_LEAVING:     60,   # at most once per minute
    Callout.NO_AIRPORT_IN_RANGE: 90,   # at most once per 90s
}

# ── Audio search paths ────────────────────────────────────────────────────────
AUDIO_DIRS = [
    "/boot/firmware/ares-nav/audio",
    "/boot/ares-nav/audio",
    os.path.join(os.path.dirname(__file__), "audio"),
    "./audio",
]


def _find_audio(callout: Callout, lang: str) -> Optional[str]:
    """Find audio file for callout in given language. Falls back to 'en'."""
    for search_lang in [lang, "en"]:
        for d in AUDIO_DIRS:
            for ext in ["wav", "mp3"]:
                path = os.path.join(d, search_lang, f"{callout.value}.{ext}")
                if os.path.exists(path):
                    return path
    return None


# ── Audio system ──────────────────────────────────────────────────────────────
class AudioSystem:
    """
    Thread-safe audio warning system.
    Designed to run as a background service — call trigger() from any thread.

    Usage:
        audio = AudioSystem(lang="de", device_index=None)
        audio.start()
        audio.trigger(Callout.GEAR_CHECK)
        audio.stop()
    """

    def __init__(self, lang: str = "en", device_index: Optional[int] = None,
                 volume: float = 0.85):
        self.lang         = lang
        self.device_index = device_index
        self.volume       = max(0.0, min(1.0, volume))
        self._lock        = threading.Lock()
        self._queue       = []           # list of Callout
        self._last_played = {}           # Callout → timestamp
        self._thread      = None
        self._running     = False
        self._ready       = False
        self._cache       = {}           # path → pygame.mixer.Sound

    def start(self):
        """Initialise pygame mixer and start playback thread."""
        if not _PYGAME_OK:
            log.warning("pygame unavailable — AudioSystem disabled")
            return
        try:
            if self.device_index is not None:
                os.environ["SDL_AUDIODRIVER"] = "alsa"
                # For specific device: set AUDIODEV env var before init
                # e.g. "hw:1,0" for USB soundcard
            pygame.mixer.pre_init(frequency=44100, size=-16, channels=1, buffer=512)
            pygame.mixer.init()
            pygame.mixer.set_num_channels(4)
            self._ready   = True
            self._running = True
            self._thread  = threading.Thread(target=self._run, daemon=True,
                                             name="ARES-audio")
            self._thread.start()
            log.info(f"AudioSystem started — lang={self.lang} "
                     f"vol={self.volume:.0%} device={self.device_index}")
        except Exception as e:
            log.error(f"AudioSystem init failed: {e}")
            self._ready = False

    def stop(self):
        self._running = False
        if _PYGAME_OK and self._ready:
            pygame.mixer.quit()

    def trigger(self, callout: Callout):
        """
        Request a callout. Thread-safe.
        Callout is ignored if the same callout was played within its
        min_repeat_interval, or if a higher-priority callout is already queued.
        """
        if not self._ready:
            return
        now = time.monotonic()
        min_interval = CALLOUT_CONFIG.get(callout, 60)

        with self._lock:
            last = self._last_played.get(callout, 0)
            if now - last < min_interval:
                return   # too soon to repeat
            if callout not in self._queue:
                # Insert CAUTION at front (highest priority), others at back
                if callout == Callout.CAUTION:
                    self._queue.insert(0, callout)
                else:
                    self._queue.append(callout)

    def _run(self):
        while self._running:
            callout = None
            with self._lock:
                if self._queue:
                    callout = self._queue.pop(0)

            if callout:
                self._play(callout)
            else:
                time.sleep(0.05)

    def _play(self, callout: Callout):
        path = _find_audio(callout, self.lang)
        if not path:
            log.warning(f"Audio file not found for {callout.value} [{self.lang}]")
            return
        try:
            if path not in self._cache:
                self._cache[path] = pygame.mixer.Sound(path)
            sound = self._cache[path]
            sound.set_volume(self.volume)
            channel = sound.play()
            # Wait for playback to finish before next callout
            if channel:
                while channel.get_busy():
                    time.sleep(0.02)
            with self._lock:
                self._last_played[callout] = time.monotonic()
            log.debug(f"Played: {callout.value} ({self.lang}) — {path}")
        except Exception as e:
            log.error(f"Playback error [{callout.value}]: {e}")

    @property
    def ready(self) -> bool:
        return self._ready


# ── Glide range monitor ───────────────────────────────────────────────────────
class GlideRangeMonitor:
    """
    Monitors nearest airport distance vs current glide range.
    Triggers audio callouts when airports enter/leave glide range.

    Glide range = (altitude_agl_ft / 100) * best_glide_nm_per_1000ft
    For a typical sailplane with L/D 30: 1000ft → ~5nm range

    Requires:
      - Current altitude AGL (ft)
      - Best glide ratio from aircraft profile
      - Nearest airport distance (nm) from nav database

    Call update() at 1 Hz from the main loop.
    """

    def __init__(self, audio: AudioSystem, glide_ratio: float = 30.0,
                 safety_margin: float = 1.15):
        """
        glide_ratio:    L/D ratio of aircraft (e.g. 30 for ASK-21)
        safety_margin:  multiply required distance by this factor (15% buffer)
        """
        self.audio          = audio
        self.glide_ratio    = glide_ratio
        self.safety_margin  = safety_margin

        self._in_range_prev  = None   # was there an airport in range last cycle?
        self._leaving_warned = set()  # airport IDs that have triggered leaving warning

    def update(self, altitude_agl_ft: float,
               nearest_airport_nm: Optional[float],
               nearest_airport_id: Optional[str] = None):
        """
        Call at ~1 Hz.
        altitude_agl_ft:    current altitude above ground level in feet
        nearest_airport_nm: distance to nearest landable airport in nm (None if unknown)
        nearest_airport_id: identifier string for the airport (for deduplication)
        """
        if altitude_agl_ft < 100:
            return   # on ground — no callouts

        # Glide range in nm: (alt_ft / 1000) * (L/D * 1000ft/nm_conversion)
        # L/D of 30 means 30ft forward per 1ft down
        # 30ft/ft * 1ft_down = 30ft forward = 30/6076 nm ≈ 0.00494 nm per ft
        glide_nm = altitude_agl_ft * (self.glide_ratio / 6076.0)
        safe_range_nm = glide_nm / self.safety_margin

        if nearest_airport_nm is None:
            # No nav data available
            in_range = False
        else:
            in_range = nearest_airport_nm <= safe_range_nm

        # State transitions → callouts
        if self._in_range_prev is None:
            # First update — just set state, no callout
            pass
        elif self._in_range_prev and not in_range:
            # Had an airport in range, now we don't → LEAVING RANGE
            self.audio.trigger(Callout.AIRPORT_LEAVING)
        elif not self._in_range_prev and not in_range:
            # Never had airport in range → periodic NO AIRPORT warning
            self.audio.trigger(Callout.NO_AIRPORT_IN_RANGE)

        self._in_range_prev = in_range

    def glide_range_nm(self, altitude_agl_ft: float) -> float:
        """Return current glide range in nm (without safety margin)."""
        return altitude_agl_ft * (self.glide_ratio / 6076.0)


# ── Gear check monitor ────────────────────────────────────────────────────────
class GearCheckMonitor:
    """
    Triggers gear check callout when descending through configured altitude.
    Only relevant for motorized aircraft — disabled for sailplanes.

    Default trigger: descending through 1000ft AGL.
    Resets when climbing back above 1500ft AGL (hysteresis).
    """

    def __init__(self, audio: AudioSystem,
                 trigger_alt_ft: float = 1000.0,
                 reset_alt_ft:   float = 1500.0):
        self.audio          = audio
        self.trigger_alt    = trigger_alt_ft
        self.reset_alt      = reset_alt_ft
        self._triggered     = False
        self._vs_ft_min     = 0.0

    def update(self, altitude_agl_ft: float, vertical_speed_fpm: float):
        """Call at ~1 Hz."""
        self._vs_ft_min = vertical_speed_fpm

        if altitude_agl_ft > self.reset_alt:
            self._triggered = False   # reset hysteresis

        if (not self._triggered
                and altitude_agl_ft <= self.trigger_alt
                and vertical_speed_fpm < -100):   # only when descending
            self.audio.trigger(Callout.GEAR_CHECK)
            self._triggered = True


# ── Master audio manager ──────────────────────────────────────────────────────
class AresNavAudio:
    """
    Top-level audio manager — owns AudioSystem, GlideRangeMonitor, GearCheckMonitor.
    Initialise once from the main application. Call update() at 1 Hz.

    Example:
        audio_mgr = AresNavAudio.from_profile(profile, config)
        audio_mgr.start()

        # In main loop (1 Hz):
        audio_mgr.update(state)

        # On any fault:
        audio_mgr.caution()
    """

    def __init__(self, lang: str = "en",
                 glide_ratio: float = 30.0,
                 aircraft_type: str = "sailplane",
                 gear_trigger_ft: float = 1000.0,
                 device_index: Optional[int] = None,
                 volume: float = 0.85):

        self.aircraft_type = aircraft_type
        self._audio  = AudioSystem(lang=lang, device_index=device_index,
                                   volume=volume)
        self._glide  = GlideRangeMonitor(self._audio, glide_ratio=glide_ratio)
        self._gear   = GearCheckMonitor(self._audio,
                                        trigger_alt_ft=gear_trigger_ft) \
                       if aircraft_type == "motorized" else None

    @classmethod
    def from_profile(cls, profile: dict, config: dict) -> "AresNavAudio":
        """Construct from aircraft profile and system config dicts."""
        lang         = profile.get("audio_lang", config.get("audio_lang", "en"))
        glide_ratio  = profile.get("glide_ratio", 30.0)
        a_type       = profile.get("aircraft_type", "sailplane")
        gear_trigger = profile.get("gear_check_alt_ft", 1000.0)
        device       = config.get("audio_device_index", None)
        volume       = config.get("audio_volume", 0.85)
        return cls(lang=lang, glide_ratio=glide_ratio, aircraft_type=a_type,
                   gear_trigger_ft=gear_trigger, device_index=device,
                   volume=volume)

    def start(self):
        self._audio.start()

    def stop(self):
        self._audio.stop()

    def caution(self):
        """Trigger CAUTION tone immediately — call on any fault."""
        self._audio.trigger(Callout.CAUTION)

    def update(self, state) -> None:
        """
        Call at 1 Hz from main loop.
        state: AresNavState dataclass from simulator.py / EKF output
        """
        if not self._audio.ready:
            return

        # Estimate AGL from altitude and terrain (simplified: use 0 as ground)
        # TODO: replace with SRTM terrain lookup when available
        alt_agl = max(0.0, state.altitude_ft)

        # Glide range monitor
        nearest_nm = getattr(state, 'nearest_airport_nm', None)
        nearest_id = getattr(state, 'nearest_airport_id', None)
        self._glide.update(alt_agl, nearest_nm, nearest_id)

        # Gear check (motorized only)
        if self._gear:
            self._gear.update(alt_agl, state.vertical_speed_fpm)

        # CAUTION on master caution flag
        if getattr(state, 'master_caution', False):
            self._audio.trigger(Callout.CAUTION)

    @property
    def ready(self) -> bool:
        return self._audio.ready
