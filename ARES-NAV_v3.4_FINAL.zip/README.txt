ARES-NAV  Rev. 3.4  |  Duwald Systems  |  March 2026
⚠ EXPERIMENTAL

2-MCU SETUP:
  Pro Micro #1 → firmware/MCU1_IMU/MCU1_IMU.ino       (3x MPU-9250 SPI)
  Pro Micro #2 → firmware/MCU2_Peripheral/             (BMP280+AHT20+Encoder)

START:
  python3 app/main.py --profile motorglider    # full hardware
  python3 app/main.py --sim                    # simulator, no hardware

DEPS (Pi, once):
  sudo raspi-config → Advanced → W1 (X11) → Reboot
  sudo apt install -y python3-pyqt5 python3-numpy python3-serial python3-pygame
