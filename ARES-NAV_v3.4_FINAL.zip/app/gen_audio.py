"""
ARES-NAV — Audio Callout Generator
Revision 3.1  |  Duwald Systems  |  March 2026

Run this script ON THE Pi with internet access to generate real TTS callout files.
Requires: pip install gtts

Usage:
    python3 gen_audio.py                  # generate both de and en
    python3 gen_audio.py --lang de        # German only
    python3 gen_audio.py --lang en        # English only
    python3 gen_audio.py --out /custom/path

Output: /boot/firmware/ares-nav/audio/<lang>/<callout>.mp3
"""

import os
import sys
import argparse

CALLOUTS = {
    "de": {
        "caution":              "Achtung",
        "gear_check":           "Fahrwerk kontrollieren",
        "airport_leaving_range":"Achtung, Flugplatz verlässt Gleitreichweite",
        "no_airport_in_range":  "Kein Flugplatz in Gleitreichweite",
    },
    "en": {
        "caution":              "Caution",
        "gear_check":           "Check gear",
        "airport_leaving_range":"Warning, airport is leaving glide range",
        "no_airport_in_range":  "No airport in glide range",
    }
}

DEFAULT_OUT = "/boot/firmware/ares-nav/audio"


def generate(lang: str, out_dir: str):
    try:
        from gtts import gTTS
    except ImportError:
        print("ERROR: gtts not installed. Run: pip install gtts")
        sys.exit(1)

    lang_dir = os.path.join(out_dir, lang)
    os.makedirs(lang_dir, exist_ok=True)

    phrases = CALLOUTS.get(lang)
    if not phrases:
        print(f"ERROR: Unknown language '{lang}'. Available: {list(CALLOUTS.keys())}")
        sys.exit(1)

    for key, text in phrases.items():
        path = os.path.join(lang_dir, f"{key}.mp3")
        print(f"  Generating [{lang}] {key}: \"{text}\" ...", end=" ", flush=True)
        try:
            tts = gTTS(text=text, lang=lang, slow=False)
            tts.save(path)
            size = os.path.getsize(path)
            print(f"OK ({size} bytes) → {path}")
        except Exception as e:
            print(f"FAILED: {e}")


def main():
    parser = argparse.ArgumentParser(description="ARES-NAV Audio Callout Generator")
    parser.add_argument("--lang", action="append", default=None,
                        choices=["de", "en"], help="Language to generate (repeatable)")
    parser.add_argument("--out", default=DEFAULT_OUT,
                        help=f"Output directory (default: {DEFAULT_OUT})")
    args = parser.parse_args()

    langs = args.lang or ["de", "en"]

    print(f"ARES-NAV Audio Generator — output: {args.out}")
    print(f"Languages: {langs}\n")

    for lang in langs:
        print(f"[{lang.upper()}]")
        generate(lang, args.out)
        print()

    print("Done. Restart ARES-NAV to load new audio files.")


if __name__ == "__main__":
    main()
