/*
 * ARES-NAV — MCU 2 Peripheral Controller
 * Hardware: Arduino Pro Micro (ATmega32U4 @ 16 MHz)
 * Role:     u-blox NEO-M8N GNSS (UART 115200),
 *           Bosch BMP280 barometer (I2C),
 *           Rotary encoder with push-button (GPIO interrupts),
 *           48-byte binary frames over USB CDC at 10 Hz.
 *
 * USB Serial Number: ARESNAV-PERI  (set in platform config)
 * Pi device symlink: /dev/aresnav-peri  (via udev rule)
 *
 * Frame format: 48 bytes — ARES-NAV Spec Rev. 2.6, Section 13
 * Revision: 2.6  |  Duwald Systems  |  March 2026
 */

#include <Wire.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>

// ── Pin assignments ────────────────────────────────────────────────────────
// NEO-M8N: hardware UART on Serial1 (TX=1 / RX=0 on Pro Micro)
#define GPS_SERIAL   Serial1
#define GPS_BAUD     115200UL

// BMP280 I2C address — 0x76 (SDO=GND, default) or 0x77 (SDO=VCC)
#define BMP280_ADDR  0x76

// Rotary encoder
#define ENC_CLK_PIN   7    // must support PCINT or INT
#define ENC_DT_PIN    6
#define ENC_SW_PIN    5    // push button

// ── Frame constants ────────────────────────────────────────────────────────
#define FRAME_SIZE  48
#define SYNC0       0xBB
#define SYNC1       0x66

// ── Transmit rate ──────────────────────────────────────────────────────────
#define TX_INTERVAL_MS  100   // 10 Hz

// ─────────────────────────────────────────────────────────────────────────────
// uint64 timestamp via Timer1 overflow (same logic as MCU 1)
// ─────────────────────────────────────────────────────────────────────────────
volatile uint32_t t1_ovf = 0;

ISR(TIMER1_OVF_vect) {
  t1_ovf++;
}

uint64_t micros64(void) {
  uint8_t sreg = SREG;
  cli();
  uint32_t ovf  = t1_ovf;
  uint32_t tcnt = TCNT1;
  SREG = sreg;
  return ((uint64_t)ovf << 15) | (tcnt >> 1);
}

static void timer1_init_ovf() {
  cli();
  TCCR1A = 0;
  TCCR1B = (1 << CS11); // normal mode, prescaler 8 (no CTC — just OVF)
  TCNT1  = 0;
  TIMSK1 = (1 << TOIE1);
  sei();
}

// ─────────────────────────────────────────────────────────────────────────────
// BMP280 driver (minimal, no external library)
// ─────────────────────────────────────────────────────────────────────────────
struct Bmp280Cal {
  uint16_t T1; int16_t T2, T3;
  uint16_t P1; int16_t P2, P3, P4, P5, P6, P7, P8, P9;
};
static Bmp280Cal bmp_cal;
static bool bmp_ok = false;

static uint8_t bmp_rb(uint8_t reg) {
  Wire.beginTransmission(BMP280_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)1);
  return Wire.available() ? Wire.read() : 0;
}
static void bmp_wb(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(BMP280_ADDR);
  Wire.write(reg); Wire.write(val);
  Wire.endTransmission();
}
static uint16_t bmp_r16u(uint8_t reg) {
  Wire.beginTransmission(BMP280_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)2);
  if (Wire.available() < 2) return 0;
  uint8_t lo = Wire.read(), hi = Wire.read();
  return (uint16_t)(hi << 8) | lo;
}
static int16_t bmp_r16s(uint8_t reg) { return (int16_t)bmp_r16u(reg); }

static bool bmp_init() {
  uint8_t id = bmp_rb(0xD0);
  if (id != 0x60 && id != 0x58) return false; // 0x60=BMP280, 0x58=BMP280 variant

  // Read calibration (0x88..0x9F)
  bmp_cal.T1 = bmp_r16u(0x88); bmp_cal.T2 = bmp_r16s(0x8A); bmp_cal.T3 = bmp_r16s(0x8C);
  bmp_cal.P1 = bmp_r16u(0x8E); bmp_cal.P2 = bmp_r16s(0x90); bmp_cal.P3 = bmp_r16s(0x92);
  bmp_cal.P4 = bmp_r16s(0x94); bmp_cal.P5 = bmp_r16s(0x96); bmp_cal.P6 = bmp_r16s(0x98);
  bmp_cal.P7 = bmp_r16s(0x9A); bmp_cal.P8 = bmp_r16s(0x9C); bmp_cal.P9 = bmp_r16s(0x9E);

  // Config: oversampling x4 temp + x4 pressure, normal mode, IIR filter x2
  // ctrl_meas: osrs_t=011(x4), osrs_p=011(x4), mode=11(normal) → 0b01101111 = 0x6F
  // config:    t_sb=000(0.5ms), filter=010(x2), spi3w_en=0       → 0b00001000 = 0x08
  bmp_wb(0xF5, 0x08); // config first
  bmp_wb(0xF4, 0x6F); // ctrl_meas — starts measurements
  delay(10);
  return true;
}

// Returns pressure in Pa*100 (i.e. 101325.00 Pa = 10132500) and temp in 0.01°C
// Uses BMP280 datasheet compensation formulas
static void bmp_read(int32_t *press_pa_x100, int32_t *temp_cdegc) {
  // Read raw values (3 bytes each, 20-bit)
  Wire.beginTransmission(BMP280_ADDR);
  Wire.write(0xF7); // press_msb
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)BMP280_ADDR, (uint8_t)6);
  if (Wire.available() < 6) { *press_pa_x100 = 0; *temp_cdegc = 0; return; }

  int32_t adc_P = ((int32_t)Wire.read() << 12) | ((int32_t)Wire.read() << 4) | (Wire.read() >> 4);
  int32_t adc_T = ((int32_t)Wire.read() << 12) | ((int32_t)Wire.read() << 4) | (Wire.read() >> 4);

  // Temperature compensation
  int32_t var1 = (((adc_T >> 3) - ((int32_t)bmp_cal.T1 << 1)) * bmp_cal.T2) >> 11;
  int32_t var2 = (((((adc_T >> 4) - (int32_t)bmp_cal.T1) *
                    ((adc_T >> 4) - (int32_t)bmp_cal.T1)) >> 12) * bmp_cal.T3) >> 14;
  int32_t t_fine = var1 + var2;
  int32_t T = (t_fine * 5 + 128) >> 8; // in 0.01°C units? No — BMP280 returns 0.01°C directly
  *temp_cdegc = T; // 0.01 °C units (e.g. 2145 = 21.45°C)

  // Pressure compensation (64-bit intermediate — use int64)
  int64_t v1p = (int64_t)t_fine - 128000;
  int64_t v2p = v1p * v1p * (int64_t)bmp_cal.P6;
  v2p += ((v1p * (int64_t)bmp_cal.P5) << 17);
  v2p += ((int64_t)bmp_cal.P4 << 35);
  v1p  = ((v1p * v1p * (int64_t)bmp_cal.P3) >> 8) + ((v1p * (int64_t)bmp_cal.P2) << 12);
  v1p  = (((int64_t)1 << 47) + v1p) * (int64_t)bmp_cal.P1 >> 33;
  if (v1p == 0) { *press_pa_x100 = 0; return; }
  int64_t p = 1048576 - adc_P;
  p = (((p << 31) - v2p) * 3125) / v1p;
  v1p = ((int64_t)bmp_cal.P9 * (p >> 13) * (p >> 13)) >> 25;
  v2p = ((int64_t)bmp_cal.P8 * p) >> 19;
  p = ((p + v1p + v2p) >> 8) + ((int64_t)bmp_cal.P7 << 4);
  // p is now in Pa * 256. Convert to Pa * 100:
  *press_pa_x100 = (int32_t)((p * 100) >> 8);
}

// ─────────────────────────────────────────────────────────────────────────────
// NEO-M8N NMEA parser (minimal — GGA and RMC only)
// ─────────────────────────────────────────────────────────────────────────────
static char  nmea_buf[100];
static uint8_t nmea_pos = 0;

struct GnssData {
  double   lat;       // degrees, +N -S
  double   lon;       // degrees, +E -W
  float    alt_m;     // altitude MSL metres
  uint16_t spd_cms;   // ground speed cm/s
  uint16_t trk_cdeg;  // ground track 0.01° (0–35999)
  uint8_t  fix;       // 0=none 1=2D 2=3D 3=3D+SBAS
  uint8_t  sats;
  uint8_t  hdop10;    // HDOP * 10 (e.g. 12 = HDOP 1.2)
  bool     valid;
};
static GnssData gnss = {0};

// Parse double from NMEA field (e.g. "4807.038" → 48.1173°)
static double parse_lat_lon(const char *s) {
  // Format: DDDMM.MMMM or DDMM.MMMM
  double raw = atof(s);
  int deg = (int)(raw / 100);
  double min = raw - (double)(deg * 100);
  return (double)deg + min / 60.0;
}

static void parse_nmea(char *sentence) {
  // Minimal GGA parser: $GPGGA or $GNGGA
  if (strncmp(sentence + 1, "GPGGA", 5) == 0 ||
      strncmp(sentence + 1, "GNGGA", 5) == 0) {
    // $xxGGA,hhmmss.ss,lat,N/S,lon,E/W,fix,sats,hdop,alt,M,...
    char *tok = strtok(sentence, ",");
    char *fields[15];
    uint8_t n = 0;
    while (tok && n < 15) { fields[n++] = tok; tok = strtok(NULL, ","); }
    if (n < 10) return;

    gnss.fix  = (uint8_t)atoi(fields[6]);
    gnss.sats = (uint8_t)atoi(fields[7]);
    gnss.hdop10 = (uint8_t)(atof(fields[8]) * 10.0f);
    gnss.alt_m  = (float)atof(fields[9]);

    if (gnss.fix > 0 && strlen(fields[2]) > 3) {
      gnss.lat = parse_lat_lon(fields[2]);
      if (fields[3][0] == 'S') gnss.lat = -gnss.lat;
      gnss.lon = parse_lat_lon(fields[4]);
      if (fields[5][0] == 'W') gnss.lon = -gnss.lon;
      gnss.valid = true;
    }
    return;
  }

  // Minimal RMC parser: $GPRMC or $GNRMC
  if (strncmp(sentence + 1, "GPRMC", 5) == 0 ||
      strncmp(sentence + 1, "GNRMC", 5) == 0) {
    // $xxRMC,time,A/V,lat,N/S,lon,E/W,speed_knots,track,date,...
    char *tok = strtok(sentence, ",");
    char *fields[12];
    uint8_t n = 0;
    while (tok && n < 12) { fields[n++] = tok; tok = strtok(NULL, ","); }
    if (n < 9) return;

    if (fields[2][0] == 'A') { // Active (valid fix)
      float spd_kts = (float)atof(fields[7]);
      gnss.spd_cms  = (uint16_t)(spd_kts * 51.444f); // knots → cm/s
      float trk     = (float)atof(fields[8]);
      gnss.trk_cdeg = (uint16_t)(trk * 100.0f);       // degrees → 0.01° units
    }
  }
}

static void gnss_process_char(char c) {
  if (c == '$') {
    nmea_pos = 0;
  }
  if (nmea_pos < sizeof(nmea_buf) - 1) {
    nmea_buf[nmea_pos++] = c;
    if (c == '\n' && nmea_pos > 5) {
      nmea_buf[nmea_pos] = '\0';
      // Strip checksum (*XX\r\n) before parsing
      char *star = strchr(nmea_buf, '*');
      if (star) *star = '\0';
      parse_nmea(nmea_buf);
      nmea_pos = 0;
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// UBX config: set NEO-M8N to 115200 baud + 10 Hz on Serial1
// ─────────────────────────────────────────────────────────────────────────────
static void ubx_send(const uint8_t *msg, uint8_t len) {
  GPS_SERIAL.write(msg, len);
}

static void gnss_configure() {
  // UBX-CFG-PRT: set UART1 to 115200, NMEA in+out
  static const uint8_t cfg_prt[] = {
    0xB5, 0x62, 0x06, 0x00, 0x14, 0x00,
    0x01,             // portID = UART1
    0x00,             // reserved
    0x00, 0x00,       // txReady
    0xD0, 0x08, 0x00, 0x00, // mode: 8N1
    0x00, 0xC2, 0x01, 0x00, // baudRate: 115200 LE
    0x07, 0x00,       // inProtoMask: NMEA+UBX+RTCM
    0x03, 0x00,       // outProtoMask: NMEA+UBX
    0x00, 0x00,       // flags
    0x00, 0x00,       // reserved
    0xBC, 0x5E        // checksum (precomputed)
  };
  ubx_send(cfg_prt, sizeof(cfg_prt));
  delay(100);
  GPS_SERIAL.begin(GPS_BAUD); // switch to 115200

  // UBX-CFG-RATE: 10 Hz navigation rate (measRate=100ms, navRate=1, timeRef=UTC)
  static const uint8_t cfg_rate[] = {
    0xB5, 0x62, 0x06, 0x08, 0x06, 0x00,
    0x64, 0x00,  // measRate 100 ms LE
    0x01, 0x00,  // navRate  1
    0x01, 0x00,  // timeRef  UTC
    0x7A, 0x12  // checksum
  };
  ubx_send(cfg_rate, sizeof(cfg_rate));
  delay(50);
}

// ─────────────────────────────────────────────────────────────────────────────
// Rotary encoder — interrupt-driven
// ─────────────────────────────────────────────────────────────────────────────
volatile int8_t  enc_delta   = 0;   // accumulated ticks since last frame
volatile uint8_t enc_btn     = 0;   // bit 0 = short press, bit 1 = long press
volatile bool    btn_pressed = false;
volatile uint32_t btn_press_ms = 0;
static   uint8_t last_clk_state;

// Encoder CLK interrupt
void enc_clk_isr() {
  uint8_t clk = digitalRead(ENC_CLK_PIN);
  uint8_t dt  = digitalRead(ENC_DT_PIN);
  if (clk != last_clk_state) {
    enc_delta += (clk == dt) ? +1 : -1;
    last_clk_state = clk;
  }
}

// Button pin change — detect press and release, classify short/long
void enc_sw_isr() {
  uint8_t sw = digitalRead(ENC_SW_PIN);
  if (sw == LOW && !btn_pressed) {
    btn_pressed   = true;
    btn_press_ms  = millis();
  } else if (sw == HIGH && btn_pressed) {
    btn_pressed = false;
    uint32_t dur = millis() - btn_press_ms;
    if (dur > 600) {
      enc_btn |= 0x02; // long press
    } else if (dur > 30) {
      enc_btn |= 0x01; // short press
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CRC-8 (same poly as MCU 1)
// ─────────────────────────────────────────────────────────────────────────────
static uint8_t crc8(const uint8_t *d, uint8_t n) {
  uint8_t c = 0;
  for (uint8_t i = 0; i < n; i++) {
    c ^= d[i];
    for (uint8_t b = 0; b < 8; b++)
      c = (c & 0x80) ? (c << 1) ^ 0x07 : (c << 1);
  }
  return c;
}

// ─────────────────────────────────────────────────────────────────────────────
// Pack 48-byte peripheral frame
// Byte layout (ARES-NAV Spec Rev. 2.6, Section 13):
//  0–1   sync (0xBB 0x66)
//  2–3   sequence (uint16 LE)
//  4–11  timestamp (uint64 LE)
//  12–19 latitude (double LE)
//  20–27 longitude (double LE)
//  28–31 GNSS altitude m (float LE)
//  32–33 ground speed cm/s (uint16 LE)
//  34–35 ground track 0.01° (uint16 LE)
//  36–37 pressure 0.01 hPa (uint16 LE)  [Pa*100 / 100 * 100 = Pa, then /100 for hPa ... see below]
//  38–39 temperature 0.01°C (int16 LE)
//  40    GNSS fix type (uint8)
//  41    satellite count (uint8)
//  42    HDOP x10 (uint8)
//  43    encoder delta (int8)
//  44    button flags (uint8)
//  45    battery voltage (uint8) [0.05V steps, 0=unknown]
//  46    CRC8 over bytes 0–45
//  47    padding 0x00
// ─────────────────────────────────────────────────────────────────────────────
static uint16_t frame_seq = 0;

static void write_u16le(uint8_t *f, uint8_t &p, uint16_t v) {
  f[p++] = v & 0xFF; f[p++] = v >> 8;
}
static void write_i16le(uint8_t *f, uint8_t &p, int16_t v) {
  write_u16le(f, p, (uint16_t)v);
}
static void write_u64le(uint8_t *f, uint8_t &p, uint64_t v) {
  for (uint8_t i = 0; i < 8; i++) f[p++] = (v >> (i * 8)) & 0xFF;
}
static void write_double_le(uint8_t *f, uint8_t &p, double v) {
  uint8_t *b = (uint8_t *)&v;
  for (uint8_t i = 0; i < 8; i++) f[p++] = b[i];
}
static void write_float_le(uint8_t *f, uint8_t &p, float v) {
  uint8_t *b = (uint8_t *)&v;
  for (uint8_t i = 0; i < 4; i++) f[p++] = b[i];
}

static void pack_frame(uint8_t *f,
                       int32_t press_pa_x100, int32_t temp_cdegc,
                       bool bmp_valid) {
  uint8_t p = 0;
  uint64_t ts = micros64();

  f[p++] = SYNC0;
  f[p++] = SYNC1;
  write_u16le(f, p, frame_seq++);
  write_u64le(f, p, ts);

  // GNSS fields
  write_double_le(f, p, gnss.valid ? gnss.lat : 0.0);
  write_double_le(f, p, gnss.valid ? gnss.lon : 0.0);
  write_float_le (f, p, gnss.valid ? gnss.alt_m : 0.0f);
  write_u16le(f, p, gnss.valid ? gnss.spd_cms  : 0);
  write_u16le(f, p, gnss.valid ? gnss.trk_cdeg : 0);

  // Pressure in 0.01 hPa units:
  // press_pa_x100 is Pa * 100, so Pa = press_pa_x100 / 100
  // hPa = Pa / 100, so 0.01 hPa = hPa * 100 = Pa
  // → 0.01 hPa value = press_pa_x100 / 100  (just drop the last 2 digits... no)
  // Actually: press_pa_x100 = pressure_Pa * 100
  // We want uint16 in units of 0.01 hPa = 1 Pa
  // So: value = press_pa_x100 / 100 (= Pa), stored as uint16
  // 101325 Pa = 1013.25 hPa → stored as 10133 (0.01 hPa units would be 101325, overflow uint16)
  // Fix: store as 0.1 hPa units: value = press_pa_x100 / 1000  → 1013 for 1013.25 hPa
  // Or store as Pa directly: uint16 overflows at 65535 Pa = 655 hPa (too low)
  // Best: store as hPa * 10 in uint16 (range 0–6553.5 hPa, more than enough)
  // 101325 Pa → 1013.25 hPa → stored as 10132 (hPa * 10, truncated)
  // Pi decodes: pressure_hpa = frame_value / 10.0
  uint16_t press_val = bmp_valid ? (uint16_t)(press_pa_x100 / 1000) : 0; // hPa * 10
  write_u16le(f, p, press_val);

  // Temperature: 0.01°C units — temp_cdegc is already in 0.01°C from BMP280 compensation
  // But int32_t, clamp to int16 range
  int16_t temp_val = bmp_valid ? (int16_t)(temp_cdegc) : 0;
  write_i16le(f, p, temp_val);

  f[p++] = gnss.fix;
  f[p++] = gnss.sats;
  f[p++] = gnss.hdop10;

  // Encoder: read atomically
  cli();
  int8_t delta = enc_delta; enc_delta = 0;
  uint8_t btn  = enc_btn;   enc_btn   = 0;
  sei();
  f[p++] = (uint8_t)delta;
  f[p++] = btn;

  // Battery voltage placeholder (0 = unknown, future: ADC from BMS sense pin)
  f[p++] = 0;

  // Fault flags
  uint8_t faults = 0;
  if (!gnss.valid && gnss.fix == 0) faults |= 0x01;
  if (!bmp_valid) faults |= 0x02;
  // (Not used in this frame — fault byte removed to fit 48 bytes; Pi infers from fix=0)

  // CRC over bytes 0..(p-1) — p should be 46 here
  f[p] = crc8(f, p);
  p++;

  // Pad
  while (p < FRAME_SIZE) f[p++] = 0x00;
}

// ─────────────────────────────────────────────────────────────────────────────
// SETUP
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(0);  // USB CDC to Pi
  uint32_t t0 = millis();
  while (!Serial && (millis() - t0) < 2000);

  // I2C for BMP280
  Wire.begin();
  Wire.setClock(400000UL);

  // BMP280 init
  bmp_ok = bmp_init();

  // GNSS: start at default baud (9600), send config, switch to 115200
  GPS_SERIAL.begin(9600);
  delay(200);
  gnss_configure(); // sends UBX, restarts GPS_SERIAL at 115200

  // Encoder pins with internal pull-ups
  pinMode(ENC_CLK_PIN, INPUT_PULLUP);
  pinMode(ENC_DT_PIN,  INPUT_PULLUP);
  pinMode(ENC_SW_PIN,  INPUT_PULLUP);
  last_clk_state = digitalRead(ENC_CLK_PIN);

  // Attach encoder interrupts
  // On ATmega32U4, INT2 = pin 0, INT3 = pin 1, INT6 = pin 7
  // Use pin 7 (INT6) for CLK and digitalRead polling for DT (acceptable for encoder)
  attachInterrupt(digitalPinToInterrupt(ENC_CLK_PIN), enc_clk_isr, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_SW_PIN),  enc_sw_isr,  CHANGE);

  // Timer1 OVF for uint64 timestamp
  timer1_init_ovf();

  // Hardware watchdog
  wdt_enable(WDTO_2S);
}

// ─────────────────────────────────────────────────────────────────────────────
// LOOP — 10 Hz frame transmission + continuous GNSS parsing
// ─────────────────────────────────────────────────────────────────────────────
static uint8_t tx_frame[FRAME_SIZE];

void loop() {
  static uint32_t last_tx = 0;

  // Drain GPS UART continuously
  while (GPS_SERIAL.available()) {
    gnss_process_char((char)GPS_SERIAL.read());
  }

  // Transmit frame at 10 Hz
  uint32_t now = millis();
  if (now - last_tx >= TX_INTERVAL_MS) {
    last_tx = now;

    // Read BMP280
    int32_t press_pa_x100 = 0, temp_cdegc = 0;
    if (bmp_ok) {
      bmp_read(&press_pa_x100, &temp_cdegc);
    } else {
      // Try to re-init (power glitch recovery)
      bmp_ok = bmp_init();
    }

    pack_frame(tx_frame, press_pa_x100, temp_cdegc, bmp_ok);
    Serial.write(tx_frame, FRAME_SIZE);
  }

  wdt_reset();
}
