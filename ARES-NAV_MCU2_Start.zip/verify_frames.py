#!/usr/bin/env python3
"""
ARES-NAV — MCU Frame Verifier
Run on the Raspberry Pi to verify MCU 1 and MCU 2 frames.

Usage:
    python3 verify_frames.py --mcu 1   # verify MCU 1 (IMU frames)
    python3 verify_frames.py --mcu 2   # verify MCU 2 (peripheral frames)
    python3 verify_frames.py --mcu both

Requires:  pip install pyserial
"""

import argparse
import struct
import serial
import time
from pathlib import Path

# ── Frame constants ───────────────────────────────────────────────────────────
MCU1_DEVICE  = "/dev/aresnav-imu"
MCU2_DEVICE  = "/dev/aresnav-peri"
MCU1_SYNC    = bytes([0xAA, 0x55])
MCU2_SYNC    = bytes([0xBB, 0x66])
MCU1_SIZE    = 62
MCU2_SIZE    = 48
CRC8_POLY    = 0x07

# ── CRC-8 ─────────────────────────────────────────────────────────────────────
def crc8(data: bytes) -> int:
    c = 0
    for b in data:
        c ^= b
        for _ in range(8):
            c = ((c << 1) ^ CRC8_POLY) if (c & 0x80) else (c << 1)
            c &= 0xFF
    return c

# ── MCU 1 frame decoder ───────────────────────────────────────────────────────
def decode_mcu1(frame: bytes) -> dict:
    assert len(frame) == MCU1_SIZE
    sync   = frame[0:2]
    seq    = struct.unpack_from('<H', frame, 2)[0]
    ts_us  = struct.unpack_from('<Q', frame, 4)[0]
    crc_rx = frame[56]
    crc_ok = crc8(frame[:56]) == crc_rx

    imu = []
    off = 12
    for i in range(3):
        gx, gy, gz = struct.unpack_from('<hhh', frame, off);     off += 6
        ax, ay, az = struct.unpack_from('<hhh', frame, off);     off += 6
        imu.append(dict(gx=gx, gy=gy, gz=gz, ax=ax, ay=ay, az=az))

    mx, my, mz = struct.unpack_from('<hhh', frame, 48)
    temp_c      = struct.unpack_from('<b',  frame, 54)[0]
    faults      = frame[55]

    return dict(
        sync=sync, seq=seq, ts_us=ts_us,
        imu=imu, mx=mx, my=my, mz=mz,
        temp_c=temp_c, faults=faults,
        crc_ok=crc_ok
    )

# ── MCU 2 frame decoder ───────────────────────────────────────────────────────
def decode_mcu2(frame: bytes) -> dict:
    assert len(frame) == MCU2_SIZE
    sync        = frame[0:2]
    seq         = struct.unpack_from('<H',  frame, 2)[0]
    ts_us       = struct.unpack_from('<Q',  frame, 4)[0]
    lat         = struct.unpack_from('<d',  frame, 12)[0]
    lon         = struct.unpack_from('<d',  frame, 20)[0]
    alt_m       = struct.unpack_from('<f',  frame, 28)[0]
    spd_cms     = struct.unpack_from('<H',  frame, 32)[0]
    trk_cdeg    = struct.unpack_from('<H',  frame, 34)[0]
    press_hpa10 = struct.unpack_from('<H',  frame, 36)[0]   # hPa * 10
    temp_cdegc  = struct.unpack_from('<h',  frame, 38)[0]   # 0.01 °C
    fix         = frame[40]
    sats        = frame[41]
    hdop10      = frame[42]
    enc_delta   = struct.unpack_from('<b',  frame, 43)[0]
    btn_flags   = frame[44]
    batt_raw    = frame[45]
    crc_rx      = frame[46]
    crc_ok      = crc8(frame[:46]) == crc_rx

    return dict(
        sync=sync, seq=seq, ts_us=ts_us,
        lat=lat, lon=lon, alt_m=alt_m,
        spd_kts=spd_cms / 51.444,
        trk_deg=trk_cdeg / 100.0,
        press_hpa=press_hpa10 / 10.0,
        temp_c=temp_cdegc / 100.0,
        fix=fix, sats=sats, hdop=hdop10 / 10.0,
        enc_delta=enc_delta, btn_flags=btn_flags,
        batt_v=batt_raw * 0.05,
        crc_ok=crc_ok
    )

# ── Frame reader (handles partial reads, finds sync) ─────────────────────────
def read_frame(ser: serial.Serial, sync: bytes, size: int) -> bytes | None:
    # Scan for sync marker with timeout
    buf = bytearray()
    deadline = time.time() + 0.5
    while time.time() < deadline:
        b = ser.read(1)
        if not b:
            continue
        buf.extend(b)
        if len(buf) >= 2 and buf[-2:] == bytearray(sync):
            # Found sync — read rest of frame
            rest = ser.read(size - 2)
            if len(rest) == size - 2:
                return bytes(sync) + rest
            buf.clear()
    return None

# ── MCU 1 monitor ─────────────────────────────────────────────────────────────
def monitor_mcu1():
    dev = Path(MCU1_DEVICE)
    if not dev.exists():
        print(f"ERROR: {MCU1_DEVICE} not found.")
        print("  Is MCU 1 connected and the udev rule applied?")
        print("  Try:  ls /dev/aresnav*")
        return

    print(f"Opening {MCU1_DEVICE} ...")
    ser = serial.Serial(MCU1_DEVICE, timeout=0.1)
    print("Connected. Waiting for frames ...\n")

    last_seq   = None
    crc_errors = 0
    frame_count = 0
    t_start    = time.time()

    try:
        while True:
            raw = read_frame(ser, MCU1_SYNC, MCU1_SIZE)
            if raw is None:
                continue

            d = decode_mcu1(raw)
            frame_count += 1

            # Sequence check
            if last_seq is not None:
                gap = (d['seq'] - last_seq) & 0xFFFF
                if gap != 1:
                    print(f"  [SEQ GAP] expected +1, got +{gap}")
            last_seq = d['seq']

            if not d['crc_ok']:
                crc_errors += 1

            # Print summary every 100 frames (~0.2 s at 500 Hz)
            if frame_count % 100 == 0:
                elapsed = time.time() - t_start
                rate    = frame_count / elapsed
                imu0    = d['imu'][0]
                faults  = d['faults']
                print(
                    f"[#{d['seq']:5d}] "
                    f"ts={d['ts_us']/1e6:8.3f}s  "
                    f"rate={rate:5.1f}Hz  "
                    f"CRC_err={crc_errors:3d}  "
                    f"faults=0x{faults:02X}  "
                    f"IMU0 gx={imu0['gx']:+6d} gy={imu0['gy']:+6d} gz={imu0['gz']:+6d}  "
                    f"ax={imu0['ax']:+6d}  "
                    f"T={d['temp_c']:+3d}°C  "
                    f"Mx={d['mx']:+6d}"
                )
    except KeyboardInterrupt:
        elapsed = time.time() - t_start
        print(f"\n── Summary ──────────────────────────")
        print(f"  Frames received : {frame_count}")
        print(f"  Average rate    : {frame_count/elapsed:.1f} Hz  (target 500 Hz)")
        print(f"  CRC errors      : {crc_errors}")
        print(f"  Runtime         : {elapsed:.1f} s")

# ── MCU 2 monitor ─────────────────────────────────────────────────────────────
def monitor_mcu2():
    dev = Path(MCU2_DEVICE)
    if not dev.exists():
        print(f"ERROR: {MCU2_DEVICE} not found.")
        return

    print(f"Opening {MCU2_DEVICE} ...")
    ser = serial.Serial(MCU2_DEVICE, timeout=0.2)
    print("Connected. Waiting for frames ...\n")

    last_seq    = None
    crc_errors  = 0
    frame_count = 0
    t_start     = time.time()

    try:
        while True:
            raw = read_frame(ser, MCU2_SYNC, MCU2_SIZE)
            if raw is None:
                continue

            d = decode_mcu2(raw)
            frame_count += 1

            if last_seq is not None:
                gap = (d['seq'] - last_seq) & 0xFFFF
                if gap != 1:
                    print(f"  [SEQ GAP] +{gap}")
            last_seq = d['seq']

            if not d['crc_ok']:
                crc_errors += 1

            fix_str = ["NoFix", "2D", "3D", "3D+SBAS"][min(d['fix'], 3)]
            print(
                f"[#{d['seq']:4d}] "
                f"ts={d['ts_us']/1e6:8.3f}s  "
                f"CRC={'OK' if d['crc_ok'] else 'ERR'}  "
                f"Fix={fix_str}({d['sats']}sv)  "
                f"Lat={d['lat']:+10.6f}  "
                f"Lon={d['lon']:+11.6f}  "
                f"Alt={d['alt_m']:6.1f}m  "
                f"GS={d['spd_kts']:5.1f}kt  "
                f"Trk={d['trk_deg']:5.1f}°  "
                f"P={d['press_hpa']:7.1f}hPa  "
                f"T={d['temp_c']:+5.1f}°C  "
                f"ENC={d['enc_delta']:+3d}  "
                f"BTN=0x{d['btn_flags']:02X}"
            )
    except KeyboardInterrupt:
        elapsed = time.time() - t_start
        print(f"\n── Summary ──────────────────────────")
        print(f"  Frames received : {frame_count}")
        print(f"  Average rate    : {frame_count/elapsed:.1f} Hz  (target 10 Hz)")
        print(f"  CRC errors      : {crc_errors}")

# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ARES-NAV MCU frame verifier")
    parser.add_argument("--mcu", choices=["1", "2", "both"], default="1",
                        help="Which MCU to monitor")
    args = parser.parse_args()

    if args.mcu == "1":
        monitor_mcu1()
    elif args.mcu == "2":
        monitor_mcu2()
    else:
        import threading
        t1 = threading.Thread(target=monitor_mcu1, daemon=True)
        t2 = threading.Thread(target=monitor_mcu2, daemon=True)
        t1.start(); t2.start()
        t1.join();  t2.join()
