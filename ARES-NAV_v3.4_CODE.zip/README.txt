╔══════════════════════════════════════════════════════════════════════╗
║  ARES-NAV  Rev. 3.4  |  Duwald Systems  |  March 2026               ║
║  Advanced Redundant Estimation System for Aircraft Navigation        ║
╚══════════════════════════════════════════════════════════════════════╝
⚠  EXPERIMENTAL — NOT APPROVED FOR CERTIFIED FLIGHT OPERATIONS

━━━ 2-MCU CONFIGURATION ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MCU 1  (Pro Micro #1)  →  firmware/MCU1_IMU/           3x MPU-9250 SPI
MCU 2  (Pro Micro #2)  →  firmware/MCU2_Peripheral/    BMP280+AHT20+Encoder

━━━ WIRING SUMMARY ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MCU1 — 3x MPU-9250 (SPI, shared bus + individual CS):
  All MPUs:  SCK→Pin15  MOSI→Pin16  MISO→Pin14  VCC→3.3V  GND→GND
  MPU #1:    CS→Pin10
  MPU #2:    CS→Pin9
  MPU #3:    CS→Pin8
  AD0 on each MPU → GND (required for SPI mode)

MCU2 — BMP280+AHT20 (I2C):
  SDA→A4  SCL→A5  VCC→3.3V  GND→GND  SDO→GND (sets I2C addr 0x76)

MCU2 — KY-040 Encoder:
  CLK→7  DT→6  SW→5  VCC→5V  GND→GND

MCU2 — NEO-M8N GNSS (when it arrives):
  GPS-TX→Pin0  GPS-RX→Pin1  VCC→3.3V or 5V  GND→GND

Power:
  3S LiPo → Buck (XL4016 or MP1584, set to 5.0V) → Pi 5 USB-C
  Pi 5V GPIO → display  |  Pi 3.3V GPIO → all sensors

━━━ QUICK START ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Full hardware:   python3 app/main.py --profile motorglider
Bridge (1 MCU):  python3 app/main.py --bridge --profile motorglider
Simulator:       python3 app/main.py --sim --profile motorglider

━━━ DEPENDENCIES (Pi, run once) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
sudo raspi-config → Advanced → W1 (X11) → Reboot   ← MANDATORY
sudo apt install -y python3-pyqt5 python3-numpy python3-serial python3-pygame

━━━ MODULE TESTS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
python3 app/ekf.py           # EKF self-test (no hardware)
python3 app/simulator.py     # flight simulator terminal
python3 app/mcu_reader.py    # live USB frame monitor

━━━ TTS AUDIO (optional, Pi + internet) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
pip install gtts --break-system-packages
python3 app/gen_audio.py

━━━ FILE MAP ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app/
  main.py           Entry point — auto detects hardware/bridge/sim
  simulator.py      60 Hz flight simulator, no hardware needed
  mcu_reader.py     USB binary frame reader, bridge mode
  ekf.py            17-state Extended Kalman Filter
  pfd_v28.py        PyQt5 PFD renderer 60 Hz
  audio_system.py   Gear/glide/CAUTION voice callouts
  gen_audio.py      TTS callout generator
  config.json       System configuration

firmware/
  MCU1_IMU/           3x MPU-9250 SPI 500Hz + AK8963 mag
  MCU2_Peripheral/    BMP280+AHT20 + KY-040 + NEO-M8N ready
  ARES_NAV_Bridge/    Single Arduino test firmware

assets/  PFD graphics (PNG)
audio/   DE + EN callout WAVs
profiles/ Aircraft JSON profiles
