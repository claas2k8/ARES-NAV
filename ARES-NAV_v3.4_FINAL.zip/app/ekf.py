"""
ARES-NAV — Extended Kalman Filter (17-State)
Revision 3.2  |  Duwald Systems  |  March 2026

State vector x (17 elements):
    [0:3]   p_N, p_E, p_D      — NED position in metres from alignment origin
    [3:6]   v_N, v_E, v_D      — NED velocity in m/s
    [6:10]  q_w, q_x, q_y, q_z — unit quaternion attitude
    [10:13] b_gx, b_gy, b_gz   — gyroscope bias in rad/s
    [13:16] b_ax, b_ay, b_az   — accelerometer bias in m/s²
    [16]    (reserved)

Inputs:
    - MCU 1: gyro (rad/s) + accel (m/s²) medians at 100 Hz
    - MCU 2: GNSS position/velocity at 10 Hz
    - MCU 2: barometric altitude at 10 Hz
    - MCU 2: (via magnetic heading) at 10 Hz

All numpy operations use BLAS/LAPACK via OpenBLAS on Pi 5.
Typical cycle time: ~12 µs for 17×17 matrix operations.
"""

import math
import time
import logging
import numpy as np
from typing import Optional, Tuple

log = logging.getLogger("ARES-NAV.ekf")

# ── Constants ─────────────────────────────────────────────────────────────────
G_MS2    = 9.80665          # standard gravity m/s²
DEG2RAD  = math.pi / 180.0
RAD2DEG  = 180.0 / math.pi
NM2M     = 1852.0
FT2M     = 0.3048

# MPU-9250 sensitivity
GYRO_SCALE   = 1.0 / 16.4  * DEG2RAD   # raw → rad/s  (±2000°/s)
ACCEL_SCALE  = 1.0 / 2048.0 * G_MS2    # raw → m/s²   (±16g)


# ── Process noise (Q) diagonal values — tuned for consumer MEMS ──────────────
Q_POS   = 0.01      # m²
Q_VEL   = 0.10      # m²/s²
Q_QUAT  = 1e-5      # dimensionless
Q_GBIAS = 1e-8      # (rad/s)²
Q_ABIAS = 1e-6      # (m/s²)²

# ── Measurement noise (R) diagonal values ────────────────────────────────────
R_GNSS_POS_BASE = 2.5   # m per unit of HDOP
R_GNSS_VEL      = 0.05  # m/s
R_BARO_ALT      = 1.5   # m
R_MAG_HDG       = (5.0  * DEG2RAD) ** 2   # rad² (wings-level)
R_MAG_HDG_BANK  = (30.0 * DEG2RAD) ** 2  # rad² (banked > 15°)
MAG_BANK_THRESH = 15.0  * DEG2RAD          # rad


class EKF:
    """
    17-state Extended Kalman Filter for ARES-NAV.

    Usage:
        ekf = EKF()
        ekf.align(lat0, lon0, alt0_m)     # call once after INS alignment

        # In 100 Hz loop:
        ekf.predict(gyro_rps, accel_ms2, dt)

        # In 10 Hz loop (when GNSS available):
        ekf.update_gnss(lat, lon, alt_m, vn, ve, vd, hdop)

        # In 10 Hz loop (when baro available):
        ekf.update_baro(pressure_hpa, qnh_hpa)

        # Get current state:
        roll, pitch, yaw = ekf.euler_deg
        lat, lon, alt_ft = ekf.position_geodetic
        vn, ve, vd       = ekf.velocity_ned
    """

    def __init__(self):
        self._x   = np.zeros(17)
        self._x[6] = 1.0              # quaternion w=1 (identity rotation)
        self._P   = np.eye(17) * 1.0  # initial covariance — large = uncertain

        # Alignment origin (geodetic)
        self._lat0_rad  = 0.0
        self._lon0_rad  = 0.0
        self._alt0_m    = 0.0
        self._aligned   = False

        # Flat-Earth longitude scale factor (recomputed every 60s)
        self._lon_scale = 1.0
        self._lon_scale_t = 0.0

        # Magnetic declination (degrees, positive East)
        self._mag_decl_deg = 0.0

        # QNH for baro correction
        self._qnh_hpa = 1013.25

        # Covariance symmetrisation counter
        self._sym_counter = 0

        # Build Q and R matrices
        self._Q = self._build_Q()
        self._R_gnss_base = np.diag([
            R_GNSS_POS_BASE**2, R_GNSS_POS_BASE**2,  # N, E position
            (R_GNSS_POS_BASE * 1.5)**2,               # D position (VDOP ≈ 1.5×HDOP)
            R_GNSS_VEL, R_GNSS_VEL, R_GNSS_VEL       # N, E, D velocity
        ])

    # ── Public API ────────────────────────────────────────────────────────────

    def align(self, lat_deg: float, lon_deg: float, alt_m: float,
              mag_decl_deg: float = 0.0):
        """
        Set alignment origin. Must be called once before predict().
        lat_deg, lon_deg: WGS-84 degrees
        alt_m: MSL altitude in metres
        mag_decl_deg: magnetic declination (positive East)
        """
        self._lat0_rad     = lat_deg * DEG2RAD
        self._lon0_rad     = lon_deg * DEG2RAD
        self._alt0_m       = alt_m
        self._mag_decl_deg = mag_decl_deg
        self._aligned      = True
        self._update_lon_scale()
        log.info(f"EKF aligned: lat={lat_deg:.4f}° lon={lon_deg:.4f}° "
                 f"alt={alt_m:.1f}m decl={mag_decl_deg:.1f}°")

    def predict(self, gyro_rps: np.ndarray, accel_ms2: np.ndarray,
                dt: float):
        """
        IMU prediction step. Call at 100 Hz.
        gyro_rps:  [gx, gy, gz] in rad/s (body frame)
        accel_ms2: [ax, ay, az] in m/s²  (body frame, includes gravity)
        dt: time step in seconds
        """
        if not self._aligned:
            return

        x = self._x
        q = x[6:10]
        bg = x[10:13]
        ba = x[13:16]

        # Correct for bias
        gyro_c  = gyro_rps  - bg
        accel_c = accel_ms2 - ba

        # ── Quaternion integration (zeroth-order) ─────────────────────────────
        wx, wy, wz = gyro_c
        omega = np.array([
            [0,  -wx, -wy, -wz],
            [wx,  0,   wz, -wy],
            [wy, -wz,  0,   wx],
            [wz,  wy, -wx,  0 ]
        ], dtype=float)
        q_new = q + 0.5 * dt * omega @ q
        q_new /= np.linalg.norm(q_new)   # normalise every step
        x[6:10] = q_new

        # ── Rotation matrix (body → NED) ─────────────────────────────────────
        R = self._quat_to_rot(q_new)

        # ── Specific force in NED (remove gravity) ────────────────────────────
        g_ned   = np.array([0.0, 0.0, G_MS2])
        accel_n = R @ accel_c - g_ned

        # ── Velocity and position integration ────────────────────────────────
        x[3:6] += accel_n * dt
        x[0:3] += x[3:6] * dt

        # ── State transition matrix F (linearised) ───────────────────────────
        F = self._build_F(q_new, accel_c, dt)

        # ── Covariance prediction ─────────────────────────────────────────────
        self._P = F @ self._P @ F.T + self._Q * dt

        # Symmetrise every 10 steps to prevent numerical drift
        self._sym_counter += 1
        if self._sym_counter >= 10:
            self._P = 0.5 * (self._P + self._P.T)
            self._sym_counter = 0

        # Update flat-earth lon scale periodically
        if time.monotonic() - self._lon_scale_t > 60.0:
            self._update_lon_scale()

    def update_gnss(self, lat_deg: float, lon_deg: float, alt_m: float,
                    vn_ms: float, ve_ms: float, vd_ms: float,
                    hdop: float = 1.5):
        """GNSS position+velocity measurement update. Call at 10 Hz."""
        if not self._aligned:
            return

        # Convert geodetic to NED metres from origin
        dlat  = (lat_deg * DEG2RAD) - self._lat0_rad
        dlon  = (lon_deg * DEG2RAD) - self._lon0_rad
        dalt  = alt_m - self._alt0_m

        meas_ned = np.array([
            dlat  * 111320.0,
            dlon  * 111320.0 * self._lon_scale,
            -dalt,              # NED D is positive down
            vn_ms, ve_ms, vd_ms
        ])

        # State prediction for position+velocity
        pred_ned = np.zeros(6)
        pred_ned[0:3] = self._x[0:3]
        pred_ned[3:6] = self._x[3:6]

        innov = meas_ned - pred_ned

        # Measurement matrix H (6×17)
        H = np.zeros((6, 17))
        H[0, 0] = 1.0   # p_N
        H[1, 1] = 1.0   # p_E
        H[2, 2] = 1.0   # p_D
        H[3, 3] = 1.0   # v_N
        H[4, 4] = 1.0   # v_E
        H[5, 5] = 1.0   # v_D

        # Scale R by HDOP
        R = self._R_gnss_base * max(hdop, 0.5) ** 2

        self._kalman_update(H, R, innov)

    def update_baro(self, pressure_hpa: float, qnh_hpa: float = 1013.25):
        """Barometric altitude measurement update. Call at 10 Hz."""
        if not self._aligned:
            return
        self._qnh_hpa = qnh_hpa

        # ISA pressure altitude: alt = 44330 × (1 − (P/P0)^0.1903)
        alt_isa_m = 44330.0 * (1.0 - (pressure_hpa / qnh_hpa) ** 0.1903)
        dalt = alt_isa_m - self._alt0_m

        # NED D = -alt
        meas_d    = -dalt
        pred_d    = self._x[2]
        innov     = np.array([meas_d - pred_d])

        H = np.zeros((1, 17))
        H[0, 2] = 1.0    # p_D

        R = np.array([[R_BARO_ALT ** 2]])

        self._kalman_update(H, R, innov)

    def update_mag(self, mx_ut: float, my_ut: float, mz_ut: float):
        """
        Magnetometer heading update. Automatically ignored when banked > 15°.
        mag values in µT, body frame.
        """
        if not self._aligned:
            return

        roll, _, _ = self.euler_rad
        if abs(roll) > MAG_BANK_THRESH:
            return   # mag unreliable when banked

        # Project mag onto horizontal plane (tilt-compensated)
        R    = self._quat_to_rot(self._x[6:10])
        m_ned = R @ np.array([mx_ut, my_ut, mz_ut])
        # Heading from horizontal NED components
        mag_hdg = math.atan2(m_ned[1], m_ned[0])
        # Apply declination correction
        true_hdg = mag_hdg + self._mag_decl_deg * DEG2RAD

        # Current heading from quaternion
        _, _, yaw = self.euler_rad
        innov = np.array([self._wrap_angle(true_hdg - yaw)])

        H = np.zeros((1, 17))
        # Yaw sensitivity through quaternion — approximate linearisation
        q   = self._x[6:10]
        H[0, 8] = -2.0 * q[1] / (q[0]**2 + q[3]**2 + 1e-9)
        H[0, 9] =  2.0 * q[0] / (q[0]**2 + q[3]**2 + 1e-9)

        R = np.array([[R_MAG_HDG]])
        self._kalman_update(H, R, innov)

    def set_qnh(self, qnh_hpa: float):
        self._qnh_hpa = qnh_hpa

    def set_mag_declination(self, decl_deg: float):
        self._mag_decl_deg = decl_deg

    # ── State accessors ───────────────────────────────────────────────────────

    @property
    def euler_deg(self) -> Tuple[float, float, float]:
        """Return (roll_deg, pitch_deg, yaw_deg) from current quaternion."""
        r, p, y = self.euler_rad
        return r * RAD2DEG, p * RAD2DEG, y * RAD2DEG

    @property
    def euler_rad(self) -> Tuple[float, float, float]:
        q = self._x[6:10]
        qw, qx, qy, qz = q
        # Roll
        roll  = math.atan2(2*(qw*qx + qy*qz), 1 - 2*(qx*qx + qy*qy))
        # Pitch (clamped for numerical safety)
        sp    = 2*(qw*qy - qz*qx)
        pitch = math.asin(max(-1.0, min(1.0, sp)))
        # Yaw
        yaw   = math.atan2(2*(qw*qz + qx*qy), 1 - 2*(qy*qy + qz*qz))
        return roll, pitch, yaw

    @property
    def position_ned(self) -> Tuple[float, float, float]:
        """Return (north_m, east_m, down_m) from alignment origin."""
        return float(self._x[0]), float(self._x[1]), float(self._x[2])

    @property
    def position_geodetic(self) -> Tuple[float, float, float]:
        """Return (lat_deg, lon_deg, alt_ft)."""
        pn, pe, pd = self.position_ned
        lat = self._lat0_rad + pn / 111320.0
        lon = self._lon0_rad + pe / (111320.0 * self._lon_scale)
        alt_m = self._alt0_m - pd      # D is positive down
        return lat * RAD2DEG, lon * RAD2DEG, alt_m / FT2M

    @property
    def velocity_ned(self) -> Tuple[float, float, float]:
        """Return (vN_ms, vE_ms, vD_ms)."""
        return float(self._x[3]), float(self._x[4]), float(self._x[5])

    @property
    def vertical_speed_fpm(self) -> float:
        """Vertical speed in ft/min (positive = climbing)."""
        return -self._x[5] / FT2M * 60.0   # vD negative = climbing

    @property
    def groundspeed_kts(self) -> float:
        vn, ve, _ = self.velocity_ned
        return math.sqrt(vn**2 + ve**2) / 0.5144

    @property
    def track_deg(self) -> float:
        vn, ve, _ = self.velocity_ned
        if abs(vn) < 0.1 and abs(ve) < 0.1:
            return 0.0
        return (math.atan2(ve, vn) * RAD2DEG) % 360.0

    @property
    def gyro_bias_dps(self) -> list:
        return list(self._x[10:13] * RAD2DEG)

    @property
    def accel_bias_ms2(self) -> list:
        return list(self._x[13:16])

    @property
    def aligned(self) -> bool:
        return self._aligned

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _kalman_update(self, H: np.ndarray, R: np.ndarray,
                       innov: np.ndarray):
        """Standard Kalman update step."""
        S = H @ self._P @ H.T + R
        try:
            K = self._P @ H.T @ np.linalg.inv(S)
        except np.linalg.LinAlgError:
            log.warning("EKF: singular S matrix, skipping update")
            return

        self._x    += K @ innov
        I_KH        = np.eye(17) - K @ H
        self._P     = I_KH @ self._P

        # Re-normalise quaternion after update
        q = self._x[6:10]
        n = np.linalg.norm(q)
        if n > 1e-6:
            self._x[6:10] = q / n
        else:
            self._x[6:10] = np.array([1.0, 0.0, 0.0, 0.0])

    def _build_Q(self) -> np.ndarray:
        q_diag = np.array([
            Q_POS,  Q_POS,  Q_POS,      # position N,E,D
            Q_VEL,  Q_VEL,  Q_VEL,      # velocity N,E,D
            Q_QUAT, Q_QUAT, Q_QUAT, Q_QUAT,  # quaternion
            Q_GBIAS, Q_GBIAS, Q_GBIAS,   # gyro bias
            Q_ABIAS, Q_ABIAS, Q_ABIAS,   # accel bias
            0.0,                          # reserved
        ])
        return np.diag(q_diag)

    def _build_F(self, q: np.ndarray, accel_c: np.ndarray,
                 dt: float) -> np.ndarray:
        """
        Linearised state transition matrix F (17×17).
        Simplified — captures the dominant first-order terms.
        """
        F = np.eye(17)

        # Position = position + velocity * dt
        F[0, 3] = dt
        F[1, 4] = dt
        F[2, 5] = dt

        # Velocity = velocity + (R*accel - g) * dt
        # Jacobian of accel_ned wrt quaternion (simplified)
        R     = self._quat_to_rot(q)
        ac    = accel_c
        dR_dq = self._rot_jacobian_q(q, ac)  # 3×4 matrix

        for i in range(3):
            for j in range(4):
                F[3+i, 6+j] = dR_dq[i, j] * dt

        # Velocity wrt accel bias (−R * dt)
        Rdt = -R * dt
        F[3:6, 13:16] = Rdt

        # Quaternion integration — approximate F_qq
        wx, wy, wz = accel_c * 0  # use corrected gyro (already subtracted bias)
        # Simple first-order: q_new ≈ q + 0.5*dt*Omega*q, so F_qq ≈ I
        # (full Omega matrix coupling omitted for brevity — acceptable at 100Hz)

        # Quaternion wrt gyro bias
        qw, qx, qy, qz = q
        Qq = 0.5 * dt * np.array([
            [-qx, -qy, -qz],
            [ qw, -qz,  qy],
            [ qz,  qw, -qx],
            [-qy,  qx,  qw],
        ])
        F[6:10, 10:13] = Qq

        return F

    @staticmethod
    def _quat_to_rot(q: np.ndarray) -> np.ndarray:
        """Quaternion [w,x,y,z] → 3×3 rotation matrix (body→NED)."""
        qw, qx, qy, qz = q
        return np.array([
            [1-2*(qy*qy+qz*qz),  2*(qx*qy-qw*qz),   2*(qx*qz+qw*qy)],
            [2*(qx*qy+qw*qz),    1-2*(qx*qx+qz*qz),  2*(qy*qz-qw*qx)],
            [2*(qx*qz-qw*qy),    2*(qy*qz+qw*qx),    1-2*(qx*qx+qy*qy)],
        ])

    @staticmethod
    def _rot_jacobian_q(q: np.ndarray, a: np.ndarray) -> np.ndarray:
        """Jacobian of R*a wrt quaternion q. Shape: (3,4)."""
        qw, qx, qy, qz = q
        ax, ay, az = a
        # Derived analytically from d(R*a)/dq
        J = np.array([
            [2*(qy*ay+qz*az),   2*(qy*ax-2*qx*ay+qw*az), 2*(-2*qy*ax+qx*ay-qw*az+qz*az), 2*(-qz*ax+qw*ay-2*qz*az+qy*az)],  # noqa
            [2*(-qz*ax+qw*ay),  2*(qz*ay-2*qx*az-qw*ay),  2*(qy*az+qw*ax-2*qy*ay),        2*(-qx*ax-2*qz*ay+qy*az)],         # noqa
            [2*(qy*ax-qx*ay),   2*(qy*ax+qz*az-2*qx*az),  2*(qx*ay-2*qy*az+qz*ax),        2*(qw*ax-2*qz*ay+qx*az)],          # noqa
        ])
        return J

    def _update_lon_scale(self):
        lat = self._lat0_rad + self._x[0] / 111320.0
        self._lon_scale = math.cos(lat)
        self._lon_scale_t = time.monotonic()

    @staticmethod
    def _wrap_angle(a: float) -> float:
        """Wrap angle to [-π, π]."""
        while a >  math.pi: a -= 2 * math.pi
        while a < -math.pi: a += 2 * math.pi
        return a


# ── Standalone test ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("EKF self-test — simulating 10s of flight")

    ekf = EKF()
    ekf.align(53.5353, 9.8353, 7.0, mag_decl_deg=2.5)  # Hamburg Finkenwerder

    dt = 0.01  # 100 Hz
    t  = 0.0

    # Simulate level flight north at 90 kts, 3000ft
    # Gravity vector in body frame (level flight, z down): [0, 0, -g]
    accel  = np.array([0.0, 0.0, -G_MS2])
    gyro   = np.array([0.0, 0.0, 0.0])

    for step in range(1000):
        ekf.predict(gyro, accel, dt)
        t += dt

        # GNSS update at 10 Hz
        if step % 10 == 0:
            lat, lon, alt_ft = ekf.position_geodetic
            ekf.update_gnss(lat, lon, alt_ft * FT2M, 46.3, 0.0, 0.0, hdop=1.2)
            ekf.update_baro(1013.25 - (alt_ft * FT2M / 8.43), 1013.25)

    roll, pitch, yaw = ekf.euler_deg
    lat, lon, alt_ft = ekf.position_geodetic
    vn, ve, vd = ekf.velocity_ned

    print(f"  After {t:.1f}s:")
    print(f"  Attitude:  roll={roll:+.2f}°  pitch={pitch:+.2f}°  yaw={yaw:.1f}°")
    print(f"  Position:  lat={lat:.5f}°  lon={lon:.5f}°  alt={alt_ft:.0f}ft")
    print(f"  Velocity:  vN={vn:.2f}  vE={ve:.2f}  vD={vd:.2f} m/s")
    print(f"  GS={ekf.groundspeed_kts:.1f}kts  VS={ekf.vertical_speed_fpm:.0f}fpm")
    print("EKF self-test complete.")
