"""
ARES-NAV — Main Application
Revision 3.2  |  Duwald Systems  |  March 2026

Entry point for the ARES-NAV system on Raspberry Pi 5.
Starts all subsystems and runs the 60 Hz PFD render loop.

Usage:
    python3 main.py                          # auto-detect hardware
    python3 main.py --sim                    # force simulator mode
    python3 main.py --profile ask21          # load specific profile
    python3 main.py --fullscreen             # fullscreen display
    python3 main.py --sim --lang de          # simulator + German audio

Architecture:
    MCUReader threads  →  EKF (100 Hz predict)  →  AresNavState
    MCUReader threads  →  AresNavState (GNSS/baro direct)
    AresNavState       →  PFD renderer (60 Hz)
    AresNavState       →  Audio system (1 Hz monitor)
"""

import sys
import os
import time
import json
import math
import logging
import threading
import argparse
import copy
from typing import Optional

import numpy as np
from PyQt5.QtWidgets import QApplication

# ── Local modules ─────────────────────────────────────────────────────────────
from simulator  import Simulator, AresNavState
from mcu_reader import MCUReader, MCU1Frame, MCU2Frame, EncoderEvents, make_readers
from ekf        import EKF, DEG2RAD, RAD2DEG, G_MS2, FT2M
from audio_system import AresNavAudio
from csv_bridge import CSVBridge

# PFD renderer — import dynamically so we can run headless for testing
try:
    from pfd_v28 import PFD
    _PFD_AVAILABLE = True
except ImportError:
    _PFD_AVAILABLE = False

log = logging.getLogger("ARES-NAV.main")

# ── Config and profile paths ──────────────────────────────────────────────────
PROFILE_DIRS = [
    "/boot/firmware/ares-nav/profiles",
    os.path.join(os.path.dirname(__file__), "profiles"),
    "./profiles",
]
CONFIG_PATHS = [
    "/boot/firmware/ares-nav/config.json",
    os.path.join(os.path.dirname(__file__), "config.json"),
    "./config.json",
]

DEFAULT_PROFILE = {
    "aircraft_name":    "Unknown",
    "callsign":         "ARES",
    "aircraft_type":    "motorized",
    "cruise_cas_kts":   90.0,
    "v_ne_kts":         150.0,
    "v_s_kts":          52.0,
    "v_bg_kts":         75.0,
    "glide_ratio":      10.0,
    "audio_lang":       "en",
    "gear_check_alt_ft":1000.0,
}

DEFAULT_CONFIG = {
    "audio_lang":         "en",
    "audio_volume":       0.85,
    "audio_device_index": None,
    "qnh_hpa":            1013.25,
    "mag_decl_deg":       2.5,       # Hamburg area
    "alignment_sec":      60,
    "ekf_rate_hz":        100,
    "display_rate_hz":    60,
}


def load_json(paths: list, fallback: dict) -> dict:
    for p in paths:
        if os.path.exists(p):
            try:
                with open(p) as f:
                    data = json.load(f)
                    log.info(f"Loaded config: {p}")
                    return {**fallback, **data}
            except Exception as e:
                log.warning(f"Failed to load {p}: {e}")
    return fallback.copy()


def load_profile(name: str) -> dict:
    for d in PROFILE_DIRS:
        p = os.path.join(d, f"{name}.json")
        if os.path.exists(p):
            try:
                with open(p) as f:
                    data = json.load(f)
                    log.info(f"Loaded profile: {p}")
                    return {**DEFAULT_PROFILE, **data}
            except Exception as e:
                log.warning(f"Failed to load profile {p}: {e}")
    log.warning(f"Profile '{name}' not found, using defaults")
    return DEFAULT_PROFILE.copy()


# ── Hardware data source ──────────────────────────────────────────────────────

class HardwareSource:
    """
    Reads MCU 1 + MCU 2 frames and runs EKF at 100 Hz.
    Produces AresNavState at 60 Hz for the PFD renderer.
    Identical interface to Simulator — both expose get_state().
    """

    ALIGN_SEC = 60     # alignment duration

    def __init__(self, profile: dict, config: dict):
        self.profile = profile
        self.config  = config

        # MCU readers (MCU1 = IMU, MCU2 = GNSS/baro/encoder)
        bridge = config.get("bridge_mode", False)
        self._mcu1, self._mcu2, self._enc = make_readers(bridge_mode=bridge)

        # EKF
        self._ekf = EKF()

        # State
        self._state      = AresNavState()
        self._state_lock = threading.Lock()
        self._running    = False

        # Alignment
        self._align_start = 0.0
        self._aligned     = False
        self._align_sec   = config.get("alignment_sec", 60)

        # QNH + declination
        self._qnh_hpa  = config.get("qnh_hpa",       1013.25)
        self._mag_decl = config.get("mag_decl_deg",   2.5)

        # EKF timing
        self._ekf_hz     = config.get("ekf_rate_hz", 100)
        self._last_f1_seq = -1
        self._last_f2_seq = -1
        self._last_f2: Optional[MCU2Frame] = None

        # Wind
        self._wind_samples = []

        # Apply profile to state
        s = self._state
        s.callsign      = profile.get("callsign",      "ARES")
        s.aircraft_name = profile.get("aircraft_name", "Unknown")
        s.aircraft_type = profile.get("aircraft_type", "motorized")
        s.v_ne_kts      = profile.get("v_ne_kts",      150.0)
        s.v_s_kts       = profile.get("v_s_kts",       52.0)
        s.v_bg_kts      = profile.get("v_bg_kts",      75.0)
        s.audio_lang    = profile.get("audio_lang", config.get("audio_lang", "en"))
        s.qnh_hpa       = self._qnh_hpa

    def start(self):
        self._mcu1.start()
        self._mcu2.start()
        self._running     = True
        self._align_start = time.monotonic()
        t = threading.Thread(target=self._run, daemon=True, name="HW-source")
        t.start()
        log.info("HardwareSource started")

    def stop(self):
        self._running = False
        self._mcu1.stop()
        self._mcu2.stop()

    def get_state(self) -> AresNavState:
        with self._state_lock:
            return copy.copy(self._state)

    # ── Internal loop ─────────────────────────────────────────────────────────

    def _run(self):
        dt_ekf = 1.0 / self._ekf_hz
        last   = time.monotonic()

        while self._running:
            now = time.monotonic()
            dt  = now - last
            if dt < dt_ekf:
                time.sleep(dt_ekf - dt)
                continue
            last = now

            self._tick(dt)

    def _tick(self, dt: float):
        s = self._state

        # ── MCU link health ───────────────────────────────────────────────────
        s.mcu1_link = self._mcu1.link_ok
        s.mcu2_link = self._mcu2.link_ok

        # ── Read MCU 2 (GNSS / baro / encoder) ───────────────────────────────
        f2 = self._mcu2.get()
        if f2 and f2.seq != self._last_f2_seq:
            self._last_f2_seq = f2.seq
            self._last_f2     = f2
            self._enc.update(f2)

            # GNSS
            if f2.gnss_valid:
                s.gnss_fix   = f2.fix
                s.satellites = f2.sats
                s.hdop       = f2.hdop
                s.gnss_ok    = True
                s.lat        = f2.lat
                s.lon        = f2.lon
                # Update EKF with GNSS
                if self._aligned:
                    alt_m = f2.alt_m
                    # Velocity from track + speed
                    spd_ms = f2.spd_kts * 0.5144
                    trk_r  = f2.trk_deg * DEG2RAD
                    vn = spd_ms * math.cos(trk_r)
                    ve = spd_ms * math.sin(trk_r)
                    self._ekf.update_gnss(f2.lat, f2.lon, alt_m,
                                          vn, ve, 0.0, f2.hdop)
            else:
                s.gnss_ok = False
                s.gnss_fix = f2.fix
                s.satellites = f2.sats

            # Barometer
            if f2.baro_valid:
                s.baro_ok = True
                if self._aligned:
                    self._ekf.update_baro(f2.pressure_hpa, self._qnh_hpa)
            else:
                s.baro_ok = False

            # Battery
            if f2.battery_v > 0:
                s.battery_v = f2.battery_v

            # Humidity from AHT20 (non-zero = AHT20 present and working)
            if hasattr(f2, 'humidity_pct') and f2.humidity_pct > 0:
                s.humidity_pct = f2.humidity_pct
                s.aht20_ok     = True

        # ── Alignment phase ───────────────────────────────────────────────────
        elapsed = time.monotonic() - self._align_start

        if not self._aligned:
            s.aligned = False
            s.imu1_ok = s.mcu1_link
            s.imu2_ok = s.mcu1_link
            s.imu3_ok = s.mcu1_link
            s.mag_ok  = s.mcu1_link

            if elapsed >= self._align_sec and s.gnss_ok and s.mcu1_link:
                # Align EKF at current GNSS position
                f2c = self._last_f2
                if f2c and f2c.gnss_valid:
                    self._ekf.align(f2c.lat, f2c.lon, f2c.alt_m,
                                    self._mag_decl)
                    self._aligned   = True
                    s.aligned       = True
                    log.info("INS alignment complete")
            return   # Don't update PFD state during alignment

        # ── Read MCU 1 (IMU) ─────────────────────────────────────────────────
        f1 = self._mcu1.get()
        if f1 and f1.seq != self._last_f1_seq:
            self._last_f1_seq = f1.seq
            self._last_f1     = f1

            # IMU health from fault flags
            s.imu1_ok = f1.imu1_ok
            s.imu2_ok = f1.imu2_ok
            s.imu3_ok = f1.imu3_ok
            s.mag_ok  = f1.mag_ok

            if not (s.imu1_ok or s.imu2_ok or s.imu3_ok):
                s.master_caution = True
            else:
                # EKF predict with median IMU values
                gyro_rps  = np.array(f1.gyro_med_dps) * DEG2RAD
                accel_ms2 = np.array(f1.accel_med_g)  * G_MS2
                self._ekf.predict(gyro_rps, accel_ms2, dt)

                # Magnetometer update
                if f1.mag_ok:
                    self._ekf.update_mag(*f1.mag_ut)

        # ── Extract EKF output into state ─────────────────────────────────────
        if self._aligned:
            roll, pitch, yaw      = self._ekf.euler_deg
            lat, lon, alt_ft      = self._ekf.position_geodetic
            vn, ve, vd            = self._ekf.velocity_ned

            s.roll_deg            = roll
            s.pitch_deg           = pitch
            s.heading_deg         = yaw % 360.0
            s.heading_valid       = True
            s.altitude_ft         = alt_ft
            s.groundspeed_kts     = self._ekf.groundspeed_kts
            s.vertical_speed_fpm  = self._ekf.vertical_speed_fpm
            s.lat                 = lat
            s.lon                 = lon
            s.aligned             = True

            # Wind estimation: TAS ≈ GS (no pitot), wind = GPS track vs heading
            self._estimate_wind(s)

        # ── Fault logic ───────────────────────────────────────────────────────
        any_fault = (
            not s.mcu1_link or not s.mcu2_link or
            not s.gnss_ok   or not s.baro_ok   or
            not (s.imu1_ok or s.imu2_ok or s.imu3_ok)
        )
        s.master_caution = any_fault

        # ── Write back ────────────────────────────────────────────────────────
        with self._state_lock:
            self._state = s

    def _estimate_wind(self, s: AresNavState):
        """Simple wind triangle: compare GPS track with magnetic heading."""
        if not s.gnss_ok or s.groundspeed_kts < 20.0:
            s.wind_valid = False
            return

        # TAS approximation from ISA (no pitot)
        tas_kts = s.groundspeed_kts  # placeholder until pitot available

        hdg_r = s.heading_deg * DEG2RAD
        trk_r = self._ekf.track_deg * DEG2RAD

        # Wind = TAS vector − GS vector
        tas_n = tas_kts * math.cos(hdg_r)
        tas_e = tas_kts * math.sin(hdg_r)
        gs_n  = s.groundspeed_kts * math.cos(trk_r)
        gs_e  = s.groundspeed_kts * math.sin(trk_r)

        wn = tas_n - gs_n
        we = tas_e - gs_e

        s.wind_speed_kts = math.sqrt(wn**2 + we**2)
        s.wind_dir_deg   = (math.atan2(we, wn) * RAD2DEG + 180) % 360
        s.wind_valid     = True

    def encoder(self) -> EncoderEvents:
        return self._enc


# ── Main application ──────────────────────────────────────────────────────────

class AresNavApp:
    """
    Top-level application. Owns all subsystems.
    Call run() to start — blocks until window is closed.
    """

    def __init__(self, args):
        self.args = args

        # Load config and profile
        self.config  = load_json(CONFIG_PATHS, DEFAULT_CONFIG)
        self.profile = load_profile(args.profile)

        # Override language from CLI if given
        if args.lang:
            self.profile["audio_lang"] = args.lang
            self.config["audio_lang"]  = args.lang

        # Bridge mode flag
        if hasattr(args, 'bridge') and args.bridge:
            self.config["bridge_mode"] = True

        # Choose data source
        if args.csv:
            log.info(f"Using CSV bridge on {args.csv}")
            self.source = CSVBridge(
                port=args.csv,
                profile=self.profile,
                qnh_hpa=self.config.get("qnh_hpa", 1013.25),
            )
            self.hw = None
        elif args.sim or not self._hardware_available():
            log.info("Using simulator data source")
            self.source = Simulator(profile=self.profile)
            self.hw     = None
        else:
            log.info("Using hardware data source (MCU readers + EKF)")
            self.source = HardwareSource(self.profile, self.config)
            self.hw     = self.source

        # Audio
        self.audio = AresNavAudio.from_profile(self.profile, self.config)

        # Audio monitoring thread (1 Hz)
        self._audio_thread = threading.Thread(
            target=self._audio_loop, daemon=True, name="audio-monitor")

    def run(self):
        """Start all subsystems and launch PFD window. Blocks until exit."""
        self.source.start()
        self.audio.start()
        self._audio_thread.start()

        if not _PFD_AVAILABLE:
            log.error("PFD renderer (pfd_v28.py) not found — headless mode")
            self._headless_loop()
            return

        app = QApplication(sys.argv)
        app.setStyle("Fusion")
        pfd = PFD(self.source, profile=self.profile)

        # Pass encoder to PFD if using hardware
        if self.hw:
            pfd.set_encoder(self.hw.encoder())

        if self.args.fullscreen or self._is_raspberry_pi():
            pfd.showFullScreen()
        else:
            pfd.resize(1024, 600)
            pfd.show()

        exit_code = app.exec_()
        self.source.stop()
        self.audio.stop()
        sys.exit(exit_code)

    def _audio_loop(self):
        """1 Hz audio monitoring — checks glide range, gear, caution."""
        while True:
            try:
                state = self.source.get_state()
                self.audio.update(state)
            except Exception as e:
                log.debug(f"Audio monitor error: {e}")
            time.sleep(1.0)

    def _headless_loop(self):
        """Headless mode — print state to terminal (for testing without display)."""
        print("Headless mode — no display. Ctrl+C to stop.\n")
        print(f"{'Time':>6}  {'Roll':>6}  {'Pitch':>6}  {'Hdg':>6}  "
              f"{'Alt':>7}  {'GS':>6}  {'VS':>7}  {'Fix'}")
        try:
            while True:
                s = self.source.get_state()
                print(f"{s.timestamp:6.1f}  "
                      f"{s.roll_deg:+6.1f}°  {s.pitch_deg:+6.1f}°  "
                      f"{s.heading_deg:6.1f}°  {s.altitude_ft:6.0f}ft  "
                      f"{s.groundspeed_kts:5.1f}kt  "
                      f"{s.vertical_speed_fpm:+6.0f}fpm  "
                      f"GPS{s.gnss_fix}", end="\r")
                time.sleep(0.1)
        except KeyboardInterrupt:
            print("\nStopped.")

    @staticmethod
    def _hardware_available() -> bool:
        """Return True if at least MCU 2 USB device is present."""
        import os
        for p in ["/dev/aresnav-peri", "/dev/ttyACM0", "/dev/ttyACM1"]:
            if os.path.exists(p):
                return True
        return False

    @staticmethod
    def _is_raspberry_pi() -> bool:
        try:
            return os.uname().nodename.startswith("raspberry")
        except AttributeError:
            return False


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
        datefmt="%H:%M:%S",
    )

    parser = argparse.ArgumentParser(description="ARES-NAV PFD")
    parser.add_argument("--sim",        action="store_true",
                        help="Force simulator mode (ignore hardware)")
    parser.add_argument("--csv",        default=None, metavar="PORT",
                        help="Use CSV test platform (e.g. /dev/ttyACM0 or COM3)")
    parser.add_argument("--profile",    default="motorglider",
                        help="Aircraft profile name (default: motorglider)")
    parser.add_argument("--fullscreen", action="store_true",
                        help="Start in fullscreen mode")
    parser.add_argument("--lang",       default=None, choices=["de", "en"],
                        help="Override audio language")
    parser.add_argument("--bridge",     action="store_true",
                        help="Bridge mode: single Arduino with ARES_NAV_Bridge.ino")
    parser.add_argument("--headless",   action="store_true",
                        help="Run without display (terminal output only)")
    parser.add_argument("--ekf-test",   action="store_true",
                        help="Run EKF self-test and exit")
    args = parser.parse_args()

    if args.ekf_test:
        import ekf as ekf_mod
        # Run the EKF standalone test
        exec(open(ekf_mod.__file__).read().split("if __name__")[1].split("==")[1], {})
        return

    AresNavApp(args).run()


if __name__ == "__main__":
    main()
