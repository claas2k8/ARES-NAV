"""
ARES-NAV — Flight Data Simulator
Revision 3.2  |  Duwald Systems  |  March 2026

Generates realistic 60 Hz aircraft state without any hardware.
Identical interface to HardwareSource — both expose get_state().
The PFD renderer never needs to know which source is active.

Usage (standalone):
    python3 simulator.py

Usage (imported):
    from simulator import Simulator, AresNavState
    sim = Simulator(profile=profile_dict)
    sim.start()
    state = sim.get_state()   # returns AresNavState copy
    sim.stop()
"""

import math
import time
import copy
import threading
import random
from dataclasses import dataclass
from typing import Optional


# ─────────────────────────────────────────────────────────────────────────────
# Canonical aircraft state — shared by Simulator, HardwareSource, and EKF
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class AresNavState:
    # ── Attitude ──────────────────────────────────────────────────────────────
    roll_deg:            float = 0.0
    pitch_deg:           float = 0.0
    heading_deg:         float = 360.0
    heading_valid:       bool  = False

    # ── Speed ─────────────────────────────────────────────────────────────────
    groundspeed_kts:     float = 0.0
    vertical_speed_fpm:  float = 0.0

    # ── Altitude ──────────────────────────────────────────────────────────────
    altitude_ft:         float = 0.0
    qnh_hpa:             float = 1013.25

    # ── Navigation ────────────────────────────────────────────────────────────
    lat:                 float = 53.5353
    lon:                 float = 9.8353
    gnss_fix:            int   = 0
    satellites:          int   = 0
    hdop:                float = 99.9

    # ── Wind ──────────────────────────────────────────────────────────────────
    wind_dir_deg:        float = 0.0
    wind_speed_kts:      float = 0.0
    wind_valid:          bool  = False

    # ── Flight director ───────────────────────────────────────────────────────
    fd_active:           bool  = False
    fd_pitch_cmd:        float = 0.0
    fd_roll_cmd:         float = 0.0
    lnav_active:         bool  = False

    # ── Active waypoint ───────────────────────────────────────────────────────
    wp_name:             str   = ""
    wp_bearing_deg:      float = 0.0
    wp_dist_nm:          float = 0.0
    wp_eta_s:            float = 0.0
    course_deg:          float = 0.0

    # ── System health ─────────────────────────────────────────────────────────
    imu1_ok:             bool  = False
    imu2_ok:             bool  = False
    imu3_ok:             bool  = False
    mag_ok:              bool  = False
    baro_ok:             bool  = False
    gnss_ok:             bool  = False
    mcu1_link:           bool  = False
    mcu2_link:           bool  = False
    master_caution:      bool  = False
    aligned:             bool  = False

    # ── Nearest airport (glide range audio) ───────────────────────────────────
    nearest_airport_nm:  Optional[float] = None
    nearest_airport_id:  Optional[str]   = None

    # ── Power ─────────────────────────────────────────────────────────────────
    battery_v:           float = 12.4
    bus_v:               float = 12.6

    # ── Environment (AHT20) ───────────────────────────────────────────────────
    humidity_pct:        float = 0.0    # % relative humidity
    aht20_ok:            bool  = False

    # ── Aircraft profile ──────────────────────────────────────────────────────
    callsign:            str   = "SIM"
    aircraft_name:       str   = "Simulator"
    aircraft_type:       str   = "motorized"
    v_ne_kts:            float = 150.0
    v_s_kts:             float = 52.0
    v_bg_kts:            float = 75.0
    audio_lang:          str   = "en"

    timestamp:           float = 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Simulator
# ─────────────────────────────────────────────────────────────────────────────
class Simulator:
    """
    Realistic flight simulator at 60 Hz in a daemon thread.
    Phases: align(8s) → cruise → turn_right → climb → turn_left → descend → …
    """

    def __init__(self, profile: dict = None):
        self._state   = AresNavState()
        self._lock    = threading.Lock()
        self._thread  = None
        self._running = False
        self._t = self._phase_t = 0.0
        self._phase   = "align"
        self._tgt_hdg = 90.0
        self._tgt_alt = 3000.0
        self._tgt_spd = 90.0

        if profile:
            s = self._state
            s.callsign      = profile.get("callsign",      "SIM")
            s.aircraft_name = profile.get("aircraft_name", "Simulator")
            s.aircraft_type = profile.get("aircraft_type", "motorized")
            s.v_ne_kts      = profile.get("v_ne_kts",      150.0)
            s.v_s_kts       = profile.get("v_s_kts",       52.0)
            s.v_bg_kts      = profile.get("v_bg_kts",      75.0)
            s.audio_lang    = profile.get("audio_lang",    "en")

    def start(self):
        self._running = True
        self._thread  = threading.Thread(target=self._run, daemon=True,
                                          name="simulator")
        self._thread.start()

    def stop(self):
        self._running = False

    def get_state(self) -> AresNavState:
        with self._lock:
            return copy.copy(self._state)

    def _run(self):
        dt = 1.0 / 60.0
        last = time.monotonic()
        while self._running:
            now = time.monotonic()
            if now - last < dt:
                time.sleep(dt - (now - last))
                continue
            last          = now
            self._t      += dt
            self._phase_t += dt
            self._update(dt)

    @staticmethod
    def _lerp(cur, tgt, rate, dt):
        d = tgt - cur
        s = rate * dt
        return tgt if abs(d) < s else cur + math.copysign(s, d)

    @staticmethod
    def _wrap(h): return h % 360.0

    def _update(self, dt):
        s  = self._state
        t  = self._t
        pt = self._phase_t

        # ── Alignment ────────────────────────────────────────────────────────
        if self._phase == "align":
            s.aligned       = False
            s.mcu1_link     = pt > 0.5;  s.mcu2_link = pt > 0.5
            s.imu1_ok       = pt > 1.0;  s.imu2_ok   = pt > 1.5
            s.imu3_ok       = pt > 2.0;  s.mag_ok    = pt > 2.5
            s.baro_ok       = pt > 3.0
            s.satellites    = int(min(pt * 1.5, 9))
            s.gnss_fix      = 0 if pt < 4 else (1 if pt < 5 else (2 if pt < 6 else 3))
            s.gnss_ok       = s.gnss_fix >= 2
            s.heading_valid = pt > 3.0
            s.groundspeed_kts = 0.0
            s.altitude_ft   = 23.0
            s.roll_deg      = 0.0
            s.pitch_deg     = 2.0
            s.heading_deg   = 85.0
            s.hdop          = max(9.9 - pt, 1.2)
            s.timestamp     = t
            if pt >= 8.0:
                s.aligned   = True
                self._phase = "cruise"
                self._phase_t = 0.0
            with self._lock:
                self._state = s
            return

        # ── Normal flight ─────────────────────────────────────────────────────
        s.imu1_ok = s.imu2_ok = s.imu3_ok = True
        s.mag_ok = s.baro_ok = s.gnss_ok = True
        s.mcu1_link = s.mcu2_link = True
        s.aligned = True
        s.heading_valid = True
        s.satellites = 9
        s.gnss_fix = 3
        s.hdop = 1.2
        s.master_caution = False

        # ── Phase transitions ─────────────────────────────────────────────────
        if   self._phase == "cruise"     and pt > 35:
            self._phase = "turn_right"; self._phase_t = 0.0
            self._tgt_hdg = self._wrap(s.heading_deg + 90)
        elif self._phase == "turn_right" and pt > 20:
            self._phase = "climb"; self._phase_t = 0.0
            self._tgt_alt = s.altitude_ft + 1200; self._tgt_spd = 80.0
        elif self._phase == "climb"      and pt > 30:
            self._phase = "turn_left"; self._phase_t = 0.0
            self._tgt_hdg = self._wrap(s.heading_deg - 90)
        elif self._phase == "turn_left"  and pt > 20:
            self._phase = "descend"; self._phase_t = 0.0
            self._tgt_alt = s.altitude_ft - 800; self._tgt_spd = 95.0
        elif self._phase == "descend"    and pt > 30:
            self._phase = "cruise"; self._phase_t = 0.0
            self._tgt_spd = 90.0

        # ── Heading smooth ────────────────────────────────────────────────────
        rate = 10.0 if "turn" in self._phase else 3.0
        diff = (self._tgt_hdg - s.heading_deg + 540) % 360 - 180
        step = rate * dt
        s.heading_deg = self._wrap(
            self._tgt_hdg if abs(diff) < step
            else s.heading_deg + math.copysign(step, diff))

        # ── Speed / VS / Alt ─────────────────────────────────────────────────
        s.groundspeed_kts    = self._lerp(s.groundspeed_kts,   self._tgt_spd, 5.0, dt)
        vs_tgt               = max(-800.0, min(800.0, (self._tgt_alt - s.altitude_ft) * 2.0))
        s.vertical_speed_fpm = self._lerp(s.vertical_speed_fpm, vs_tgt, 100.0, dt)
        s.altitude_ft       += s.vertical_speed_fpm / 60.0 * dt

        # ── Attitude ─────────────────────────────────────────────────────────
        roll_tgt  =  20.0 if self._phase == "turn_right" else \
                    -20.0 if self._phase == "turn_left"  else 0.0
        pitch_tgt = max(-5.0, min(8.0, s.vertical_speed_fpm / 200.0))
        s.roll_deg  = self._lerp(s.roll_deg,  roll_tgt,  15.0, dt)
        s.pitch_deg = self._lerp(s.pitch_deg, pitch_tgt,  5.0, dt)

        # ── Turbulence ────────────────────────────────────────────────────────
        s.roll_deg    += random.gauss(0, 0.8)
        s.pitch_deg   += random.gauss(0, 0.25)
        s.altitude_ft += random.gauss(0, 1.2)

        # ── Position ─────────────────────────────────────────────────────────
        hdg_r  = math.radians(s.heading_deg)
        spd_ms = s.groundspeed_kts * 0.5144
        s.lat += spd_ms * math.cos(hdg_r) * dt / 111320.0
        s.lon += spd_ms * math.sin(hdg_r) * dt / \
                 (111320.0 * math.cos(math.radians(s.lat)))

        # ── Wind ─────────────────────────────────────────────────────────────
        s.wind_dir_deg = 270.0; s.wind_speed_kts = 12.0; s.wind_valid = True

        # ── Nearest airport: EDXB Heide-Büsum ────────────────────────────────
        wp_lat, wp_lon = 54.3747, 8.9011
        dlat = wp_lat - s.lat; dlon = wp_lon - s.lon
        dist_m = math.sqrt(
            (dlat * 111320.0) ** 2 +
            (dlon * 111320.0 * math.cos(math.radians(s.lat))) ** 2)
        s.wp_dist_nm         = dist_m / 1852.0
        s.wp_bearing_deg     = (math.degrees(math.atan2(dlon, dlat)) + 360) % 360
        s.wp_name            = "EDXB"
        s.course_deg         = s.wp_bearing_deg
        s.wp_eta_s           = dist_m / (s.groundspeed_kts * 0.5144 + 0.1)
        s.nearest_airport_nm = s.wp_dist_nm
        s.nearest_airport_id = s.wp_name

        # ── Power ─────────────────────────────────────────────────────────────
        s.battery_v = 12.4 + random.gauss(0, 0.02)
        s.bus_v     = 12.6 + random.gauss(0, 0.02)
        s.timestamp = t

        with self._lock:
            self._state = s


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    sim = Simulator()
    sim.start()
    print("Simulator running. Ctrl+C to stop.\n")
    print(f"{'t':>6}  {'Phase':>10}  {'Hdg':>6}  {'Spd':>6}  "
          f"{'Alt':>7}  {'Roll':>6}  {'Pitch':>6}  {'VS':>7}")
    try:
        while True:
            s = sim.get_state()
            ph = "ALIGN" if not s.aligned else "FLT"
            print(f"{s.timestamp:6.1f}  {ph:>10}  "
                  f"{s.heading_deg:6.1f}  {s.groundspeed_kts:5.1f}kt  "
                  f"{s.altitude_ft:6.0f}ft  {s.roll_deg:+6.1f}  "
                  f"{s.pitch_deg:+6.1f}  {s.vertical_speed_fpm:+7.0f}",
                  end="\r")
            time.sleep(0.1)
    except KeyboardInterrupt:
        sim.stop()
        print("\nStopped.")
