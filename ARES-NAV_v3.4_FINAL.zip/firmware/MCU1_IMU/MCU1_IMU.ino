/*
 * ARES-NAV — MCU 1 IMU Controller
 * Hardware: Arduino Pro Micro (ATmega32U4 @ 16 MHz)
 * Role:     3x MPU-9250 via SPI at 8 MHz, 500 Hz sampling,
 *           AK8963 mag via I2C master pass-through (100 Hz),
 *           CRC8-protected 62-byte binary frames over USB CDC.
 *
 * 4th MPU-9250 available as cold spare — connect to CS3 (Pin 7)
 * if IMU1/2/3 fails. No firmware changes needed: swap CS pin in
 * the failing IMU slot and reflash.
 *
 * USB Serial Number: ARESNAV-IMU  (set in platform config)
 * Pi device symlink: /dev/aresnav-imu  (via udev rule)
 *
 * Frame: 62 bytes — ARES-NAV Spec Rev. 3.3, Section 13
 * Revision: 3.3  |  Duwald Systems  |  March 2026
 */

#include <SPI.h>
#include <Wire.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>

// ── Pin assignments ────────────────────────────────────────────────────────
#define CS0_PIN   10   // MPU-9250 #1 chip select
#define CS1_PIN    9   // MPU-9250 #2 chip select
#define CS2_PIN    8   // MPU-9250 #3 chip select

// ── MPU-9250 register map ──────────────────────────────────────────────────
#define REG_SMPLRT_DIV    0x19
#define REG_CONFIG        0x1A
#define REG_GYRO_CONFIG   0x1B
#define REG_ACCEL_CONFIG  0x1C
#define REG_ACCEL_CFG2    0x1D
#define REG_INT_PIN_CFG   0x37
#define REG_ACCEL_XOUT_H  0x3B
#define REG_TEMP_OUT_H    0x41
#define REG_GYRO_XOUT_H   0x43
#define REG_USER_CTRL     0x6A
#define REG_PWR_MGMT_1    0x6B
#define REG_WHO_AM_I      0x75
#define REG_I2C_MST_CTRL  0x24
#define REG_I2C_SLV0_ADDR 0x25
#define REG_I2C_SLV0_REG  0x26
#define REG_I2C_SLV0_CTRL 0x27
#define REG_EXT_SENS_DATA 0x49

// ── AK8963 (magnetometer) ─────────────────────────────────────────────────
#define AK_ADDR  0x0C
#define AK_WIA   0x00
#define AK_CNTL1 0x0A
#define AK_ASAX  0x10

// ── Frame constants ────────────────────────────────────────────────────────
#define FRAME_SIZE  62
#define SYNC0       0xAA
#define SYNC1       0x55
#define RING_DEPTH   4   // 4 x 62 = 248 bytes ring buffer — fits in SRAM

// ─────────────────────────────────────────────────────────────────────────────
// uint64 timestamp via Timer1 overflow counter
// Timer1 runs in CTC mode at 500 Hz (OCR1A = 3999, prescaler 8).
// The OVF interrupt fires when TCNT1 rolls over from 65535 → 0,
// which at prescaler 8 happens every 65536 / (16e6/8) = 32.768 ms.
// micros64() = (overflow_count << 15) | (TCNT1 >> 1)
// → 0.5 µs per tick of TCNT1, correct µs value.
// ─────────────────────────────────────────────────────────────────────────────
volatile uint32_t t1_ovf = 0;

ISR(TIMER1_OVF_vect) {
  t1_ovf++;
}

uint64_t micros64(void) {
  uint8_t sreg = SREG;
  cli();
  uint32_t ovf  = t1_ovf;
  uint32_t tcnt = TCNT1;
  SREG = sreg;
  return ((uint64_t)ovf << 15) | (tcnt >> 1);
}

// ─────────────────────────────────────────────────────────────────────────────
// State
// ─────────────────────────────────────────────────────────────────────────────
static uint8_t  ring[RING_DEPTH][FRAME_SIZE];
static volatile uint8_t  ring_w = 0;  // written by ISR
static volatile uint8_t  ring_r = 0;  // read by loop()
static volatile uint16_t frame_seq = 0;
static volatile uint8_t  fault_flags = 0;
// Bits: 0=IMU1 2=IMU2 2=IMU3 3=MAG1 4=MAG2 5=MAG3

// Raw sensor values — written by ISR, read by pack_frame (same ISR context)
static int16_t g_ax[3], g_ay[3], g_az[3];
static int16_t g_gx[3], g_gy[3], g_gz[3];
static int16_t g_mx[3], g_my[3], g_mz[3];
static bool    g_mag_ok[3] = {false, false, false};
static int8_t  g_temp_c = 0;
static float   mag_adj[3][3]; // sensitivity adjustment per IMU per axis

// ─────────────────────────────────────────────────────────────────────────────
// SPI primitives
// ─────────────────────────────────────────────────────────────────────────────
static const SPISettings SPI_CFG(8000000, MSBFIRST, SPI_MODE3);

static void cs_lo(uint8_t pin) { digitalWrite(pin, LOW);  }
static void cs_hi(uint8_t pin) { digitalWrite(pin, HIGH); }

static uint8_t mpu_rb(uint8_t cs, uint8_t reg) {
  SPI.beginTransaction(SPI_CFG);
  cs_lo(cs); SPI.transfer(reg | 0x80); uint8_t v = SPI.transfer(0); cs_hi(cs);
  SPI.endTransaction();
  return v;
}

static void mpu_wb(uint8_t cs, uint8_t reg, uint8_t val) {
  SPI.beginTransaction(SPI_CFG);
  cs_lo(cs); SPI.transfer(reg & 0x7F); SPI.transfer(val); cs_hi(cs);
  SPI.endTransaction();
}

static void mpu_burst(uint8_t cs, uint8_t reg, uint8_t *buf, uint8_t n) {
  SPI.beginTransaction(SPI_CFG);
  cs_lo(cs);
  SPI.transfer(reg | 0x80);
  for (uint8_t i = 0; i < n; i++) buf[i] = SPI.transfer(0);
  cs_hi(cs);
  SPI.endTransaction();
}

// ─────────────────────────────────────────────────────────────────────────────
// AK8963 helpers (called only during setup, via I2C bypass)
// ─────────────────────────────────────────────────────────────────────────────
static void ak_bypass_on(uint8_t cs) {
  mpu_wb(cs, REG_USER_CTRL,   0x00);
  mpu_wb(cs, REG_INT_PIN_CFG, 0x02);
  delay(5);
}
static void ak_bypass_off(uint8_t cs) {
  mpu_wb(cs, REG_INT_PIN_CFG, 0x00);
  mpu_wb(cs, REG_USER_CTRL,   0x20); // re-enable I2C master
  delay(5);
}
static uint8_t ak_rb(uint8_t reg) {
  Wire.beginTransmission(AK_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)AK_ADDR, (uint8_t)1);
  return Wire.available() ? Wire.read() : 0xFF;
}
static void ak_wb(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(AK_ADDR);
  Wire.write(reg); Wire.write(val);
  Wire.endTransmission();
}

// ─────────────────────────────────────────────────────────────────────────────
// MPU-9250 + AK8963 full initialisation
// ─────────────────────────────────────────────────────────────────────────────
static bool mpu_init(uint8_t cs, uint8_t idx) {
  // Power on, PLL clock source
  mpu_wb(cs, REG_PWR_MGMT_1, 0x01);
  delay(10);

  // WHO_AM_I check
  uint8_t who = mpu_rb(cs, REG_WHO_AM_I);
  if (who != 0x71 && who != 0x73) {
    fault_flags |= (1 << idx);
    return false;
  }

  // Gyro: ±2000 dps, DLPF 92 Hz bandwidth
  mpu_wb(cs, REG_GYRO_CONFIG, 0x18);
  mpu_wb(cs, REG_CONFIG,      0x02);

  // Accel: ±16g, DLPF 99 Hz
  mpu_wb(cs, REG_ACCEL_CONFIG, 0x18);
  mpu_wb(cs, REG_ACCEL_CFG2,   0x02);

  // Sample rate divider: 500 Hz  (1000 / (1+1) = 500)
  mpu_wb(cs, REG_SMPLRT_DIV, 0x01);

  // ── AK8963 setup via I2C bypass ─────────────────────────────────────────
  ak_bypass_on(cs);

  // Read factory sensitivity adjustment (fuse ROM mode)
  ak_wb(AK_CNTL1, 0x0F);
  delay(10);
  uint8_t asa[3] = {128, 128, 128};
  Wire.beginTransmission(AK_ADDR);
  Wire.write(AK_ASAX);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)AK_ADDR, (uint8_t)3);
  for (uint8_t i = 0; i < 3 && Wire.available(); i++) asa[i] = Wire.read();
  for (uint8_t i = 0; i < 3; i++)
    mag_adj[idx][i] = ((float)asa[i] - 128.0f) / 256.0f + 1.0f;

  // Power down → 16-bit continuous mode 2 (100 Hz)
  ak_wb(AK_CNTL1, 0x00); delay(10);
  ak_wb(AK_CNTL1, 0x16); delay(10);

  if (ak_rb(AK_WIA) != 0x48) fault_flags |= (1 << (idx + 3));

  ak_bypass_off(cs);

  // Configure MPU I2C master to auto-read 8 bytes from AK8963
  mpu_wb(cs, REG_I2C_MST_CTRL,  0x0D);          // I2C master 400 kHz
  mpu_wb(cs, REG_I2C_SLV0_ADDR, AK_ADDR | 0x80);// read from AK
  mpu_wb(cs, REG_I2C_SLV0_REG,  0x02);          // start at ST1
  mpu_wb(cs, REG_I2C_SLV0_CTRL, 0x88);          // enable, 8 bytes

  return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// Read one IMU (22 bytes: accel + temp + gyro + 8 ext_sens for AK data)
// ─────────────────────────────────────────────────────────────────────────────
static void read_imu(uint8_t cs, uint8_t idx) {
  uint8_t b[22];
  mpu_burst(cs, REG_ACCEL_XOUT_H, b, 22);

  g_ax[idx] = (int16_t)((b[0]  << 8) | b[1]);
  g_ay[idx] = (int16_t)((b[2]  << 8) | b[3]);
  g_az[idx] = (int16_t)((b[4]  << 8) | b[5]);

  if (idx == 0) {
    int16_t rt = (int16_t)((b[6] << 8) | b[7]);
    g_temp_c = (int8_t)(rt / 333.87f + 21.0f);
  }

  g_gx[idx] = (int16_t)((b[8]  << 8) | b[9]);
  g_gy[idx] = (int16_t)((b[10] << 8) | b[11]);
  g_gz[idx] = (int16_t)((b[12] << 8) | b[13]);

  // EXT_SENS_DATA (b[14..21]):  ST1, HXL, HXH, HYL, HYH, HZL, HZH, ST2
  if (b[14] & 0x01) { // DRDY
    int16_t mx = (int16_t)((b[16] << 8) | b[15]); // AK = little-endian
    int16_t my = (int16_t)((b[18] << 8) | b[17]);
    int16_t mz = (int16_t)((b[20] << 8) | b[19]);
    g_mx[idx] = (int16_t)(mx * mag_adj[idx][0]);
    g_my[idx] = (int16_t)(my * mag_adj[idx][1]);
    g_mz[idx] = (int16_t)(mz * mag_adj[idx][2]);
    g_mag_ok[idx] = true;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CRC-8 (poly 0x07, init 0x00)
// ─────────────────────────────────────────────────────────────────────────────
static uint8_t crc8(const uint8_t *d, uint8_t n) {
  uint8_t c = 0;
  for (uint8_t i = 0; i < n; i++) {
    c ^= d[i];
    for (uint8_t b = 0; b < 8; b++)
      c = (c & 0x80) ? (c << 1) ^ 0x07 : (c << 1);
  }
  return c;
}

// ─────────────────────────────────────────────────────────────────────────────
// Median of three int16
// ─────────────────────────────────────────────────────────────────────────────
static int16_t med3(int16_t a, int16_t b, int16_t c) {
  if (a > b) { int16_t t = a; a = b; b = t; }
  if (b > c) { int16_t t = b; b = c; c = t; }
  if (a > b) { int16_t t = a; a = b; b = t; }
  return b;
}

// ─────────────────────────────────────────────────────────────────────────────
// Pack 62-byte frame
// Byte layout (from spec Rev. 2.6):
//  0–1   sync (0xAA 0x55)
//  2–3   sequence (uint16 LE)
//  4–11  timestamp (uint64 LE)
//  12–17 gyro XYZ IMU1 (int16 LE x3)
//  18–23 accel XYZ IMU1
//  24–29 gyro XYZ IMU2
//  30–35 accel XYZ IMU2
//  36–41 gyro XYZ IMU3
//  42–47 accel XYZ IMU3
//  48–53 mag XYZ median (int16 LE x3)
//  54    temperature (int8)
//  55    fault flags (uint8)
//  56    CRC8 over bytes 0–55
//  57–61 padding 0x00
// ─────────────────────────────────────────────────────────────────────────────
static void pack_frame(uint8_t *f, uint64_t ts) {
  uint8_t p = 0;

  f[p++] = SYNC0;
  f[p++] = SYNC1;
  f[p++] = frame_seq & 0xFF;
  f[p++] = frame_seq >> 8;
  frame_seq++;

  for (uint8_t i = 0; i < 8; i++) f[p++] = (ts >> (i * 8)) & 0xFF;

  for (uint8_t i = 0; i < 3; i++) {
    f[p++] = g_gx[i] & 0xFF; f[p++] = g_gx[i] >> 8;
    f[p++] = g_gy[i] & 0xFF; f[p++] = g_gy[i] >> 8;
    f[p++] = g_gz[i] & 0xFF; f[p++] = g_gz[i] >> 8;
    f[p++] = g_ax[i] & 0xFF; f[p++] = g_ax[i] >> 8;
    f[p++] = g_ay[i] & 0xFF; f[p++] = g_ay[i] >> 8;
    f[p++] = g_az[i] & 0xFF; f[p++] = g_az[i] >> 8;
  }

  // Mag median
  int16_t mx = 0, my = 0, mz = 0;
  uint8_t ok = g_mag_ok[0] + g_mag_ok[1] + g_mag_ok[2];
  if (ok >= 2) {
    mx = med3(g_mx[0], g_mx[1], g_mx[2]);
    my = med3(g_my[0], g_my[1], g_my[2]);
    mz = med3(g_mz[0], g_mz[1], g_mz[2]);
  } else if (ok == 1) {
    for (uint8_t i = 0; i < 3; i++) if (g_mag_ok[i]) { mx=g_mx[i]; my=g_my[i]; mz=g_mz[i]; break; }
  }
  f[p++] = mx & 0xFF; f[p++] = (uint8_t)(mx >> 8);
  f[p++] = my & 0xFF; f[p++] = (uint8_t)(my >> 8);
  f[p++] = mz & 0xFF; f[p++] = (uint8_t)(mz >> 8);

  f[p++] = (uint8_t)g_temp_c;
  f[p++] = fault_flags;

  // CRC over bytes 0..55 (p == 56 here)
  f[p] = crc8(f, p);
  p++;

  // Pad to 62
  while (p < FRAME_SIZE) f[p++] = 0x00;
}

// ─────────────────────────────────────────────────────────────────────────────
// Timer1 COMPA ISR — 500 Hz
// ─────────────────────────────────────────────────────────────────────────────
ISR(TIMER1_COMPA_vect) {
  uint64_t ts = micros64();

  read_imu(CS0_PIN, 0);
  read_imu(CS1_PIN, 1);
  read_imu(CS2_PIN, 2);

  uint8_t nw = (ring_w + 1) % RING_DEPTH;
  if (nw != ring_r) {            // ring not full
    pack_frame(ring[ring_w], ts);
    ring_w = nw;
  }
  // If ring full: drop frame silently — loop() is not draining fast enough

  wdt_reset();
}

// ─────────────────────────────────────────────────────────────────────────────
// Timer1 init — CTC 500 Hz + OVF for uint64
// ─────────────────────────────────────────────────────────────────────────────
static void timer1_init() {
  cli();
  TCCR1A = 0;
  TCCR1B = 0;
  TCNT1  = 0;
  OCR1A  = 3999;                          // 16e6 / (8 * 500) - 1
  TCCR1B = (1 << WGM12) | (1 << CS11);   // CTC, prescaler 8
  TIMSK1 = (1 << OCIE1A) | (1 << TOIE1); // COMPA + OVF interrupts
  sei();
}

// ─────────────────────────────────────────────────────────────────────────────
// SETUP
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(0); // USB CDC — baud ignored
  // Wait briefly for USB enumeration (non-blocking)
  uint32_t t0 = millis();
  while (!Serial && (millis() - t0) < 2000);

  pinMode(CS0_PIN, OUTPUT); digitalWrite(CS0_PIN, HIGH);
  pinMode(CS1_PIN, OUTPUT); digitalWrite(CS1_PIN, HIGH);
  pinMode(CS2_PIN, OUTPUT); digitalWrite(CS2_PIN, HIGH);

  SPI.begin();
  Wire.begin();
  Wire.setClock(400000UL);

  delay(50); // IMU power-up settling time

  mpu_init(CS0_PIN, 0);
  mpu_init(CS1_PIN, 1);
  mpu_init(CS2_PIN, 2);

  timer1_init();
  wdt_enable(WDTO_2S); // 2-second hardware watchdog
}

// ─────────────────────────────────────────────────────────────────────────────
// LOOP — drain ring buffer to USB as fast as possible
// ─────────────────────────────────────────────────────────────────────────────
void loop() {
  while (ring_r != ring_w) {
    Serial.write(ring[ring_r], FRAME_SIZE);
    ring_r = (ring_r + 1) % RING_DEPTH;
  }
  wdt_reset();
}
