"""
ARES-NAV — Primary Flight Display  Rev. 2.8
PyQt5, 60 Hz, fully resolution-independent.

Corrections vs Rev. 2.7 / PFD v1.1:
  [C1] os.uname() → platform.system() — Windows/Mac safe for development
  [C2] Optional[QPixmap] type hint — Python 3.9 compatible
  [C3] QTransform order corrected: translate(cx,cy) → rotate → translate(offset)
       Qt applies transforms right-to-left; previous order caused misaligned horizon
  [C4] Pitch offset sign corrected: nose-up (+pitch) → horizon moves DOWN
       → texture shifts UP → pitch_offset added (not subtracted) in translate
  [C5] p.resetTransform() inserted after horizon asset draw — prevents
       subsequent elements (pitch ladder, FD bars) from inheriting the transform
  [C6] Status bar right-side text: removed duplicate QPainter.drawText() call
       that caused ghosted characters at half-pixel offset
  [C7] p.end() called explicitly at end of paintEvent — releases QPainter
       resources immediately rather than waiting for garbage collection
  [C8] Simulator state snapshot uses dataclasses.replace() — O(1) threadsafe
       shallow copy; replaces copy.deepcopy() which was O(n) and unnecessary

Revision: 2.8  |  Duwald Systems  |  March 2026
"""

import sys
import math
import time
import json
import os
import platform
import argparse
from typing import Optional, Dict, Tuple

from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5.QtCore    import Qt, QTimer, QPoint
from PyQt5.QtGui     import (QPainter, QColor, QPen, QBrush, QFont,
                              QFontMetrics, QTransform, QPolygon,
                              QPainterPath, QPixmap)

from simulator import Simulator, AresNavState

# ── Colours ───────────────────────────────────────────────────────────────────
SKY_TOP  = QColor(0,   80,  160)
GND_HOR  = QColor(120, 80,  20)
WHITE    = QColor(255, 255, 255)
BLACK    = QColor(0,   0,   0)
AMBER    = QColor(232, 100, 10)
GREEN    = QColor(0,   200, 80)
CYAN     = QColor(0,   220, 220)
MAGENTA  = QColor(220, 0,   220)
RED      = QColor(220, 30,  30)
YELLOW   = QColor(240, 200, 0)
GRAY     = QColor(120, 120, 120)
DARK     = QColor(15,  15,  20)
PANEL_BG = QColor(10,  12,  18, 220)

ASSET_DIRS = [
    "/boot/firmware/ares-nav/assets",
    "/boot/ares-nav/assets",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets"),
    "./assets",
]

def find_asset(name: str) -> str:
    for d in ASSET_DIRS:
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    return ""


class PFD(QWidget):
    def __init__(self, sim: Simulator, profile: dict = None):
        super().__init__()
        self.sim     = sim
        self.profile = profile or {}
        self.setWindowTitle("ARES-NAV PFD  Rev. 2.8")
        self.setStyleSheet("background-color: black;")

        # Raw pixmaps — loaded once from disk
        self._raw: Dict[str, Optional[QPixmap]] = {}
        for name in ["horizon_base.png", "bank_arc.png",
                     "aircraft_symbol.png", "logo.png"]:
            path = find_asset(name)
            self._raw[name] = QPixmap(path) if path else None

        # Scaled cache — cleared on resize, populated lazily
        self._cache: Dict[Tuple[str, int], QPixmap] = {}

        self._fps        = 0.0
        self._fps_frames = 0
        self._fps_t0     = time.monotonic()

        # [C1] platform.system() works on Windows/Mac/Linux
        on_pi = platform.system() == "Linux" and \
                os.path.exists("/boot/firmware")
        if on_pi or "--fullscreen" in sys.argv:
            self.showFullScreen()
        else:
            self.resize(1024, 600)
            self.show()

        self._timer = QTimer()
        self._timer.timeout.connect(self.update)
        self._timer.start(16)

    def resizeEvent(self, event):
        self._cache.clear()
        super().resizeEvent(event)

    # ── Asset helper ──────────────────────────────────────────────────────────
    def _asset(self, name: str, size_px: int) -> Optional[QPixmap]:
        raw = self._raw.get(name)
        if raw is None or raw.isNull():
            return None
        key = (name, size_px)
        if key not in self._cache:
            self._cache[key] = raw.scaled(
                size_px, size_px,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation)
        return self._cache[key]

    # ── Layout ────────────────────────────────────────────────────────────────
    def _sc(self, px: float) -> int:
        return max(1, int(px * self.S))

    def _font(self, size: float, bold=False) -> QFont:
        f = QFont("Liberation Mono", max(8, self._sc(size)))
        f.setBold(bold)
        return f

    def _sans(self, size: float, bold=False) -> QFont:
        f = QFont("Liberation Sans", max(8, self._sc(size)))
        f.setBold(bold)
        return f

    def _text(self, p, color, text, x, y, size,
              bold=False, center=True, mono=False, right=False):
        f  = self._font(size, bold) if mono else self._sans(size, bold)
        fm = QFontMetrics(f)
        w  = fm.boundingRect(text).width()
        if center: x -= w // 2
        if right:  x -= w
        p.setPen(QPen(color))
        p.setFont(f)
        p.drawText(x, y, text)

    # ── paintEvent ────────────────────────────────────────────────────────────
    def paintEvent(self, event):
        self.W  = self.width()
        self.H  = self.height()
        self.CX = self.W // 2
        self.CY = self.H // 2
        self.S  = min(self.W, self.H) / 600.0

        state = self.sim.get_state()

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(0, 0, self.W, self.H, DARK)

        if not state.aligned:
            self._draw_align(p, state)
        else:
            self._draw_attitude(p, state)
            self._draw_heading_tape(p, state)
            self._draw_speed_box(p, state)
            self._draw_altitude_box(p, state)
            self._draw_vs_bar(p, state)
            self._draw_wind(p, state)
            self._draw_waypoint(p, state)
            self._draw_annunciators(p, state)
            self._draw_status_bar(p, state)
            if state.fd_active:
                self._draw_fd_bars(p, state)

        # FPS counter (dev only)
        self._fps_frames += 1
        now = time.monotonic()
        if now - self._fps_t0 >= 1.0:
            self._fps        = self._fps_frames / (now - self._fps_t0)
            self._fps_frames = 0
            self._fps_t0     = now
        self._text(p, GRAY, f"{self._fps:.0f}fps",
                   self.W - self._sc(4), self.H - self._sc(4),
                   9, mono=True, center=False, right=True)

        # [C7] Explicit end — do not rely on GC
        p.end()

    # ── Align screen ──────────────────────────────────────────────────────────
    def _draw_align(self, p, s):
        cx, cy = self.CX, self.CY
        logo = self._asset("logo.png", self._sc(160))
        if logo:
            p.drawPixmap(cx - logo.width()//2, self._sc(20), logo)
        self._text(p, AMBER, "ARES-NAV", cx, self._sc(50), 36, bold=True)
        self._text(p, WHITE, "ALIGNING  —  DO NOT MOVE AIRCRAFT",
                   cx, self._sc(68), 13)
        items = [("MCU 1",s.mcu1_link),("MCU 2",s.mcu2_link),
                 ("IMU 1",s.imu1_ok),  ("IMU 2",s.imu2_ok),
                 ("IMU 3",s.imu3_ok),  ("MAG",  s.mag_ok),
                 ("BARO", s.baro_ok),  ("GNSS", s.gnss_ok)]
        col_x = cx - self._sc(130)
        row_y = int(cy * 0.85)
        for i, (lbl, ok) in enumerate(items):
            xi = col_x + (i % 4) * self._sc(68)
            yi = row_y + (i // 4) * self._sc(28)
            self._text(p, GREEN if ok else GRAY,
                       ("✓ " if ok else "○ ") + lbl, xi, yi, 10, center=False)
        fixes = ["No Fix","2D","3D","3D+SBAS"]
        fc = GREEN if s.gnss_fix>=2 else (YELLOW if s.gnss_fix==1 else GRAY)
        self._text(p, fc,
                   f"GPS {fixes[min(s.gnss_fix,3)]}  {s.satellites}sv  HDOP {s.hdop:.1f}",
                   cx, self.H - self._sc(28), 11)
        self._text(p, GRAY,
                   f"Lat {s.lat:.4f}°  Lon {s.lon:.4f}°  Alt {s.altitude_ft:.0f}ft",
                   cx, self.H - self._sc(12), 9)

    # ── Attitude ──────────────────────────────────────────────────────────────
    def _draw_attitude(self, p, s):
        cx, cy = self.CX, self.CY
        r      = self._sc(200)
        ppd    = self._sc(4.5)

        # [C4] Corrected sign:
        # pitch_deg positive = nose up
        # nose up → real horizon drops → texture must move UP → positive offset
        pitch_offset = int(s.pitch_deg * ppd)

        clip = QPainterPath()
        clip.addEllipse(cx - r, cy - r, r*2, r*2)
        p.save()
        p.setClipPath(clip)

        horizon = self._asset("horizon_base.png", r * 3)
        if horizon:
            hw, hh = horizon.width(), horizon.height()
            # [C3] Corrected QTransform order:
            # Qt applies transforms in reverse order of method calls.
            # We need: (1) place texture centred at cx,cy
            #          (2) rotate around that centre by roll
            #          (3) shift texture up by pitch_offset (in rotated space)
            # Method call order (reversed from application order):
            t = QTransform()
            t.translate(cx, cy)                 # applied 3rd: move to display centre
            t.rotate(-s.roll_deg)               # applied 2nd: rotate around centre
            t.translate(-hw//2, -hh//2 - pitch_offset)  # applied 1st: centre + pitch
            p.setTransform(t)
            p.drawPixmap(0, 0, horizon)
            # [C5] Reset transform before pitch ladder
            p.resetTransform()
        else:
            p.translate(cx, cy)
            p.rotate(-s.roll_deg)
            p.fillRect(-r*2, -r*2 - pitch_offset, r*4, r*2+r+pitch_offset, SKY_TOP)
            p.fillRect(-r*2, -pitch_offset,        r*4, r*3,                GND_HOR)
            p.setPen(QPen(WHITE, max(2, self._sc(2))))
            p.drawLine(-r, -pitch_offset, r, -pitch_offset)
            p.resetTransform()

        # Pitch ladder
        p.translate(cx, cy)
        p.rotate(-s.roll_deg)
        p.setFont(self._font(9))
        for deg in range(-20, 25, 5):
            if deg == 0:
                continue
            yp = -pitch_offset - int(deg * ppd)
            if abs(yp) > r * 0.85:
                continue
            lw    = self._sc(40 if deg%10==0 else 20)
            color = WHITE if deg > 0 else QColor(180,120,50)
            p.setPen(QPen(color, max(1, self._sc(1.5))))
            p.drawLine(-lw, yp, lw, yp)
            if deg % 10 == 0:
                p.setPen(QPen(WHITE))
                lb = str(abs(deg))
                p.drawText(-lw - self._sc(22), yp + self._sc(4), lb)
                p.drawText( lw + self._sc(6),  yp + self._sc(4), lb)
        p.resetTransform()
        p.restore()

        # Bank arc (static asset)
        arc_r = r + self._sc(12)
        arc_sz = arc_r*2 + self._sc(30)
        arc_px = self._asset("bank_arc.png", arc_sz)
        if arc_px:
            p.drawPixmap(cx - arc_px.width()//2,
                         cy - arc_px.height()//2, arc_px)
        else:
            p.setPen(QPen(WHITE, max(1,self._sc(1.5))))
            for deg in [-60,-45,-30,-20,-10,10,20,30,45,60]:
                a = math.radians(deg-90)
                x1,y1 = cx+int(arc_r*math.cos(a)), cy+int(arc_r*math.sin(a))
                o = arc_r + self._sc(8 if deg%30==0 else 5)
                p.drawLine(x1,y1, cx+int(o*math.cos(a)), cy+int(o*math.sin(a)))

        # Bank pointer (dynamic — always code)
        ba = math.radians(-s.roll_deg-90)
        px_, py_ = cx+int(arc_r*math.cos(ba)), cy+int(arc_r*math.sin(ba))
        pts = self._rot([(0,-self._sc(10)),(-self._sc(6),0),(self._sc(6),0)],
                        -s.roll_deg, px_, py_)
        p.setPen(QPen(WHITE,1)); p.setBrush(QBrush(WHITE))
        p.drawPolygon(QPolygon([QPoint(*pt) for pt in pts]))
        p.setBrush(Qt.NoBrush)

        # Aircraft symbol (static asset)
        sym_sz = self._sc(140)
        sym = self._asset("aircraft_symbol.png", sym_sz)
        if sym:
            p.drawPixmap(cx-sym.width()//2, cy-sym.height()//2, sym)
        else:
            pen = QPen(WHITE, max(2,self._sc(2.5)))
            p.setPen(pen)
            p.drawLine(cx-self._sc(60), cy, cx-self._sc(10), cy)
            p.drawLine(cx-self._sc(10), cy, cx-self._sc(10), cy+self._sc(8))
            p.drawLine(cx+self._sc(60), cy, cx+self._sc(10), cy)
            p.drawLine(cx+self._sc(10), cy, cx+self._sc(10), cy+self._sc(8))
            p.setPen(Qt.NoPen); p.setBrush(QBrush(WHITE))
            r4 = self._sc(4)
            p.drawEllipse(cx-r4, cy-r4, r4*2, r4*2)
            p.setBrush(Qt.NoBrush)

    def _rot(self, pts, deg, cx, cy):
        r = math.radians(deg)
        c, s = math.cos(r), math.sin(r)
        return [(int(x*c - y*s + cx), int(x*s + y*c + cy)) for x,y in pts]

    # ── FD bars ───────────────────────────────────────────────────────────────
    def _draw_fd_bars(self, p, s):
        cx, cy = self.CX, self.CY
        p.setPen(QPen(MAGENTA, max(3,self._sc(3))))
        py = cy - int(s.fd_pitch_cmd * self.S * 4.5)
        p.drawLine(cx-self._sc(50), py, cx+self._sc(50), py)
        rx = cx + int(s.fd_roll_cmd * self.S * 4.5)
        p.drawLine(rx, cy-self._sc(50), rx, cy+self._sc(50))

    # ── Heading tape ──────────────────────────────────────────────────────────
    def _draw_heading_tape(self, p, s):
        cx     = self.CX
        tape_h = self._sc(36)
        tape_w = self._sc(300)
        tape_y = self.H - self._sc(60)
        tape_x = cx - tape_w//2
        ppd    = tape_w / 40.0
        COMP   = {0:"N",45:"NE",90:"E",135:"SE",
                  180:"S",225:"SW",270:"W",315:"NW"}
        p.fillRect(tape_x, tape_y, tape_w, tape_h, PANEL_BG)
        for off in range(-25, 26):
            d = int(s.heading_deg + off) % 360
            x = cx + int(off * ppd)
            if not (tape_x <= x <= tape_x + tape_w): continue
            if d % 10 == 0:
                maj = d % 30 == 0
                p.setPen(QPen(CYAN if maj else WHITE, max(1,self._sc(1.5))))
                th = self._sc(14 if maj else 8)
                p.drawLine(x, tape_y+2, x, tape_y+th)
                if maj:
                    self._text(p, CYAN, COMP.get(d,f"{d:03d}"),
                               x, tape_y+self._sc(28), 10)
        pts = [(cx,tape_y+2),(cx-self._sc(8),tape_y-self._sc(8)),
               (cx+self._sc(8),tape_y-self._sc(8))]
        p.setPen(QPen(WHITE,1)); p.setBrush(QBrush(WHITE))
        p.drawPolygon(QPolygon([QPoint(*pt) for pt in pts]))
        p.setBrush(Qt.NoBrush)
        bw = self._sc(70)
        p.fillRect(cx-bw//2, tape_y+tape_h, bw, self._sc(24), BLACK)
        p.setPen(QPen(WHITE,1))
        p.drawRect(cx-bw//2, tape_y+tape_h, bw, self._sc(24))
        self._text(p, WHITE, f"{s.heading_deg:05.1f}",
                   cx, tape_y+tape_h+self._sc(17), 12, bold=True, mono=True)
        self._text(p, CYAN, f"CRS {s.course_deg:03.0f}°",
                   tape_x+tape_w+self._sc(8),
                   tape_y+self._sc(20), 10, center=False)

    # ── Speed box ─────────────────────────────────────────────────────────────
    def _draw_speed_box(self, p, s):
        bx,by = self._sc(20), int(self.H*0.35)
        bw,bh = self._sc(80), self._sc(50)
        p.fillRect(bx,by,bw,bh,PANEL_BG)
        p.setPen(QPen(WHITE,1)); p.drawRect(bx,by,bw,bh)
        self._text(p,GRAY,"GS",bx+bw//2,by+self._sc(14),9)
        self._text(p,WHITE,f"{s.groundspeed_kts:.0f}",
                   bx+bw//2,by+self._sc(34),20,bold=True,mono=True)
        self._text(p,GRAY,"kt",bx+bw//2,by+self._sc(46),9)
        gs = s.groundspeed_kts
        if gs > s.v_ne_kts:
            self._flash_box(p,"OVERSPD",RED,bx,by-self._sc(22),bw)
        elif gs > s.v_ne_kts*0.9:
            self._text(p,YELLOW,"CAUTION",bx+bw//2,by-self._sc(8),9)
        elif 5 < gs < s.v_s_kts:
            self._flash_box(p,"STALL",RED,bx,by-self._sc(22),bw)
        if s.v_ne_kts > 0:
            f = min(s.v_bg_kts/s.v_ne_kts, 1.0)
            bgy = by + int(bh*(1.0-f))
            p.setPen(QPen(GREEN,max(2,self._sc(2))))
            p.drawLine(bx,bgy,bx+self._sc(8),bgy)

    # ── Altitude box ──────────────────────────────────────────────────────────
    def _draw_altitude_box(self, p, s):
        bw = self._sc(80)
        bx = self.W - self._sc(20) - bw
        by = int(self.H*0.35)
        bh = self._sc(50)
        p.fillRect(bx,by,bw,bh,PANEL_BG)
        p.setPen(QPen(WHITE,1)); p.drawRect(bx,by,bw,bh)
        self._text(p,GRAY,"ALT",bx+bw//2,by+self._sc(14),9)
        alt = s.altitude_ft
        sz  = 16 if abs(alt) >= 10000 else 20
        self._text(p,WHITE,f"{alt:5.0f}" if abs(alt)>=10000 else f"{alt:4.0f}",
                   bx+bw//2,by+self._sc(35),sz,bold=True,mono=True)
        self._text(p,GRAY,"ft",bx+bw//2,by+self._sc(47),9)
        self._text(p,CYAN,f"{s.qnh_hpa:.2f}",bx+bw//2,by+bh+self._sc(14),9)

    # ── VS bar ────────────────────────────────────────────────────────────────
    def _draw_vs_bar(self, p, s):
        vs    = s.vertical_speed_fpm
        bar_h = self._sc(120)
        x     = self.W - self._sc(14)
        cy    = int(self.H*0.45)
        defl  = max(-1.0, min(1.0, vs/1000.0))
        seg_h = int(abs(defl)*bar_h/2)
        seg_y = cy - int(defl*bar_h/2) if defl>0 else cy
        color = GREEN if vs>0 else AMBER
        if seg_h > 2:
            p.fillRect(x-self._sc(8), seg_y, self._sc(8), seg_h, color)
        p.setPen(QPen(GRAY,1))
        p.drawLine(x-self._sc(10),cy,x,cy)
        if abs(vs) > 50:
            self._text(p,color,f"{vs:+.0f}",
                       x-self._sc(4),cy-int(defl*bar_h/2)-self._sc(6),
                       9,mono=True,right=True,center=False)

    # ── Status bar ────────────────────────────────────────────────────────────
    def _draw_status_bar(self, p, s):
        # [C6] Single draw pass — no duplicate text causing ghosting
        p.fillRect(0, 0, self.W, self._sc(20), QColor(10,10,20,210))
        y = self._sc(14)
        x = self._sc(10)
        for lbl, active in [("FD",s.fd_active),("CMD",s.fd_active),
                             ("LNAV",s.lnav_active)]:
            if active:
                self._text(p,CYAN,lbl,x,y,11,bold=True,center=False)
                x += self._sc(50)
        callsign = self.profile.get("callsign",      s.callsign)
        aircraft = self.profile.get("aircraft_name", s.aircraft_name)
        self._text(p, WHITE, f"{callsign}  /  {aircraft}",
                   self.W - self._sc(10), y,
                   10, center=False, right=True)

    # ── Wind ──────────────────────────────────────────────────────────────────
    def _draw_wind(self, p, s):
        ar = self._sc(20)
        wx, wy = self._sc(30), self._sc(45)
        ax, ay = wx+ar, wy+ar+self._sc(5)
        if not s.wind_valid:
            self._text(p,AMBER,"WIND EST",ax,wy+self._sc(8),9,center=False)
            self._text(p,GRAY,"---/---kt",ax,wy+self._sc(22),10,center=False)
            return
        wr = math.radians(s.wind_dir_deg+180-s.heading_deg)
        tx,ty = ax+int(ar*math.sin(wr)), ay-int(ar*math.cos(wr))
        bx,by = ax-int(ar*math.sin(wr)), ay+int(ar*math.cos(wr))
        p.setPen(QPen(WHITE,max(2,self._sc(2))))
        p.drawLine(bx,by,tx,ty)
        pr = wr+math.pi/2; aw = self._sc(5)
        ah = [QPoint(tx,ty),
              QPoint(tx-int(aw*math.sin(wr)-aw*0.5*math.sin(pr)),
                     ty+int(aw*math.cos(wr)-aw*0.5*math.cos(pr))),
              QPoint(tx-int(aw*math.sin(wr)+aw*0.5*math.sin(pr)),
                     ty+int(aw*math.cos(wr)+aw*0.5*math.cos(pr)))]
        p.setPen(Qt.NoPen); p.setBrush(QBrush(WHITE))
        p.drawPolygon(QPolygon(ah)); p.setBrush(Qt.NoBrush)
        lx = ax+ar+self._sc(8)
        self._text(p,AMBER,"WIND EST",lx,wy+self._sc(8),8,center=False)
        self._text(p,WHITE,f"{s.wind_dir_deg:03.0f}\u00b0M",lx,wy+self._sc(20),10,center=False)
        self._text(p,WHITE,f"{s.wind_speed_kts:.0f}kt",lx,wy+self._sc(32),10,center=False)

    # ── Waypoint ──────────────────────────────────────────────────────────────
    def _draw_waypoint(self, p, s):
        if not s.wp_name: return
        x  = self.W - self._sc(10)
        y0 = int(self.H*0.6)
        em, es = int(s.wp_eta_s/60), int(s.wp_eta_s%60)
        for color,text,dy in [
            (CYAN,  s.wp_name,                           0),
            (WHITE, f"{s.wp_dist_nm:.1f} nm",            self._sc(18)),
            (WHITE, f"{s.wp_bearing_deg:03.0f}\u00b0M",  self._sc(32)),
            (GRAY,  f"ETA {em:02d}:{es:02d}",            self._sc(46)),
        ]:
            self._text(p,color,text,x,y0+dy,10,right=True,center=False)

    # ── Annunciators ──────────────────────────────────────────────────────────
    def _draw_annunciators(self, p, s):
        faults = []
        if not s.mcu1_link:  faults.append(("MCU1 LINK",AMBER))
        if not s.mcu2_link:  faults.append(("MCU2 LINK",AMBER))
        if not s.gnss_ok:    faults.append(("GPS LOST", AMBER))
        if not s.baro_ok:    faults.append(("BARO FAIL",AMBER))
        if not s.mag_ok:     faults.append(("MAG FAIL", AMBER))
        if s.master_caution: faults.append(("MASTER CAUTION",RED))
        if not faults: return
        cx = self.CX
        y  = self.H - self._sc(90)
        fl = int(time.monotonic()*2)%2==0
        for text,color in faults:
            bw = len(text)*self._sc(8)+self._sc(16)
            bh = self._sc(20)
            if fl:
                p.fillRect(cx-bw//2,y-self._sc(16),bw,bh,color)
                self._text(p,BLACK,text,cx,y,11,bold=True)
            else:
                self._text(p,color,text,cx,y,11,bold=True)
            y -= self._sc(24)

    def _flash_box(self, p, text, color, x, y, w):
        bh = self._sc(18)
        if int(time.monotonic()*2)%2==0:
            p.fillRect(x,y,w,bh,color)
            self._text(p,BLACK,text,x+w//2,y+self._sc(13),10,bold=True)
        else:
            self._text(p,color,text,x+w//2,y+self._sc(13),10,bold=True)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.close()
        elif event.key() == Qt.Key_F:
            if self.isFullScreen():
                self.showNormal(); self.resize(1024,600)
            else:
                self.showFullScreen()


# ── Entry point ───────────────────────────────────────────────────────────────
def load_profile(name: str) -> dict:
    for d in ["/boot/firmware/ares-nav/profiles",
              "/boot/ares-nav/profiles", "."]:
        path = os.path.join(d, f"{name}.json")
        if os.path.exists(path):
            with open(path) as f:
                return json.load(f)
    return {}


def main():
    parser = argparse.ArgumentParser(description="ARES-NAV PFD Rev. 2.8")
    parser.add_argument("--profile",    default="motorglider")
    parser.add_argument("--fullscreen", action="store_true")
    args = parser.parse_args()
    profile = load_profile(args.profile)
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    sim = Simulator(profile=profile)
    sim.start()
    pfd = PFD(sim, profile=profile)
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
