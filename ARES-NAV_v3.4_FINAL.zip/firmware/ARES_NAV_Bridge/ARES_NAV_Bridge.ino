/*
 * ARES-NAV — Single Arduino Bridge Firmware
 * Hardware: Arduino (any) + MPU-9250 (GY-9250) + BMP280 via I2C
 * 
 * PURPOSE: Übergangs-Firmware bis MCU 1 (SPI) + MCU 2 getrennt sind.
 * Sendet ARES-NAV-kompatible Binary Frames über USB Serial.
 * Kompatibel mit mcu_reader.py auf dem Pi — keine Pi-Änderungen nötig.
 *
 * FRAME OUTPUT:
 *   Alle 100ms (10 Hz):
 *     → 62-Byte IMU Frame  (Sync 0xAA 0x55) — Gyro/Accel/Mag
 *     → 48-Byte PERI Frame (Sync 0xBB 0x66) — Baro/Encoder
 *
 * WIRING:
 *   MPU-9250  VCC → 3.3V
 *   MPU-9250  GND → GND
 *   MPU-9250  SDA → A4 (SDA)
 *   MPU-9250  SCL → A5 (SCL)
 *   MPU-9250  AD0 → GND  (I2C Adresse 0x68)
 *
 *   BMP280    VCC → 3.3V
 *   BMP280    GND → GND
 *   BMP280    SDA → A4  (gleicher I2C Bus)
 *   BMP280    SCL → A5
 *   BMP280    SDO → GND (I2C Adresse 0x76)
 *
 *   Encoder KY-040 (optional):
 *   CLK → Pin 7,  DT → Pin 6,  SW → Pin 5,  VCC → 5V,  GND → GND
 *
 * Pro Micro: LED_RX = Pin 17 (active LOW) blinkt bei Encoder-Events
 *
 * Revision 3.2  |  Duwald Systems  |  March 2026
 */

#include <Wire.h>
#include <avr/wdt.h>

// ── MPU-9250 I2C Adressen ─────────────────────────────────────────────────────
#define MPU_ADDR      0x68   // AD0 = GND
#define AK8963_ADDR   0x0C   // Magnetometer (via MPU I2C pass-through)

// MPU-9250 Register
#define MPU_SMPLRT_DIV   0x19
#define MPU_CONFIG       0x1A
#define MPU_GYRO_CFG     0x1B   // ±2000°/s → 0x18  (16.4 LSB/°/s)
#define MPU_ACCEL_CFG    0x1C   // ±16g     → 0x18  (2048 LSB/g)
#define MPU_ACCEL_CFG2   0x1D
#define MPU_INT_PIN_CFG  0x37   // INT/DRDY config — I2C bypass enable
#define MPU_INT_ENABLE   0x38
#define MPU_ACCEL_XOUT_H 0x3B
#define MPU_TEMP_OUT_H   0x41
#define MPU_GYRO_XOUT_H  0x43
#define MPU_PWR_MGMT_1   0x6B
#define MPU_WHO_AM_I     0x75

// AK8963 Register
#define AK_WIA    0x00   // WHO AM I → should return 0x48
#define AK_ST1    0x02   // Status 1 (data ready)
#define AK_HXL    0x03   // Mag data start
#define AK_CNTL1  0x0A   // Control: mode + resolution

// ── BMP280 ────────────────────────────────────────────────────────────────────
#define BMP_ADDR      0x76
#define BMP_CHIP_ID   0xD0
#define BMP_RESET_REG 0xE0
#define BMP_CTRL_MEAS 0xF4
#define BMP_CONFIG    0xF5
#define BMP_PRESS_MSB 0xF7

struct BmpCal {
  uint16_t T1; int16_t T2, T3;
  uint16_t P1; int16_t P2,P3,P4,P5,P6,P7,P8,P9;
} bmp_cal;
bool bmp_ok = false;

// ── Encoder ───────────────────────────────────────────────────────────────────
#define ENC_CLK 7
#define ENC_DT  6
#define ENC_SW  5

volatile int8_t  enc_delta  = 0;
volatile uint8_t enc_btn    = 0;
static uint8_t   last_clk_state;
static uint8_t   last_sw_state;
static uint32_t  sw_down_ms = 0;

// ── LED (Pro Micro RX LED active LOW) ─────────────────────────────────────────
#define LED_PIN 17
struct Blink { uint8_t count; uint32_t next_ms; bool on; };
static Blink blink_led = {0, 0, false};

void blink_trigger(uint8_t times) {
  if (blink_led.count == 0) {
    blink_led.count = times * 2;
    blink_led.on    = false;
    blink_led.next_ms = millis();
  }
}
void blink_update() {
  if (!blink_led.count || millis() < blink_led.next_ms) return;
  blink_led.on = !blink_led.on;
  digitalWrite(LED_PIN, blink_led.on ? LOW : HIGH);
  blink_led.next_ms = millis() + 40;
  if (!--blink_led.count) digitalWrite(LED_PIN, HIGH);
}

// ── Frame constants ───────────────────────────────────────────────────────────
#define IMU_FRAME_SIZE  62
#define PERI_FRAME_SIZE 48

// ── CRC8 polynomial 0x07 ──────────────────────────────────────────────────────
uint8_t crc8(uint8_t *d, uint8_t len) {
  uint8_t c = 0;
  for (uint8_t i = 0; i < len; i++) {
    c ^= d[i];
    for (uint8_t j = 0; j < 8; j++)
      c = (c & 0x80) ? (c << 1) ^ 0x07 : (c << 1);
  }
  return c;
}

// ── uint64 timestamp ──────────────────────────────────────────────────────────
static uint32_t us_overflow = 0;
static uint32_t us_last     = 0;
uint64_t micros64() {
  uint32_t now = micros();
  if (now < us_last) us_overflow++;
  us_last = now;
  return ((uint64_t)us_overflow << 32) | now;
}

// ── Write helpers ─────────────────────────────────────────────────────────────
static uint8_t p;   // global write cursor for frame packing

void w_u8(uint8_t *f, uint8_t v)    { f[p++] = v; }
void w_i8(uint8_t *f, int8_t v)     { f[p++] = (uint8_t)v; }
void w_u16(uint8_t *f, uint16_t v)  { f[p++]=v&0xFF; f[p++]=v>>8; }
void w_i16(uint8_t *f, int16_t v)   { w_u16(f,(uint16_t)v); }
void w_u64(uint8_t *f, uint64_t v)  { for(uint8_t i=0;i<8;i++) f[p++]=(v>>(i*8))&0xFF; }
void w_float(uint8_t *f, float v)   { uint8_t *b=(uint8_t*)&v; for(uint8_t i=0;i<4;i++) f[p++]=b[i]; }
void w_double(uint8_t *f, double v) { uint8_t *b=(uint8_t*)&v; for(uint8_t i=0;i<8;i++) f[p++]=b[i]; }

// ── I2C helpers ───────────────────────────────────────────────────────────────
void mpu_write(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg); Wire.write(val);
  Wire.endTransmission();
}

bool mpu_read_bytes(uint8_t reg, uint8_t *buf, uint8_t len) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  Wire.requestFrom((uint8_t)MPU_ADDR, len);
  for (uint8_t i = 0; i < len; i++) {
    if (!Wire.available()) return false;
    buf[i] = Wire.read();
  }
  return true;
}

bool ak_read_bytes(uint8_t reg, uint8_t *buf, uint8_t len) {
  Wire.beginTransmission(AK8963_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  Wire.requestFrom((uint8_t)AK8963_ADDR, len);
  for (uint8_t i = 0; i < len; i++) {
    if (!Wire.available()) return false;
    buf[i] = Wire.read();
  }
  return true;
}

void ak_write(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(AK8963_ADDR);
  Wire.write(reg); Wire.write(val);
  Wire.endTransmission();
}

// ── MPU-9250 init ─────────────────────────────────────────────────────────────
bool mpu_init() {
  // Check WHO_AM_I (MPU-9250 = 0x71, some clones = 0x73 or 0x70)
  uint8_t who = 0;
  mpu_read_bytes(MPU_WHO_AM_I, &who, 1);
  if (who != 0x71 && who != 0x73 && who != 0x70) return false;

  mpu_write(MPU_PWR_MGMT_1, 0x80);   // Reset
  delay(100);
  mpu_write(MPU_PWR_MGMT_1, 0x01);   // Auto clock select (PLL)
  delay(10);

  // Gyro ±2000°/s  →  16.4 LSB/(°/s)
  mpu_write(MPU_GYRO_CFG,  0x18);
  // Accel ±16g     →  2048 LSB/g
  mpu_write(MPU_ACCEL_CFG, 0x18);
  // DLPF bandwidth ~41 Hz
  mpu_write(MPU_CONFIG,    0x03);
  // Sample rate = 1 kHz / (1+4) = 200 Hz
  mpu_write(MPU_SMPLRT_DIV, 0x04);

  // Enable I2C bypass so Pi can access AK8963 directly
  mpu_write(MPU_INT_PIN_CFG, 0x02);  // BYPASS_EN = 1
  delay(10);

  // Init AK8963
  uint8_t ak_who = 0;
  ak_read_bytes(AK_WIA, &ak_who, 1);
  if (ak_who == 0x48) {
    // 16-bit continuous measurement mode 2 (100 Hz)
    ak_write(AK_CNTL1, 0x16);
    delay(10);
  }

  return true;
}

// ── Read IMU ──────────────────────────────────────────────────────────────────
struct ImuData {
  int16_t ax, ay, az;
  int16_t gx, gy, gz;
  int16_t temp;
  int16_t mx, my, mz;
  bool    mag_ok;
};

void mpu_read_all(ImuData &d) {
  uint8_t buf[14];
  if (mpu_read_bytes(MPU_ACCEL_XOUT_H, buf, 14)) {
    d.ax   = (int16_t)((buf[0]  << 8) | buf[1]);
    d.ay   = (int16_t)((buf[2]  << 8) | buf[3]);
    d.az   = (int16_t)((buf[4]  << 8) | buf[5]);
    d.temp = (int16_t)((buf[6]  << 8) | buf[7]);
    d.gx   = (int16_t)((buf[8]  << 8) | buf[9]);
    d.gy   = (int16_t)((buf[10] << 8) | buf[11]);
    d.gz   = (int16_t)((buf[12] << 8) | buf[13]);
  } else {
    d.ax = d.ay = d.az = d.gx = d.gy = d.gz = d.temp = 0;
  }

  // Read magnetometer if data ready
  uint8_t st1 = 0;
  ak_read_bytes(AK_ST1, &st1, 1);
  if (st1 & 0x01) {
    uint8_t mag[7];
    if (ak_read_bytes(AK_HXL, mag, 7)) {
      // AK8963: Little-endian, 16-bit
      d.mx = (int16_t)((mag[1] << 8) | mag[0]);
      d.my = (int16_t)((mag[3] << 8) | mag[2]);
      d.mz = (int16_t)((mag[5] << 8) | mag[4]);
      // mag[6] = ST2 — must read to unlatch
      d.mag_ok = !(mag[6] & 0x08);  // HOFL bit = overflow
    } else {
      d.mx = d.my = d.mz = 0;
      d.mag_ok = false;
    }
  } else {
    d.mx = d.my = d.mz = 0;
    d.mag_ok = false;
  }
}

// ── BMP280 init ───────────────────────────────────────────────────────────────
bool bmp_init() {
  uint8_t id = 0;
  Wire.beginTransmission(BMP_ADDR);
  Wire.write(BMP_CHIP_ID);
  if (Wire.endTransmission(false) != 0) return false;
  Wire.requestFrom((uint8_t)BMP_ADDR, (uint8_t)1);
  if (!Wire.available()) return false;
  id = Wire.read();
  if (id != 0x60 && id != 0x58) return false;

  // Reset
  Wire.beginTransmission(BMP_ADDR);
  Wire.write(BMP_RESET_REG); Wire.write(0xB6);
  Wire.endTransmission();
  delay(10);

  // Read calibration (26 bytes from 0x88)
  uint8_t cal[26];
  Wire.beginTransmission(BMP_ADDR);
  Wire.write(0x88);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)BMP_ADDR, (uint8_t)26);
  for (uint8_t i = 0; i < 26; i++) cal[i] = Wire.read();

  bmp_cal.T1 = (uint16_t)(cal[1]<<8|cal[0]);
  bmp_cal.T2 = (int16_t) (cal[3]<<8|cal[2]);
  bmp_cal.T3 = (int16_t) (cal[5]<<8|cal[4]);
  bmp_cal.P1 = (uint16_t)(cal[7]<<8|cal[6]);
  bmp_cal.P2 = (int16_t) (cal[9]<<8|cal[8]);
  bmp_cal.P3 = (int16_t) (cal[11]<<8|cal[10]);
  bmp_cal.P4 = (int16_t) (cal[13]<<8|cal[12]);
  bmp_cal.P5 = (int16_t) (cal[15]<<8|cal[14]);
  bmp_cal.P6 = (int16_t) (cal[17]<<8|cal[16]);
  bmp_cal.P7 = (int16_t) (cal[19]<<8|cal[18]);
  bmp_cal.P8 = (int16_t) (cal[21]<<8|cal[20]);
  bmp_cal.P9 = (int16_t) (cal[23]<<8|cal[22]);

  // Normal mode, osrs_t=2, osrs_p=16, filter coeff=4
  Wire.beginTransmission(BMP_ADDR);
  Wire.write(BMP_CONFIG); Wire.write(0x10);
  Wire.endTransmission();
  Wire.beginTransmission(BMP_ADDR);
  Wire.write(BMP_CTRL_MEAS); Wire.write(0x57);
  Wire.endTransmission();
  delay(100);
  return true;
}

void bmp_read(int32_t *press_pa_x100, int32_t *temp_cdegc) {
  uint8_t buf[6];
  Wire.beginTransmission(BMP_ADDR);
  Wire.write(BMP_PRESS_MSB);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)BMP_ADDR, (uint8_t)6);
  for (uint8_t i = 0; i < 6; i++) buf[i] = Wire.read();

  int32_t adc_P = ((int32_t)buf[0]<<12)|((int32_t)buf[1]<<4)|(buf[2]>>4);
  int32_t adc_T = ((int32_t)buf[3]<<12)|((int32_t)buf[4]<<4)|(buf[5]>>4);

  // BMP280 datasheet temperature compensation
  int32_t v1 = ((((adc_T>>3)-((int32_t)bmp_cal.T1<<1)))*bmp_cal.T2)>>11;
  int32_t v2 = (((((adc_T>>4)-(int32_t)bmp_cal.T1)*
                   ((adc_T>>4)-(int32_t)bmp_cal.T1))>>12)*bmp_cal.T3)>>14;
  int32_t t_fine = v1 + v2;
  *temp_cdegc = (t_fine * 5 + 128) >> 8;  // units: 0.01°C

  // BMP280 datasheet pressure compensation
  int64_t p1 = (int64_t)t_fine - 128000;
  int64_t p2 = p1 * p1 * (int64_t)bmp_cal.P6;
  p2 += ((p1*(int64_t)bmp_cal.P5)<<17);
  p2 += ((int64_t)bmp_cal.P4<<35);
  p1  = ((p1*p1*(int64_t)bmp_cal.P3)>>8)+((p1*(int64_t)bmp_cal.P2)<<12);
  p1  = (((int64_t)1<<47)+p1)*((int64_t)bmp_cal.P1)>>33;
  if (p1 == 0) { *press_pa_x100 = 0; return; }
  int64_t pres = 1048576 - adc_P;
  pres = (((pres<<31)-p2)*3125)/p1;
  p1   = ((int64_t)bmp_cal.P9*(pres>>13)*(pres>>13))>>25;
  p2   = ((int64_t)bmp_cal.P8*pres)>>19;
  pres = ((pres+p1+p2)>>8)+((int64_t)bmp_cal.P7<<4);

  // pres is now Pa * 256 — convert to Pa * 100
  *press_pa_x100 = (int32_t)((pres * 100) >> 8);
}

// ── Encoder ISR ───────────────────────────────────────────────────────────────
void enc_clk_isr() {
  uint8_t clk = digitalRead(ENC_CLK);
  uint8_t dt  = digitalRead(ENC_DT);
  if (clk != last_clk_state) {
    enc_delta += (dt != clk) ? +1 : -1;
    last_clk_state = clk;
  }
}

void enc_sw_isr() {
  uint8_t sw = digitalRead(ENC_SW);
  if (sw == LOW && last_sw_state == HIGH) {
    sw_down_ms = millis();
  } else if (sw == HIGH && last_sw_state == LOW) {
    uint32_t held = millis() - sw_down_ms;
    if      (held >= 600) enc_btn |= 0x02;  // long press
    else if (held >= 30)  enc_btn |= 0x01;  // short press
  }
  last_sw_state = sw;
}

// ── Pack 62-byte IMU frame ────────────────────────────────────────────────────
static uint16_t imu_seq  = 0;
static uint16_t peri_seq = 0;

void pack_imu_frame(uint8_t *f, const ImuData &d) {
  p = 0;
  w_u8(f, 0xAA); w_u8(f, 0x55);           // sync
  w_u16(f, imu_seq++);                     // sequence
  w_u64(f, micros64());                    // timestamp

  // IMU1 = real data, IMU2 + IMU3 = copy of IMU1
  // (single sensor — fault flags indicate only 1 active)
  for (uint8_t i = 0; i < 3; i++) {
    w_i16(f, d.gx); w_i16(f, d.gy); w_i16(f, d.gz);
    w_i16(f, d.ax); w_i16(f, d.ay); w_i16(f, d.az);
  }

  // Magnetometer median (same value for all 3 since we have 1 mag)
  w_i16(f, d.mx); w_i16(f, d.my); w_i16(f, d.mz);

  // Temperature (int8 °C)
  w_i8(f, (int8_t)(d.temp / 340 + 36));   // MPU-9250 temp formula

  // Fault flags: IMU2 + IMU3 are not real → bits 1+2 set
  // bit0=IMU1 fail, bit1=IMU2 fail, bit2=IMU3 fail, bit3=mag fail
  uint8_t faults = 0x06;  // IMU2+IMU3 absent — Pi EKF handles gracefully
  if (!d.mag_ok) faults |= 0x08;
  w_u8(f, faults);

  f[p] = crc8(f, p); p++;                 // CRC8 over bytes 0–55
  while (p < IMU_FRAME_SIZE) f[p++] = 0;  // pad to 62
}

// ── Pack 48-byte peripheral frame ─────────────────────────────────────────────
void pack_peri_frame(uint8_t *f, int32_t press_pa_x100, int32_t temp_cdegc) {
  cli();
  int8_t  delta = enc_delta; enc_delta = 0;
  uint8_t btn   = enc_btn;   enc_btn   = 0;
  sei();

  p = 0;
  w_u8(f, 0xBB); w_u8(f, 0x66);           // sync
  w_u16(f, peri_seq++);
  w_u64(f, micros64());

  // No GNSS — all zero
  double zero_d = 0.0; float zero_f = 0.0;
  w_double(f, zero_d);   // lat
  w_double(f, zero_d);   // lon
  w_float(f,  zero_f);   // alt
  w_u16(f, 0);           // speed
  w_u16(f, 0);           // track

  // Pressure: stored as hPa * 10
  // press_pa_x100 = Pa * 100
  // hPa = Pa / 100  →  hPa * 10 = Pa / 10 = press_pa_x100 / 1000
  uint16_t press_val = bmp_ok ? (uint16_t)(press_pa_x100 / 1000) : 0;
  w_u16(f, press_val);

  // Temperature: 0.01°C units (already in that format from bmp_read)
  w_i16(f, (int16_t)temp_cdegc);

  w_u8(f, 0);    // fix = none
  w_u8(f, 0);    // sats = 0
  w_u8(f, 99);   // hdop = 9.9

  w_i8(f,  delta);
  w_u8(f,  btn);
  w_u8(f,  0);   // battery unknown

  f[p] = crc8(f, p); p++;
  while (p < PERI_FRAME_SIZE) f[p++] = 0;
}

// ── SETUP ─────────────────────────────────────────────────────────────────────
uint8_t imu_frame[IMU_FRAME_SIZE];
uint8_t peri_frame[PERI_FRAME_SIZE];

void setup() {
  Serial.begin(115200);
  delay(500);

  Wire.begin();
  Wire.setClock(400000);

  // LED
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH);  // off

  // Encoder
  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT,  INPUT_PULLUP);
  pinMode(ENC_SW,  INPUT_PULLUP);
  last_clk_state = digitalRead(ENC_CLK);
  last_sw_state  = digitalRead(ENC_SW);
  attachInterrupt(digitalPinToInterrupt(ENC_CLK), enc_clk_isr, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_SW),  enc_sw_isr,  CHANGE);

  // Init MPU-9250
  bool mpu_ok = mpu_init();
  bmp_ok      = bmp_init();

  // Startup LED: 3x both if all OK, 5x if init failed
  uint8_t flashes = (mpu_ok && bmp_ok) ? 3 : 5;
  for (uint8_t i = 0; i < flashes; i++) {
    digitalWrite(LED_PIN, LOW); delay(80);
    digitalWrite(LED_PIN, HIGH); delay(80);
  }

  wdt_enable(WDTO_2S);
}

// ── LOOP ──────────────────────────────────────────────────────────────────────
void loop() {
  static uint32_t last_tx = 0;
  uint32_t now = millis();

  if (now - last_tx >= 100) {
    last_tx = now;

    // Read sensors
    ImuData d;
    mpu_read_all(d);

    int32_t press_pa_x100 = 0, temp_cdegc = 0;
    if (bmp_ok) {
      bmp_read(&press_pa_x100, &temp_cdegc);
    } else {
      bmp_ok = bmp_init();
    }

    // LED blink on encoder
    cli();
    int8_t  dp = enc_delta;
    uint8_t bp = enc_btn;
    sei();
    if (dp != 0)   blink_trigger(1);
    if (bp & 0x01) blink_trigger(3);
    if (bp & 0x02) blink_trigger(5);

    // Send both frames
    pack_imu_frame(imu_frame, d);
    Serial.write(imu_frame, IMU_FRAME_SIZE);

    pack_peri_frame(peri_frame, press_pa_x100, temp_cdegc);
    Serial.write(peri_frame, PERI_FRAME_SIZE);
  }

  blink_update();
  wdt_reset();
}
