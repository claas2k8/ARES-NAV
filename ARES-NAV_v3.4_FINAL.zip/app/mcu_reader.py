"""
ARES-NAV — MCU USB Frame Reader
Revision 3.2  |  Duwald Systems  |  March 2026

Two background threads read binary frames from MCU 1 and MCU 2 over USB CDC.
Frames are validated (sync bytes + CRC8), decoded, and stored thread-safely.
The main application reads decoded frames via get_mcu1() / get_mcu2().

MCU 1: 62-byte IMU frame  @ ~10 Hz delivered (500 Hz sampled, ring-buffered)
MCU 2: 48-byte peripheral frame @ 10 Hz

USB device paths (via udev symlinks):
    /dev/aresnav-imu   → MCU 1
    /dev/aresnav-peri  → MCU 2

Fallback scan order if symlinks not present:
    /dev/ttyACM0, /dev/ttyACM1, /dev/ttyUSB0, /dev/ttyUSB1
"""

import struct
import threading
import time
import logging
from dataclasses import dataclass, field
from typing import Optional

import serial
import serial.tools.list_ports

log = logging.getLogger("ARES-NAV.mcu")

# ── CRC8 (polynomial 0x07 — same as firmware) ────────────────────────────────
def crc8(data: bytes) -> int:
    c = 0
    for b in data:
        c ^= b
        for _ in range(8):
            c = ((c << 1) ^ 0x07) & 0xFF if (c & 0x80) else (c << 1) & 0xFF
    return c


# ── Decoded frame dataclasses ─────────────────────────────────────────────────

@dataclass
class MCU1Frame:
    """Decoded 62-byte IMU frame from MCU 1."""
    seq:        int   = 0
    timestamp:  int   = 0        # microseconds since MCU boot (uint64)

    # Raw gyro/accel for all 3 IMUs — int16 raw counts
    # gyro LSB = 16.4 counts/(°/s) at ±2000°/s FSR
    # accel LSB = 2048 counts/g at ±16g FSR
    gyro:       list  = field(default_factory=lambda: [[0,0,0],[0,0,0],[0,0,0]])
    accel:      list  = field(default_factory=lambda: [[0,0,0],[0,0,0],[0,0,0]])

    # Magnetometer median (µT × 10, int16)
    mag:        list  = field(default_factory=lambda: [0, 0, 0])

    # Temperature from BMP280 (°C, int8)
    temp_c:     int   = 0

    # Fault flags: bit0=IMU1 bit1=IMU2 bit2=IMU3 bit3=Mag
    fault_flags: int  = 0

    # Derived convenience values (in physical units)
    gyro_dps:   list  = field(default_factory=lambda: [[0.0,0.0,0.0]]*3)
    accel_g:    list  = field(default_factory=lambda: [[0.0,0.0,0.0]]*3)
    mag_ut:     list  = field(default_factory=lambda: [0.0, 0.0, 0.0])

    # Medians (computed from 3 IMUs, used by EKF)
    gyro_med_dps:  list = field(default_factory=lambda: [0.0, 0.0, 0.0])
    accel_med_g:   list = field(default_factory=lambda: [0.0, 0.0, 0.0])

    rx_time:    float = 0.0      # wall clock time of reception
    crc_ok:     bool  = False

    @property
    def imu1_ok(self) -> bool: return not (self.fault_flags & 0x01)
    @property
    def imu2_ok(self) -> bool: return not (self.fault_flags & 0x02)
    @property
    def imu3_ok(self) -> bool: return not (self.fault_flags & 0x04)
    @property
    def mag_ok(self)  -> bool: return not (self.fault_flags & 0x08)


@dataclass
class MCU2Frame:
    """Decoded 48-byte peripheral frame from MCU 2."""
    seq:        int   = 0
    timestamp:  int   = 0        # microseconds since MCU boot

    # GNSS
    lat:        float = 0.0      # degrees WGS-84
    lon:        float = 0.0
    alt_m:      float = 0.0      # metres MSL
    spd_kts:    float = 0.0      # knots
    trk_deg:    float = 0.0      # degrees true
    fix:        int   = 0        # 0=none 1=2D 2=3D 3=3D+SBAS
    sats:       int   = 0
    hdop:       float = 99.9

    # Barometer
    pressure_hpa: float = 0.0    # hPa
    temp_c:       float = 0.0    # °C  (AHT20 if available, else BMP280)
    humidity_pct: float = 0.0    # % RH from AHT20 (0 if not available)

    # Encoder
    enc_delta:  int   = 0        # signed, rotation since last frame
    btn_flags:  int   = 0        # bit0=short press, bit1=long press

    # Power
    battery_v:  float = 0.0      # volts (0 = unknown)

    rx_time:    float = 0.0
    crc_ok:     bool  = False

    @property
    def gnss_valid(self) -> bool: return self.fix >= 2
    @property
    def baro_valid(self) -> bool: return self.pressure_hpa > 500.0
    @property
    def short_press(self) -> bool: return bool(self.btn_flags & 0x01)
    @property
    def long_press(self)  -> bool: return bool(self.btn_flags & 0x02)


# ── Frame decoders ────────────────────────────────────────────────────────────

GYRO_SCALE  = 1.0 / 16.4    # raw → °/s  (±2000°/s FSR)
ACCEL_SCALE = 1.0 / 2048.0  # raw → g    (±16g FSR)
MAG_SCALE   = 0.1            # raw → µT  (stored as µT×10)

def _med3(a, b, c):
    if a <= b <= c or c <= b <= a: return b
    if b <= a <= c or c <= a <= b: return a
    return c

def decode_mcu1(raw: bytes) -> Optional[MCU1Frame]:
    """Decode a 62-byte MCU 1 frame. Returns None on CRC error."""
    if len(raw) != 62:
        return None
    if raw[0] != 0xAA or raw[1] != 0x55:
        return None
    if crc8(raw[:56]) != raw[56]:
        log.debug(f"MCU1 CRC fail: expected {crc8(raw[:56]):02X} got {raw[56]:02X}")
        return None

    f = MCU1Frame(crc_ok=True, rx_time=time.monotonic())
    f.seq       = struct.unpack_from('<H', raw, 2)[0]
    f.timestamp = struct.unpack_from('<Q', raw, 4)[0]

    # 3 IMUs × (gyro XYZ + accel XYZ) = 3 × 12 bytes starting at offset 12
    off = 12
    for i in range(3):
        gx, gy, gz = struct.unpack_from('<hhh', raw, off);     off += 6
        ax, ay, az = struct.unpack_from('<hhh', raw, off);     off += 6
        f.gyro[i]      = [gx, gy, gz]
        f.accel[i]     = [ax, ay, az]
        f.gyro_dps[i]  = [gx * GYRO_SCALE,  gy * GYRO_SCALE,  gz * GYRO_SCALE]
        f.accel_g[i]   = [ax * ACCEL_SCALE, ay * ACCEL_SCALE, az * ACCEL_SCALE]

    # Magnetometer median
    mx, my, mz  = struct.unpack_from('<hhh', raw, 48)
    f.mag       = [mx, my, mz]
    f.mag_ut    = [mx * MAG_SCALE, my * MAG_SCALE, mz * MAG_SCALE]

    f.temp_c     = struct.unpack_from('<b', raw, 54)[0]
    f.fault_flags = raw[55]

    # Compute medians across 3 IMUs for EKF input
    for axis in range(3):
        vals_g = [f.gyro_dps[i][axis] for i in range(3)]
        vals_a = [f.accel_g[i][axis]  for i in range(3)]
        f.gyro_med_dps[axis] = _med3(*vals_g)
        f.accel_med_g[axis]  = _med3(*vals_a)

    return f


def decode_mcu2(raw: bytes) -> Optional[MCU2Frame]:
    """Decode a 48-byte MCU 2 frame. Returns None on CRC error."""
    if len(raw) != 48:
        return None
    if raw[0] != 0xBB or raw[1] != 0x66:
        return None
    if crc8(raw[:46]) != raw[46]:
        log.debug(f"MCU2 CRC fail: expected {crc8(raw[:46]):02X} got {raw[46]:02X}")
        return None

    f = MCU2Frame(crc_ok=True, rx_time=time.monotonic())
    f.seq       = struct.unpack_from('<H',  raw,  2)[0]
    f.timestamp = struct.unpack_from('<Q',  raw,  4)[0]
    f.lat       = struct.unpack_from('<d',  raw, 12)[0]
    f.lon       = struct.unpack_from('<d',  raw, 20)[0]
    f.alt_m     = struct.unpack_from('<f',  raw, 28)[0]

    spd_cms     = struct.unpack_from('<H',  raw, 32)[0]
    trk_cdeg    = struct.unpack_from('<H',  raw, 34)[0]
    press_hpa10 = struct.unpack_from('<H',  raw, 36)[0]
    temp_cdegc  = struct.unpack_from('<h',  raw, 38)[0]

    f.spd_kts       = spd_cms / 51.444          # cm/s → knots
    f.trk_deg       = trk_cdeg / 100.0
    f.pressure_hpa  = press_hpa10 / 10.0
    f.temp_c        = temp_cdegc / 100.0

    f.fix           = raw[40]
    f.sats          = raw[41]
    f.hdop          = raw[42] / 10.0

    f.enc_delta     = struct.unpack_from('<b', raw, 43)[0]
    f.btn_flags     = raw[44]

    batt_raw        = raw[45]
    f.battery_v     = batt_raw * 0.05 if batt_raw else 0.0

    return f


# ── Serial port discovery ─────────────────────────────────────────────────────

MCU1_PATHS  = ["/dev/aresnav-imu",   "/dev/ttyACM0", "/dev/ttyUSB0"]
MCU2_PATHS  = ["/dev/aresnav-peri",  "/dev/ttyACM1", "/dev/ttyUSB1"]
BRIDGE_PATHS = ["/dev/aresnav-bridge", "/dev/ttyACM0", "/dev/ttyACM1",
                "/dev/ttyUSB0", "/dev/ttyUSB1"]

def _find_port(candidates: list) -> Optional[str]:
    """Return first candidate path that exists."""
    import os
    for p in candidates:
        if os.path.exists(p):
            return p
    return None


# ── Reader thread ─────────────────────────────────────────────────────────────

class MCUReader:
    """
    Background thread that reads frames from one MCU over USB CDC serial.

    Usage:
        r = MCUReader("MCU2", frame_size=48, sync=(0xBB, 0x66),
                      decoder=decode_mcu2, port_candidates=MCU2_PATHS)
        r.start()
        frame = r.get()       # latest decoded frame, or None
        stats = r.stats       # dict with rx_count, crc_errors, etc.
    """

    def __init__(self, name: str, frame_size: int,
                 sync: tuple, decoder,
                 port_candidates: list,
                 baud: int = 115200,
                 reconnect_interval: float = 2.0):
        self.name               = name
        self.frame_size         = frame_size
        self.sync               = sync
        self.decoder            = decoder
        self.port_candidates    = port_candidates
        self.baud               = baud
        self.reconnect_interval = reconnect_interval

        self._lock      = threading.Lock()
        self._latest    = None
        self._thread    = None
        self._running   = False

        self._rx_count  = 0
        self._crc_errors = 0
        self._sync_losses = 0
        self._last_rx   = 0.0
        self._port_used = None

    def start(self):
        self._running = True
        self._thread  = threading.Thread(target=self._run, daemon=True,
                                          name=f"MCU-{self.name}")
        self._thread.start()
        log.info(f"{self.name} reader started")

    def stop(self):
        self._running = False

    def get(self):
        """Return latest decoded frame (thread-safe). None if no frame yet."""
        with self._lock:
            return self._latest

    @property
    def link_ok(self) -> bool:
        """True if a frame was received within the last 600ms."""
        return (time.monotonic() - self._last_rx) < 0.6

    @property
    def stats(self) -> dict:
        return {
            "rx_count":    self._rx_count,
            "crc_errors":  self._crc_errors,
            "sync_losses": self._sync_losses,
            "link_ok":     self.link_ok,
            "port":        self._port_used,
        }

    # ── Internal ──────────────────────────────────────────────────────────────

    def _run(self):
        while self._running:
            port = _find_port(self.port_candidates)
            if not port:
                log.warning(f"{self.name}: no device found, retrying in "
                            f"{self.reconnect_interval}s")
                time.sleep(self.reconnect_interval)
                continue

            try:
                log.info(f"{self.name}: opening {port} @ {self.baud}")
                self._port_used = port
                with serial.Serial(port, self.baud, timeout=1.0) as ser:
                    ser.reset_input_buffer()
                    self._read_loop(ser)
            except serial.SerialException as e:
                log.warning(f"{self.name}: serial error — {e}")
                self._port_used = None
                time.sleep(self.reconnect_interval)
            except Exception as e:
                log.error(f"{self.name}: unexpected error — {e}")
                time.sleep(self.reconnect_interval)

    def _read_loop(self, ser: serial.Serial):
        """
        Robust framing: scan for sync bytes, then read exactly frame_size bytes.
        On CRC failure or sync loss, re-scan from next byte.
        """
        buf = bytearray()
        s0, s1 = self.sync

        while self._running:
            # Fill buffer up to 2× frame size
            chunk = ser.read(max(1, self.frame_size - len(buf)))
            if not chunk:
                continue
            buf.extend(chunk)

            # Scan for sync pattern
            while len(buf) >= self.frame_size:
                # Find sync
                idx = -1
                for i in range(len(buf) - 1):
                    if buf[i] == s0 and buf[i+1] == s1:
                        idx = i
                        break

                if idx == -1:
                    # No sync in buffer — discard all but last byte
                    self._sync_losses += 1
                    buf = buf[-1:]
                    break

                if idx > 0:
                    # Discard bytes before sync
                    self._sync_losses += 1
                    buf = buf[idx:]

                if len(buf) < self.frame_size:
                    break  # need more data

                # Try to decode
                raw   = bytes(buf[:self.frame_size])
                frame = self.decoder(raw)

                if frame is not None:
                    with self._lock:
                        self._latest = frame
                    self._rx_count  += 1
                    self._last_rx    = time.monotonic()
                    buf = buf[self.frame_size:]
                else:
                    # CRC failed — skip one byte and re-scan
                    self._crc_errors += 1
                    buf = buf[1:]


# ── Encoder event queue ───────────────────────────────────────────────────────

class EncoderEvents:
    """
    Collects encoder deltas and button presses from MCU2Frame stream.
    Call update(frame) from the main loop. Read events with pop_delta() etc.
    """

    def __init__(self):
        self._lock       = threading.Lock()
        self._delta_acc  = 0     # accumulated rotation
        self._short_press = False
        self._long_press  = False

    def update(self, frame: MCU2Frame):
        with self._lock:
            self._delta_acc   += frame.enc_delta
            if frame.short_press:
                self._short_press = True
            if frame.long_press:
                self._long_press  = True

    def pop_delta(self) -> int:
        """Return accumulated delta since last call, reset to 0."""
        with self._lock:
            d = self._delta_acc
            self._delta_acc = 0
            return d

    def pop_short_press(self) -> bool:
        """Return True if a short press occurred since last call."""
        with self._lock:
            v = self._short_press
            self._short_press = False
            return v

    def pop_long_press(self) -> bool:
        """Return True if a long press occurred since last call."""
        with self._lock:
            v = self._long_press
            self._long_press = False
            return v


# ── Convenience factory ───────────────────────────────────────────────────────

# ── Bridge mode port candidates ───────────────────────────────────────────────
# When using ARES_NAV_Bridge.ino (single Arduino, both frame types)
BRIDGE_PATHS = [
    "/dev/aresnav-bridge",  # udev symlink (optional)
    "/dev/ttyACM0",
    "/dev/ttyACM1",
    "/dev/ttyUSB0",
    "/dev/ttyUSB1",
]

def make_readers(bridge_mode: bool = False) -> tuple:
    """
    Create and return (mcu1_reader, mcu2_reader, encoder_events).

    bridge_mode=True:  Single Arduino running ARES_NAV_Bridge.ino.
                       Both frame types from same port.
    bridge_mode=False: Separate MCU 1 (ARESNAV-IMU) + MCU 2 (ARESNAV-PERI).
    """
    if bridge_mode:
        mcu1 = MCUReader("Bridge-IMU",  62, (0xAA, 0x55),
                         decode_mcu1, BRIDGE_PATHS)
        mcu2 = MCUReader("Bridge-PERI", 48, (0xBB, 0x66),
                         decode_mcu2, BRIDGE_PATHS)
    else:
        mcu1 = MCUReader("MCU1", 62, (0xAA, 0x55), decode_mcu1, MCU1_PATHS)
        mcu2 = MCUReader("MCU2", 48, (0xBB, 0x66), decode_mcu2, MCU2_PATHS)

    enc = EncoderEvents()
    return mcu1, mcu2, enc


# ── Standalone test ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.DEBUG,
                        format="%(levelname)s  %(name)s  %(message)s")

    mcu1, mcu2, enc = make_readers()
    mcu1.start()
    mcu2.start()

    print("Listening for MCU frames. Ctrl+C to stop.\n")
    print(f"{'Time':>6}  {'MCU1 seq':>8}  {'Gyro X':>8}  "
          f"{'MCU2 seq':>8}  {'GPS fix':>7}  {'Baro hPa':>9}  "
          f"{'Encoder':>7}")

    try:
        while True:
            f1 = mcu1.get()
            f2 = mcu2.get()

            enc_update = ""
            if f2:
                enc.update(f2)
                d = enc.pop_delta()
                sp = enc.pop_short_press()
                lp = enc.pop_long_press()
                if d:    enc_update += f"Δ{d:+d} "
                if sp:   enc_update += "SHORT "
                if lp:   enc_update += "LONG"

            t = time.monotonic()
            g = f"{f1.gyro_med_dps[0]:+7.2f}" if f1 else "    ---"
            s1 = f"{f1.seq:8d}" if f1 else "     ---"
            s2 = f"{f2.seq:8d}" if f2 else "     ---"
            fix = f"GPS{f2.fix}" if f2 else "  ---"
            baro = f"{f2.pressure_hpa:9.2f}" if f2 else "      ---"

            print(f"{t:6.1f}  {s1}  {g}  {s2}  {fix}  {baro}  {enc_update}",
                  end="\r")
            time.sleep(0.1)

    except KeyboardInterrupt:
        print("\nStopped.")
        print(f"MCU1: {mcu1.stats}")
        print(f"MCU2: {mcu2.stats}")
